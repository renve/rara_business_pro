<?php
/**
 * Template Functions which enhance the theme by hooking into WordPress
 *
 * @package Rara_Business_Pro
 */

if( ! function_exists( 'rara_business_pro_doctype' ) ) :
/**
 * Doctype Declaration
*/
function rara_business_pro_doctype(){
    ?>
    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>
    <?php
}
endif;
add_action( 'rara_business_pro_doctype', 'rara_business_pro_doctype' );

if( ! function_exists( 'rara_business_pro_head' ) ) :
/**
 * Before wp_head 
*/
function rara_business_pro_head(){
    ?>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php
}
endif;
add_action( 'rara_business_pro_before_wp_head', 'rara_business_pro_head' );

if( ! function_exists( 'rara_business_pro_page_start' ) ) :
/**
 * Page Start
*/
function rara_business_pro_page_start(){
    ?>
    <div id="page" class="site">
    <?php
}
endif;
add_action( 'rara_business_pro_before_header', 'rara_business_pro_page_start', 20 );

if( ! function_exists( 'rara_business_pro_header' ) ) :
/**
 * Header Start
*/
function rara_business_pro_header(){ 
    /** Load default theme options */
    $default_options =  rara_business_pro_default_theme_options();
    $header_array    = array( 'one', 'two', 'three', 'four', 'five' );
    $header          = get_theme_mod( 'header_layout', $default_options['header_layout'] );

    if( in_array( $header, $header_array ) ){            
        get_template_part( 'headers/' . $header );
    }
}
endif;
add_action( 'rara_business_pro_header', 'rara_business_pro_header', 20 );

if( ! function_exists( 'rara_business_pro_banner' ) ) :
/**
 * Banner  
*/
function rara_business_pro_banner(){
    $default_options = rara_business_pro_default_theme_options(); // Get default theme options

    $banner_control      = get_theme_mod( 'ed_banner_section', $default_options['ed_banner_section'] );
    $slider_type         = get_theme_mod( 'slider_type', $default_options['slider_type'] ); 
    $title               = get_theme_mod( 'banner_title', $default_options['banner_title'] );
    $description         = get_theme_mod( 'banner_description', $default_options['banner_description'] );
    $link_one_label      = get_theme_mod( 'banner_link_one_label', $default_options['banner_link_one_label'] );
    $link_one_url        = get_theme_mod( 'banner_link_one_url', $default_options['banner_link_one_url'] );
    $link_two_label      = get_theme_mod( 'banner_link_two_label', $default_options['banner_link_two_label'] );
    $link_two_url        = get_theme_mod( 'banner_link_two_url', $default_options['banner_link_two_url'] );
    $banner_newsletter   = get_theme_mod( 'banner_newsletter', $default_options['banner_newsletter'] );
    $slider_cat          = get_theme_mod( 'slider_cat', $default_options['slider_cat'] );
    $slider_pages        = get_theme_mod( 'slider_pages', $default_options['slider_pages'] );
    $slider_custom       = get_theme_mod( 'slider_custom', $default_options['slider_custom'] );
    $posts_per_page      = get_theme_mod( 'no_of_slides', $default_options['no_of_slides'] );
    $ed_caption          = get_theme_mod( 'slider_caption', $default_options['slider_caption'] );
    $read_more           = get_theme_mod( 'slider_readmore', $default_options['slider_readmore'] );
    $custom_header_image = get_header_image_tag(); // get custom header image tag

    if( is_front_page() && ! is_home() ){ 
        if( get_custom_header_markup() &&  ( $banner_control == 'static_banner' || $banner_control == 'static_nl_banner' ) && ( has_header_video() ||  ! empty( $custom_header_image ) ) ){ 

            $class = has_header_video() ? 'video-banner' : '';

            if( $banner_control == 'static_nl_banner' && ! empty( $banner_newsletter ) ){
                $class .= ' nl_banner';
            } ?>
            
            <div id="banner-section" class="banner <?php echo esc_attr( $class ); ?>">
        		<?php the_custom_header_markup(); ?>
        		<div class="banner-text">
        			<div class="container">
        				<div class="text-holder">

                            <?php
                                if ( ! empty( $title ) || ! empty( $description ) ){

                                    if( $banner_control == 'static_nl_banner' && ! empty( $banner_newsletter ) ){
                                        echo '<div class="text-holder-inner">';
                                    }

                                    if ( $title ) echo '<h2 class="title banner-title wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">'. esc_html( $title ).'</h2>';
                                    if ( $description ) echo '<p class="wow banner-desc fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">'. wp_kses_post( $description ) .'</p>';

                                    if( $banner_control == 'static_nl_banner' && ! empty( $banner_newsletter ) ){
                                        echo '</div>';
                                    }
                                    
                                }

                                if ( $banner_control == 'static_banner' && ( ( ! empty( $link_one_label ) && ! empty( $link_one_url ) )  || ( ! empty( $link_two_label ) && ! empty( $link_two_url ) ) ) ) {
                                        ?>
                                        <div class="btn-holder wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.7s">
                                            <?php
                                                if ( ! empty( $link_one_label ) && ! empty( $link_one_url ) ) echo  '<a href="'. esc_url( $link_one_url ) .'" class="btn-free-inquiry btn1"><i class="fa fa-edit"></i>'. esc_html( $link_one_label ) .'</a>'; 
                                                if ( ! empty( $link_two_label ) && ! empty( $link_two_url ) ) echo '<a href="'. esc_url( $link_two_url ) .'" class="btn-view-service btn2">'. esc_html( $link_two_label ) .'</a>';
                                            ?>
                                        </div>
                                    <?php
                                } elseif ( $banner_control == 'static_nl_banner' && ! empty( $banner_newsletter ) ){
                                    echo do_shortcode( $banner_newsletter );
                                }
                            ?>
        				</div>
        			</div>
        		</div>
        	</div>
    <?php 
        } elseif( $banner_control == 'slider_banner' ){

            if( $slider_type == 'latest_posts' || $slider_type == 'cat' || $slider_type == 'pages' ){

                $args = array(
                    'post_status'         => 'publish',            
                    'ignore_sticky_posts' => true
                );
                
                if( $slider_type === 'cat' && $slider_cat ){
                    $args['post_type']      = 'post';
                    $args['cat']            = $slider_cat; 
                    $args['posts_per_page'] = -1;  
                }elseif( $slider_type == 'pages' && $slider_pages ){
                    $args['post_type']      = 'page';
                    $args['posts_per_page'] = -1;
                    $args['post__in']       = rara_business_pro_get_id_from_page( $slider_pages );
                    $args['orderby']        = 'post__in';
                }else{
                    $args['post_type']      = 'post';
                    $args['posts_per_page'] = $posts_per_page;
                }
                    
                $qry = new WP_Query( $args );
                
                if( $qry->have_posts() ){ ?>
                    <div class="banner">
                        <div class="banner-slider owl-carousel owl-theme">

                            <?php while( $qry->have_posts() ){ $qry->the_post(); ?>
                                <div class="slider-item">
                                    <?php 
                                        if( has_post_thumbnail() ){
                                            the_post_thumbnail( 'rara-business-slider', array( 'itemprop' => 'image' ) );    
                                        }else{ 
                                            echo '<img src="'. esc_url( get_template_directory_uri().'/images/rara-business-slider.jpg' ) .'" alt="'. esc_attr( get_the_title() ) .'">';
                                        }

                                        if( $ed_caption ){ ?>
                                            <div class="banner-text">
                                                <div class="container">
                                                    <div class="text-holder">
                                                        <?php 
                                                            the_title( '<h2 class="title">','</h2>' ); 
                                                            if( has_excerpt() ){
                                                                $source_content = get_the_excerpt();
                                                            }else{
                                                                $source_content = get_the_content();
                                                            }

                                                            $source_content = strip_shortcodes( $source_content );
                                                            $trimmed_content = wp_trim_words( $source_content, 25, '&hellip;' );

                                                            echo wpautop( wp_kses_post( $trimmed_content ) );

                                                            if( ! empty( $read_more ) ){
                                                                echo '<div class="btn-holder"><a href="'. esc_url( get_the_permalink() ) .'" class="slider-btn">'. esc_html( $read_more ) .'</a></div>';
                                                            }
                                                        ?>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                    <?php } ?>
                                </div>
                            <?php } ?>   

                        </div>
                    </div>
                <?php
                wp_reset_postdata();
                }
            
            }elseif( $slider_type == 'custom' && $slider_custom ){ ?>

                <div class="banner">
                    <div class="banner-slider owl-carousel owl-theme">
                        
                        <?php foreach( $slider_custom as $slide ){  ?>
                            <div class="slider-item">
                                <?php 
                                    if( ! empty( $slide['thumbnail'] ) ){
                                        $image = wp_get_attachment_image_url( $slide['thumbnail'], 'rara-business-slider' ); ?>
                                        <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $slide['title'] );?>" itemprop="image" />
                                        <?php
                                    }else{ 
                                       echo '<img src="'. esc_url( get_template_directory_uri().'/images/rara-business-slider.jpg' ) .'" alt="'. esc_attr( $slide['title'] ) .'">';
                                    }

                                    if( $ed_caption ){ ?>   
                                        <div class="banner-text">
                                            <div class="container">
                                                <div class="text-holder">
                                                    <?php 
                                                        if( ! empty( $slide['title'] ) ){
                                                            echo '<h2 class="title">'. esc_html( $slide['title'] ) .'</h2>';
                                                        }

                                                        if( ! empty( $slide['subtitle'] ) ){
                                                            echo wpautop( wp_kses_post( $slide['subtitle'] ) );
                                                        } 

                                                        if( ! empty( $slide['link'] ) && ! empty( $read_more ) ){
                                                            echo  '<div class="btn-holder"><a href="'. esc_url( $slide['link'] ) .'" class="slider-btn">'. esc_html( $read_more ) .'</a></div>';
                                                        } 
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }  
                                ?>
                            </div>
                        <?php } ?>

                    </div>
                </div>
                <?php
            }
        }
    }
}
endif;
add_action( 'rara_business_pro_after_header', 'rara_business_pro_banner', 10 );


if( ! function_exists( 'rara_business_pro_content_start' ) ) :
/**
 * Content Start
*/
function rara_business_pro_content_start(){ 
    $home_sections = rara_business_pro_get_home_sections();

    if( !( is_front_page() && ! is_home() && $home_sections ) ){ ?>
    	<div id="content" class="site-content">
            <div class="container">
            <?php 
            if( ! ( is_front_page() && ! is_home() ) && ! is_home() && ! is_search() && ! is_archive() && ! is_page_template( 'templates/contact.php' ) ) rara_business_pro_breadcrumb();
            if( ! is_search() && ! is_archive() && ! is_page_template( 'templates/contact.php' ) && ! ( is_single() && 'post' === get_post_type() ) ) rara_business_pro_page_header();
            if( ! is_404() && ! is_page_template( array( 'templates/portfolio.php', 'templates/contact.php', 'templates/faq.php', 'templates/team.php', 'templates/testimonial.php' ) ) && ! is_tax( 'rara_portfolio_categories' ) ) echo '<div class="content-grid">';
    }
}
endif;
add_action( 'rara_business_pro_content', 'rara_business_pro_content_start' );

if( ! function_exists( 'rara_business_pro_breadcrumb' ) ) :
/**
 * Breadcrumbs
*/
function rara_business_pro_breadcrumb(){ 
    global $post;

    $default_options    = rara_business_pro_default_theme_options(); // Get default theme options
    $post_page          = get_option( 'page_for_posts' ); //The ID of the page that displays posts.
    $show_front         = get_option( 'show_on_front' ); //What to show on the front page    
    $home               = get_theme_mod( 'home_text', $default_options['home_text'] ); // text for the 'Home' link
    $breadcrumb_control = get_theme_mod( 'ed_breadcrumb', $default_options['ed_breadcrumb'] );
    $separator          = get_theme_mod( 'breadcrumb_separator', $default_options['breadcrumb_separator'] );
    $before             = '<span class="current">'; // tag before the current crumb
    $after              = '</span>'; // tag after the current crumb
    
    $separator          = ! empty( $separator ) ?  $separator : '>';
    $delimiter          = '<span class="separator">'. esc_html( $separator ) .'</span>';
    
    if( $breadcrumb_control ){
        
        echo '<div class="breadcrumb-wrapper" itemscope itemtype="http://schema.org/BreadcrumbList">
                <div id="crumbs" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                    <a href="' . esc_url( home_url() ) . '" itemprop="item">' . esc_html( $home ) . '</a> ' . $delimiter;
        
        if( is_home() ){
            
            echo $before . esc_html( single_post_title( '', false ) ) . $after;
            
        }elseif( is_category() ){
            
            $thisCat = get_category( get_query_var( 'cat' ), false );
            
            if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                $p = get_post( $post_page );
                echo ' <a href="' . esc_url( get_permalink( $post_page ) ) . '" itemprop="item">' . esc_html( $p->post_title ) . '</a> ' . $delimiter;  
            }
            
            if ( $thisCat->parent != 0 ) echo get_category_parents( $thisCat->parent, TRUE, $delimiter );
            echo $before .  esc_html( single_cat_title( '', false ) ) . $after;
        
        }elseif( rara_business_pro_is_woocommerce_activated() && ( is_product_category() || is_product_tag() ) ){ //For Woocommerce archive page
        
            $current_term = $GLOBALS['wp_query']->get_queried_object();
            
            if ( wc_get_page_id( 'shop' ) ) { //Displaying Shop link in woocommerce archive page
    			$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
                if ( ! $_name ) {
        			$product_post_type = get_post_type_object( 'product' );
        			$_name = $product_post_type->labels->singular_name;
        		}
                echo ' <a href="' . esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ) . '" itemprop="item">' . esc_html( $_name ) . '</a> ' . $delimiter;
    		}

            if( is_product_category() ){
                $ancestors = get_ancestors( $current_term->term_id, 'product_cat' );
                $ancestors = array_reverse( $ancestors );
        		foreach ( $ancestors as $ancestor ) {
        			$ancestor = get_term( $ancestor, 'product_cat' );    
        			if ( ! is_wp_error( $ancestor ) && $ancestor ) {
        				echo ' <a href="' . esc_url( get_term_link( $ancestor ) ) . '" itemprop="item">' . esc_html( $ancestor->name ) . '</a> ' . $delimiter;
        			}
        		}
            }           
            echo $before . esc_html( $current_term->name ) . $after;
            
        }elseif( rara_business_pro_is_woocommerce_activated() && is_shop() ){ //Shop Archive page
            if ( get_option( 'page_on_front' ) == wc_get_page_id( 'shop' ) ) {
    			return;
    		}
    		$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
    
    		if ( ! $_name ) {
    			$product_post_type = get_post_type_object( 'product' );
    			$_name = $product_post_type->labels->singular_name;
    		}
            echo $before . esc_html( $_name ) . $after;
            
        }elseif( is_tag() ){
            
            echo $before . esc_html( single_tag_title( '', false ) ) . $after;
     
        }elseif( is_author() ){
            
            global $author;
            $userdata = get_userdata( $author );
            echo $before . esc_html( $userdata->display_name ) . $after;
     
        }elseif( is_search() ){
            
            echo $before . esc_html__( 'Search Results', 'rara-business-pro' ) . $after;
        
        }elseif( is_day() ){
            
            echo '<a href="' . esc_url( get_year_link( get_the_time( __( 'Y', 'rara-business-pro' ) ) ) ) . '" itemprop="item">' . esc_html( get_the_time( __( 'Y', 'rara-business-pro' ) ) ) . '</a> ' . $delimiter;
            echo '<a href="' . esc_url( get_month_link( get_the_time( __( 'Y', 'rara-business-pro' ) ), get_the_time( __( 'm', 'rara-business-pro' ) ) ) ) . '" itemprop="item">' . esc_html( get_the_time( __( 'F', 'rara-business-pro' ) ) ) . '</a> ' . $delimiter;
            echo $before . esc_html( get_the_time( __( 'd', 'rara-business-pro' ) ) ) . $after;
        
        }elseif( is_month() ){
            
            echo '<a href="' . esc_url( get_year_link( get_the_time( __( 'Y', 'rara-business-pro' ) ) ) ) . '" itemprop="item">' . esc_html( get_the_time( __( 'Y', 'rara-business-pro' ) ) ) . '</a> ' . $delimiter;
            echo $before . esc_html( get_the_time( __( 'F', 'rara-business-pro' ) ) ) . $after;
        
        }elseif( is_year() ){
            
            echo $before . esc_html( get_the_time( __( 'Y', 'rara-business-pro' ) ) ) . $after;
    
        }elseif( is_single() && !is_attachment() ){
            
            if( rara_business_pro_is_woocommerce_activated() && 'product' === get_post_type() ){ //For Woocommerce single product
        		
        		if ( wc_get_page_id( 'shop' ) ) { //Displaying Shop link in woocommerce archive page
	    			$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
	                if ( ! $_name ) {
	        			$product_post_type = get_post_type_object( 'product' );
	        			$_name = $product_post_type->labels->singular_name;
	        		}
	                echo ' <a href="' . esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ) . '" itemprop="item">' . esc_html( $_name ) . '</a> ' . $delimiter;
	    		}
    		
                if ( $terms = wc_get_product_terms( $post->ID, 'product_cat', array( 'orderby' => 'parent', 'order' => 'DESC' ) ) ) {
        			$main_term = apply_filters( 'woocommerce_breadcrumb_main_term', $terms[0], $terms );
        			$ancestors = get_ancestors( $main_term->term_id, 'product_cat' );
                    $ancestors = array_reverse( $ancestors );
            		foreach ( $ancestors as $ancestor ) {
            			$ancestor = get_term( $ancestor, 'product_cat' );    
            			if ( ! is_wp_error( $ancestor ) && $ancestor ) {
            				echo ' <a href="' . esc_url( get_term_link( $ancestor ) ) . '" itemprop="item">' . esc_html( $ancestor->name ) . '</a> ' . $delimiter;
            			}
            		}
        			echo ' <a href="' . esc_url( get_term_link( $main_term ) ) . '" itemprop="item">' . esc_html( $main_term->name ) . '</a> ' . $delimiter;
        		}
                
                echo $before . esc_html( get_the_title() ) . $after;
                
            }elseif( get_post_type() != 'post' ){
                
                $post_type = get_post_type_object( get_post_type() );
                
                if( $post_type->has_archive == true ){// For CPT Archive Link
                   
                   // Add support for a non-standard label of 'archive_title' (special use case).
                   $label = !empty( $post_type->labels->archive_title ) ? $post_type->labels->archive_title : $post_type->labels->name;
                   printf( '<a href="%1$s" itemprop="item">%2$s</a>', esc_url( get_post_type_archive_link( get_post_type() ) ), $label );
                   echo $delimiter;
    
                }
                echo $before . esc_html( get_the_title() ) . $after;
                
            }else{ //For Post
                
                $cat_object       = get_the_category();
                $potential_parent = 0;
                
                if( $show_front === 'page' && $post_page ){ //If static blog post page is set
                    $p = get_post( $post_page );
                    echo ' <a href="' . esc_url( get_permalink( $post_page ) ) . '" itemprop="item">' . esc_html( $p->post_title ) . '</a> ' . $delimiter;  
                }
                
                if( $cat_object ){ //Getting category hierarchy if any
        			//Now try to find the deepest term of those that we know of
        			$use_term = key( $cat_object );
        			foreach( $cat_object as $key => $object )
        			{
        				//Can't use the next($cat_object) trick since order is unknown
        				if( $object->parent > 0  && ( $potential_parent === 0 || $object->parent === $potential_parent ) ){
        					$use_term = $key;
        					$potential_parent = $object->term_id;
        				}
        			}
                    
        			$cat = $cat_object[$use_term];
              
                    $cats = get_category_parents( $cat, TRUE, $delimiter );
                    $cats = preg_replace( "#^(.+)\s$delimiter\s$#", "$1", $cats ); //NEED TO CHECK THIS
                    echo $cats;
                }
    
                echo $before . esc_html( get_the_title() ) . $after;
                
            }
        
        }elseif( !is_single() && !is_page() && get_post_type() != 'post' && !is_404() ){
            
            $post_type = get_post_type_object(get_post_type());

            if( ! is_null(  $post_type ) ){
                if( get_query_var('paged') ){
                    echo '<a href="' . esc_url( get_post_type_archive_link( $post_type->name ) ) . '" itemprop="item">' . esc_html( $post_type->label ) . '</a>';
                    /* translators: %s: paged number  */
                    echo $delimiter . $before . sprintf( __('Page %s', 'rara-business-pro' ), get_query_var('paged') ) . $after;
                }else{
                    echo $before . esc_html( $post_type->label ) . $after;
                }
            }else{
                echo $before . esc_html( get_the_archive_title() ) . $after;
            }
    
    
        }elseif( is_attachment() ){
            
            $parent = get_post( $post->post_parent );
            $cat = get_the_category( $parent->ID ); 
            if( $cat ){
                $cat = $cat[0];
                echo get_category_parents( $cat, TRUE, $delimiter );
                echo '<a href="' . esc_url( get_permalink( $parent ) ) . '" itemprop="item">' . esc_html( $parent->post_title ) . '</a>' . ' <span class="separator">' . esc_html( $delimiter ) . '</span> ';
            }
            echo  $before . esc_html( get_the_title() ) . $after;
        
        }elseif( is_page() && !$post->post_parent ){
            
            echo $before . esc_html( get_the_title() ) . $after;
    
        }elseif( is_page() && $post->post_parent ){
            
            $parent_id  = $post->post_parent;
            $breadcrumbs = array();
            
            while( $parent_id ){
                $page = get_post( $parent_id );
                $breadcrumbs[] = '<a href="' . esc_url( get_permalink( $page->ID ) ) . '" itemprop="item">' . esc_html( get_the_title( $page->ID ) ) . '</a>';
                $parent_id  = $page->post_parent;
            }
            $breadcrumbs = array_reverse( $breadcrumbs );
            for ( $i = 0; $i < count( $breadcrumbs) ; $i++ ){
                echo $breadcrumbs[$i];
                if ( $i != count( $breadcrumbs ) - 1 ) echo $delimiter;
            }
            echo $delimiter . $before . esc_html( get_the_title() ) . $after;
        
        }elseif( is_404() ){
            echo $before . esc_html__( '404 Error Page', 'rara-business-pro' ) . $after;
        }
        
        if( get_query_var('paged') ) echo __( ' (Page', 'rara-business-pro' ) . ' ' . get_query_var('paged') . __( ')', 'rara-business-pro' );
        
        echo '</div></div><!-- .breadcrumb-wrapper -->';
        
    }                
}
endif;
add_action( 'rara_business_pro_before_posts_content', 'rara_business_pro_breadcrumb', 15 );

if( ! function_exists( 'rara_business_pro_page_header' ) ) :
/**
 * Page Header
*/
function rara_business_pro_page_header(){
    global $wp_query, $post;
    
    if( is_search() ){     
        echo '<header class="page-header">'; ?>    
            <h1 class="page-title">
            <?php
                /* translators: %s: search query. */
                printf( esc_html__( 'Search Results for: %s', 'rara-business-pro' ), get_search_query() );
            ?>
            </h1>
            <span><?php printf( esc_html__( 'We found %1s results for %2s. You can search again if you are unsatisfied.', 'rara-business-pro' ), number_format_i18n( $wp_query->found_posts ),get_search_query() ); ?></span>
            <?php get_search_form();
        echo '</header><!-- .page-header -->';
    }
    
    if( is_archive() ){ 
        echo '<header class="page-header">';
            the_archive_title( '<h1 class="page-title">', '</h1>' );
            the_archive_description( '<div class="archive-description">', '</div>' );
        echo '</header><!-- .page-header -->';
    }
    
    if( is_page() ){ 
        echo '<header class="page-header">';
            if( is_page_template( array( 'templates/portfolio.php', 'templates/contact.php', 'templates/faq.php', 'templates/team.php', 'templates/testimonial.php' ) ) ){
                the_title( '<h2 class="page-title">', '</h1>' );

                if( ! empty( $post->post_excerpt ) ){
                    echo wpautop( wp_kses_post( $post->post_excerpt ) );
                }else{
                    echo wpautop( wp_kses_post( $post->post_content ) );
                } 
            }else{
                the_title( '<h1 class="page-title">', '</h1>' );
            }
        echo '</header><!-- .page-header -->';
    }

    if( is_singular( 'rara-portfolio' ) ) {
        echo '<header class="page-header">';
            the_title( '<h1 class="page-title">', '</h1>' );
        echo '</header><!-- .page-header -->';
    }
    
}
endif;
add_action( 'rara_business_pro_before_posts_content', 'rara_business_pro_page_header', 20 );

if( ! function_exists( 'rara_business_pro_entry_header' ) ) :
/**
 * Entry Header
*/
function rara_business_pro_entry_header(){ 
    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $post_entry_meta = get_theme_mod( 'post_meta_order', $default_options['post_meta_order'] ); ?>
    <header class="entry-header">
		<?php
		if ( 'post' === get_post_type() ){ ?>
		<div class="entry-meta">
			<?php 
                foreach( $post_entry_meta as $meta ){
                    if( $meta === 'date' ) rara_business_pro_posted_on();
                    if( $meta === 'author' ) rara_business_pro_posted_by();
                }
            ?>
		</div><!-- .entry-meta -->
		<?php
		}
        
        if( is_singular() ){
            the_title( '<h2 class="entry-title">', '</h2>' );
        }else{
            the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
        }
        
        if( is_single() ) {
            rara_business_pro_categories();
            rara_business_pro_social_share( true );
        }
        ?>
	</header><!-- .entry-header -->
    <?php
}
endif;
add_action( 'rara_business_pro_posts_entry_content', 'rara_business_pro_entry_header', 15 );
add_action( 'rara_business_pro_post_entry_content', 'rara_business_pro_entry_header', 20 );

if ( ! function_exists( 'rara_business_pro_post_thumbnail' ) ) :
/**
 * Displays an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index views, or a div
 * element when on single views.
 */
function rara_business_pro_post_thumbnail() {
    $default_options     = rara_business_pro_default_theme_options(); // Get default theme options
    $show_post_thumbnail = get_theme_mod( 'ed_featured_image', $default_options['ed_featured_image'] );

	if ( is_singular() ) {
        if ( has_post_thumbnail() && $show_post_thumbnail ) { ?>
            <div class="post-thumbnail">
                <?php the_post_thumbnail( 'rara-business-featured' ); ?>
            </div><!-- .post-thumbnail -->
        <?php
        }
    } else { ?>

	<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
		<?php
			the_post_thumbnail( 'rara-business-featured', array(
				'alt' => the_title_attribute( array(
					'echo' => false,
				) ),
			) );
		?>
	</a>

	<?php }; // End is_singular().
}
endif;
add_action( 'rara_business_pro_posts_entry_content', 'rara_business_pro_post_thumbnail', 20 );
add_action( 'rara_business_pro_page_entry_content', 'rara_business_pro_post_thumbnail', 15 );
add_action( 'rara_business_pro_post_entry_content', 'rara_business_pro_post_thumbnail', 15 );

if( ! function_exists( 'rara_business_pro_entry_content' ) ) :
/**
 * Entry Content
*/
function rara_business_pro_entry_content(){
    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $ed_excerpt      = get_theme_mod( 'ed_excerpt', $default_options['ed_excerpt'] ); ?>
    <div class="entry-content" itemprop="text">
		<?php
			if( is_singular() || ! $ed_excerpt || ( get_post_format() != false ) ){
                the_content();
    
    			wp_link_pages( array(
    				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'rara-business-pro' ),
    				'after'  => '</div>',
    			) );
            }else{
                the_excerpt();
            }
		?>
	</div><!-- .entry-content -->
    <?php
}
endif;
add_action( 'rara_business_pro_posts_entry_content', 'rara_business_pro_entry_content', 25 );
add_action( 'rara_business_pro_page_entry_content', 'rara_business_pro_entry_content', 20 );
add_action( 'rara_business_pro_post_entry_content', 'rara_business_pro_entry_content', 25 );

if( ! function_exists( 'rara_business_pro_entry_footer' ) ) :
/**
 * Entry Footer 
*/
function rara_business_pro_entry_footer(){ 
    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $readmore        = get_theme_mod( 'read_more_text', $default_options['read_more_text'] ); ?>
    <footer class="entry-footer">
		<?php 
        if( is_singular() ){
            if( is_single() ){
                rara_business_pro_social_share();
                rara_business_pro_tags();
            }
        }elseif( $readmore ){
            echo '<a href="' . esc_url( get_the_permalink() ) . '" class="btn-readmore">' . esc_html( $readmore ) . '</a>';
        }
        
        if( get_edit_post_link() ){
            edit_post_link(
        		sprintf(
        			wp_kses(
        				/* translators: %s: Name of current post. Only visible to screen readers */
        				__( 'Edit <span class="screen-reader-text">%s</span>', 'rara-business-pro' ),
        				array(
        					'span' => array(
        						'class' => array(),
        					),
        				)
        			),
        			get_the_title()
        		),
        		'<span class="edit-link">',
        		'</span>'
        	); 
        }
        ?>
	</footer><!-- .entry-footer -->
    <?php
}
endif;
add_action( 'rara_business_pro_posts_entry_content', 'rara_business_pro_entry_footer', 30 );
add_action( 'rara_business_pro_page_entry_content', 'rara_business_pro_entry_footer', 25 );
add_action( 'rara_business_pro_post_entry_content', 'rara_business_pro_entry_footer', 30 );

if( ! function_exists( 'rara_business_pro_author' ) ) :
/**
 * Author Section
*/
function rara_business_pro_author(){ 
    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $ed_author       = get_theme_mod( 'ed_author', $default_options['ed_author'] ); 

    if( ! $ed_author && get_the_author_meta( 'description' ) ){ ?>
    <div class="author-section">
		<div class="img-holder"><?php echo get_avatar( get_the_author_meta( 'ID' ), 170 ); ?></div>
		<div class="text-holder">
			<h3 class="name"><?php echo esc_html( get_the_author_meta( 'display_name' ) ); ?></h3>
			<?php 
                echo wpautop( wp_kses_post( get_the_author_meta( 'description' ) ) );
                rara_business_pro_author_social();
            ?>            
		</div>
	</div>
    <?php
    }
}
endif;
add_action( 'rara_business_pro_after_post_content', 'rara_business_pro_author', 15 );
add_action( 'rara_business_pro_after_protfolio_post_content', 'rara_business_pro_author', 10 );

if( ! function_exists( 'rara_business_pro_pagination' ) ) :
/**
 * Paginations
*/
function rara_business_pro_pagination(){
    /** Load default theme options */
    $default_options = rara_business_pro_default_theme_options();
    $pagination      = get_theme_mod( 'pagination_type', $default_options['pagination_type'] );

    if( is_single() ){
        $previous = get_previous_post_link(
    		'<div class="nav-previous">%link</div>',
    		esc_html__( 'Prev Post', 'rara-business-pro' ) . '<span class="nav-arrow"><i class="fa fa-angle-left"></i></span><span>%title</span>',
    		false,
    		'',
    		'category'
    	);
    
    	$next = get_next_post_link(
    		'<div class="nav-next">%link</div>',
    		esc_html__( 'Next Post', 'rara-business-pro' ) . '<span class="nav-arrow"><i class="fa fa-angle-right"></i></span><span>%title</span>',
    		false,
    		'',
    		'category'
    	); 
        
        if( $previous || $next ){?>            
            <nav class="navigation post-navigation" role="navigation">
    			<h2 class="screen-reader-text"><?php esc_html_e( 'Post Navigation', 'rara-business-pro' ); ?></h2>
    			<div class="nav-links">
    				<?php
                        if( $previous ) echo $previous;
                        if( $next ) echo $next;
                    ?>
    			</div>
    		</nav>        
            <?php
        }
    }else{
        switch( $pagination ){
            case 'default': // Default Pagination
                the_posts_navigation();
            break;
            
            case 'numbered': // Numbered Pagination
                the_posts_pagination( array(
                    'prev_next'          => false,
                    'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'rara-business-pro' ) . ' </span>',
                ) );
            break;
            
            case 'load_more': // Load More Button
            case 'infinite_scroll': // Auto Infinite Scroll
                echo '<div class="pagination"></div>';
            break;
        }   
    }
}
endif;
add_action( 'rara_business_pro_after_post_content', 'rara_business_pro_pagination', 20 );
add_action( 'rara_business_pro_after_posts_content', 'rara_business_pro_pagination' );
add_action( 'rara_business_pro_after_protfolio_post_content', 'rara_business_pro_pagination', 20 );

if( ! function_exists( 'rara_business_pro_related_posts' ) ) :
/**
 * Related Posts
*/
function rara_business_pro_related_posts(){ 
    global $post;

    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $ed_related_post = get_theme_mod( 'ed_related', $default_options['ed_related'] );
    $related_title   = get_theme_mod( 'related_post_title', $default_options['related_post_title'] ); 
    if( $ed_related_post ){
        $args = array(
            'post_type'           => 'post',
            'post_status'         => 'publish',
            'posts_per_page'      => 4,
            'ignore_sticky_posts' => true,
            'post__not_in'        => array( $post->ID ),
            'orderby'             => 'rand'
        );
        $cats = get_the_category( $post->ID );
        if( $cats ){
            $c = array();
            foreach( $cats as $cat ){
                $c[] = $cat->term_id; 
            }
            $args['category__in'] = $c;
        }
        
        $qry = new WP_Query( $args );
        
        if( $qry->have_posts() ){ ?>
        <section class="related-post">
    		<?php if( $related_title ) echo '<h2 class="section-title">' . esc_html( $related_title ) . '</h2>'; ?>
    		<div class="grid">
    			<?php 
                while( $qry->have_posts() ){ 
                    $qry->the_post(); ?>
                    <div class="col">
    					<a href="<?php the_permalink(); ?>" class="post-thumbnail">
                        <?php
                            if( has_post_thumbnail() ){
                                the_post_thumbnail( 'rara-business-blog' );
                            }else{ ?>
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/images/rara-business-blog.jpg' ); ?>" alt="<?php the_title_attribute(); ?>" />
                            <?php 
                            }
                        ?>
                        </a>
    					
						<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
    					
        			</div>
        			<?php 
                }
                wp_reset_postdata();  
                ?>
    		</div>
    	</section>
        <?php
        }
    }
}
endif;
add_action( 'rara_business_pro_after_post_content', 'rara_business_pro_related_posts', 25 );

if( ! function_exists( 'rara_business_pro_popular_posts' ) ) :
/**
 * Popular Posts
*/
function rara_business_pro_popular_posts(){ 
    global $post;

    $default_options = rara_business_pro_default_theme_options(); // Get default theme options
    $ed_popular_post = get_theme_mod( 'ed_popular_posts', $default_options['ed_popular_posts'] );
    $popular_title   = get_theme_mod( 'popular_post_title', $default_options['popular_post_title'] ); 
    if( $ed_popular_post ){
        $args = array(
            'post_type'           => 'post',
            'post_status'         => 'publish',
            'posts_per_page'      => 4,
            'ignore_sticky_posts' => true,
            'post__not_in'        => array( $post->ID ),
            'orderby'             => 'comment_count'
        );

        $qry = new WP_Query( $args );
        
        if( $qry->have_posts() ){ ?>
        <section class="popular-post">
    		<?php if( $popular_title ) echo '<h2 class="section-title">' . esc_html( $popular_title ) . '</h2>'; ?>
    		<div class="grid">
    			<?php 
                while( $qry->have_posts() ){ 
                    $qry->the_post(); ?>
                    <div class="col">        				
    					<a href="<?php the_permalink(); ?>" class="post-thumbnail">
                        <?php
                            if( has_post_thumbnail() ){
                                the_post_thumbnail( 'rara-business-blog' );
                            }else{ ?>
                                <img src="<?php echo esc_url( get_template_directory_uri() . '/images/rara-business-blog.jpg' ); ?>" alt="<?php the_title_attribute(); ?>" />
                            <?php 
                            }
                        ?>
                        </a>
    					
						<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>    					
        				
        			</div>
        			<?php 
                }
                wp_reset_postdata();  
                ?>
    		</div>
    	</section>
        <?php
        }
    }
}
endif;
add_action( 'rara_business_pro_after_post_content', 'rara_business_pro_popular_posts', 30 );
 
if( ! function_exists( 'rara_business_pro_comment' ) ) :
/**
 * Comments
*/
function rara_business_pro_comment(){
    /** Load default theme options */
    $default_options = rara_business_pro_default_theme_options();
    $show_comments   = get_theme_mod( 'ed_comments', $default_options['ed_comments'] );

    // If comments are open or we have at least one comment, load up the comment template.
	if ( ( comments_open() || get_comments_number() ) && $show_comments ) :
		comments_template();
	endif;
}
endif;
add_action( 'rara_business_pro_after_page_content', 'rara_business_pro_comment' );
add_action( 'rara_business_pro_after_post_content', 'rara_business_pro_comment', 35 );

if( ! function_exists( 'rara_business_pro_recent_posts' ) ) :
/**
 * Recent Posts
*/
function rara_business_pro_recent_posts(){ 
    $args = array(
        'post_type'           => 'post',
        'posts_per_page'      => 6,
        'posts_status'        => 'publish',
        'ignore_sticky_posts' => true
    );
    
    $qry = new WP_Query( $args );
    
    if( $qry->have_posts() ){ ?>
    <section class="recent-post">
		<h2 class="section-title"><?php esc_html_e( 'Recent Posts', 'rara-business-pro' ); ?></h2>
		<div class="grid">
			<?php 
            while( $qry->have_posts() ){ 
                $qry->the_post(); ?>
                <div class="col">    				
                    <a href="<?php the_permalink(); ?>" class="post-thumbnail">
                        <?php 
                        if( has_post_thumbnail() ){
                            the_post_thumbnail( 'rara-business-blog' );    
                        }else{
                            echo '<img src="'. esc_url( get_template_directory_uri() ) . '/images/rara-business-blog.jpg' .'" alt="'. esc_attr( get_the_title() ) .'">';    
                        }
                        ?>                        
                    </a>
                    <?php 
                        the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' );
                    ?>    				
    				<div class="entry-meta">
    					<span class="posted-on"><a href="#"><time datetime="2017-12-14">14 Dec, 2017</time></a></span>
    					<span class="separator">/</span>
    					<span class="byline"><a href="#">Bob Wells</a></span>
    				</div>
    			</div>
                <?php 
            }
            wp_reset_postdata();
            ?>
		</div>
	</section>
    <?php
    }
}
endif;
add_action( 'rara_business_pro_recent_post', 'rara_business_pro_recent_posts' );


if( ! function_exists( 'rara_business_pro_content_end' ) ) :
/**
 * Content End
*/
function rara_business_pro_content_end(){ 
    $home_sections = rara_business_pro_get_home_sections();

    if( ! ( is_front_page() && ! is_home() && $home_sections ) ){ 
        if( ! is_404() && ! is_page_template( array( 'templates/portfolio.php', 'templates/contact.php', 'templates/faq.php', 'templates/team.php', 'templates/testimonial.php' ) ) && ! is_tax( 'rara_portfolio_categories' ) ) echo '</div><!-- .content-grid -->'; ?>        
        </div><!-- .container -->
	</div><!-- #content -->
    <?php } 
}
endif;
add_action( 'rara_business_pro_before_footer', 'rara_business_pro_content_end', 20 );

if( ! function_exists( 'rara_business_pro_footer_start' ) ) :
/**
 * Footer Start
*/
function rara_business_pro_footer_start(){
    ?>
    <footer id="colophon" class="site-footer" itemscope itemtype="http://schema.org/WPFooter">
        <div class="container">
    <?php
}
endif;
add_action( 'rara_business_pro_footer', 'rara_business_pro_footer_start', 20 );

if( ! function_exists( 'rara_business_pro_footer_top' ) ) :
/**
 * Footer Top
*/
function rara_business_pro_footer_top(){    
    if( is_active_sidebar( 'footer-one' ) || is_active_sidebar( 'footer-two' ) || is_active_sidebar( 'footer-three' ) || is_active_sidebar( 'footer-four' ) ){ ?>
    <div class="footer-t">		
		<div class="grid">
        <?php if( is_active_sidebar( 'footer-one' ) ){ ?>
			<div class="col">
			   <?php dynamic_sidebar( 'footer-one' ); ?>	
			</div>
        <?php } ?>
		
        <?php if( is_active_sidebar( 'footer-two' ) ){ ?>
            <div class="col">
			   <?php dynamic_sidebar( 'footer-two' ); ?>	
			</div>
        <?php } ?>
        
        <?php if( is_active_sidebar( 'footer-three' ) ){ ?>
            <div class="col">
			   <?php dynamic_sidebar( 'footer-three' ); ?>	
			</div>
        <?php } ?>
        
        <?php if( is_active_sidebar( 'footer-four' ) ){ ?>
            <div class="col">
			   <?php dynamic_sidebar( 'footer-four' ); ?>	
			</div>
        <?php } ?>
        </div>		
	</div>
    <?php 
    }   
}
endif;
add_action( 'rara_business_pro_footer', 'rara_business_pro_footer_top', 30 );

if( ! function_exists( 'rara_business_pro_footer_bottom' ) ) :
/**
 * Footer Bottom
*/
function rara_business_pro_footer_bottom(){ ?>
    <div class="footer-b">		
	<?php
        $default_options  = rara_business_pro_default_theme_options(); // default theme option
        $hide_author_link = get_theme_mod( 'ed_author_link', $default_options['ed_author_link'] );
        $hide_wp_link     = get_theme_mod( 'ed_wp_link', $default_options['ed_wp_link'] );

        rara_business_pro_get_footer_copyright();

        if( ! $hide_author_link ) {
            echo '<span class="by">' . esc_html__( 'Made by ', 'rara-business-pro' ) . '<a href="' . esc_url( 'https://raratheme.com/wordpress-themes/rara-business' ) .'" rel="author" target="_blank">' . esc_html__( ' Rara Themes ', 'rara-business-pro' ) . '</a></span>';
        }

        if( ! $hide_wp_link ){
            printf( esc_html__( '%1$sPowered by %2$s%3$s', 'rara-business-pro' ), '<span class="powered-by">', '<a href="'. esc_url( __( 'https://wordpress.org/', 'rara-business-pro' ) ) .'" target="_blank">WordPress</a>.', '</span>' );
        }

        if ( function_exists( 'the_privacy_policy_link' ) ) {
            the_privacy_policy_link( '<span class="policy_link">', '</span>');
        }
        ?>		
	</div>
    <?php
}
endif;
add_action( 'rara_business_pro_footer', 'rara_business_pro_footer_bottom', 40 );

if( ! function_exists( 'rara_business_pro_footer_end' ) ) :
/**
 * Footer End 
*/
function rara_business_pro_footer_end(){ ?>
        </div><!-- .container -->
    </footer><!-- #colophon -->
    <?php
}
endif;
add_action( 'rara_business_pro_footer', 'rara_business_pro_footer_end', 50 );

if( ! function_exists( 'rara_business_pro_scroll_to_top' ) ) :
    /**
     * Scroll to Top Options
     */  
    function rara_business_pro_scroll_to_top(){
        /** Load default theme options */
        $default_options   = rara_business_pro_default_theme_options();
        $enable_scroll_top = get_theme_mod( 'ed_scroll_to_top', $default_options['ed_scroll_to_top'] );

        if( $enable_scroll_top ){
        ?>
            <div class="to_top">
                <a href="#" class="btn"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" width="15.69" height="18.88" viewBox="0 0 15.69 18.88"><defs><style>.cls-1{fill:#fff;fill-rule:evenodd;}</style></defs><path d="M9.328,17.805 L9.321,17.836 L9.321,5.217 L13.310,9.184 C13.505,9.377 13.768,9.484 14.045,9.484 C14.322,9.484 14.584,9.377 14.779,9.184 L15.399,8.566 C15.594,8.373 15.701,8.113 15.701,7.838 C15.701,7.561 15.594,7.303 15.400,7.109 L8.578,0.309 C8.383,0.114 8.122,0.008 7.845,0.009 C7.567,0.008 7.306,0.114 7.111,0.309 L0.289,7.109 C0.094,7.303 -0.013,7.561 -0.013,7.838 C-0.013,8.113 0.094,8.373 0.289,8.566 L0.908,9.184 C1.103,9.377 1.362,9.484 1.639,9.484 C1.916,9.484 2.162,9.377 2.357,9.184 L6.367,5.172 L6.367,17.820 C6.367,18.388 6.859,18.864 7.429,18.864 L8.305,18.864 C8.875,18.864 9.328,18.373 9.328,17.805 Z" class="cls-1"/></svg>
</a>
            </div>
        <?php
        }
    }
endif;
add_action( 'rara_business_pro_after_footer', 'rara_business_pro_scroll_to_top', 10 );

if( ! function_exists( 'rara_business_pro_page_end' ) ) :
/**
 * Page End
*/
function rara_business_pro_page_end(){
    ?>
    </div><!-- #page -->
    <?php
}
endif;
add_action( 'rara_business_pro_after_footer', 'rara_business_pro_page_end', 20 );