<?php
/**
 * Testimonial Template Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_testimonial_template_panel' ) ) :
	/**
	 * Add testimonial template panel
	 */
	function rara_business_pro_customize_register_testimonial_template_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'testimonial_template_panel', array(
	        'title'          => __( 'Testimonial Template Settings', 'rara-business-pro' ),
	        'priority'       => 50,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_testimonial_template_panel' );