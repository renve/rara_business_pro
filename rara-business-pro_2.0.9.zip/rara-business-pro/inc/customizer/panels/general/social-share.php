<?php
/**
 * General Social Sharing Settings
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_general_sharing' ) ) :
    /**
     * Add social sharing controls
     */
    function rara_business_pro_customize_register_general_sharing( $wp_customize ) {
    	
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Social Sharing */
        $wp_customize->add_section(
            'social_sharing',
            array(
                'title'    => __( 'Social Sharing', 'rara-business-pro' ),
                'priority' => 20,
                'panel'    => 'general_settings_panel',
            )
        );
        
        /** Enable Social Sharing Buttons */
        $wp_customize->add_setting(
            'ed_social_sharing',
            array(
                'default'           => $default_options['ed_social_sharing'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
    		new Rara_Business_Pro_Toggle_Control( 
    			$wp_customize,
    			'ed_social_sharing',
    			array(
    				'section'     => 'social_sharing',
    				'label'       => __( 'Enable Social Sharing Buttons', 'rara-business-pro' ),
                    'description' => __( 'Enable or disable social sharing buttons on single post.', 'rara-business-pro' ),
    			)
    		)
    	);
        
        /** Social Sharing Buttons */
        $wp_customize->add_setting(
    		'social_share', 
    		array(
    			'default' => $default_options['social_share'],
    			'sanitize_callback' => 'rara_business_pro_sanitize_sortable',						
    		)
    	);

    	$wp_customize->add_control(
    		new Rara_Business_Pro_Sortable(
    			$wp_customize,
    			'social_share',
    			array(
    				'section'     => 'social_sharing',
    				'label'       => __( 'Social Sharing Buttons', 'rara-business-pro' ),
    				'description' => __( 'Sort or toggle social sharing buttons.', 'rara-business-pro' ),
    				'choices'     => array(
                		'facebook'  => __( 'Facebook', 'rara-business-pro' ),
                		'twitter'   => __( 'Twitter', 'rara-business-pro' ),
                		'linkedin'  => __( 'LinkedIn', 'rara-business-pro' ),
                		'pinterest' => __( 'Pinterest', 'rara-business-pro' ),
                		'email'     => __( 'Email', 'rara-business-pro' ),
                		'gplus'     => __( 'Google Plus', 'rara-business-pro' ),
                        'stumble'   => __( 'StumbleUpon', 'rara-business-pro' ),
                        'tumblr'    => __( 'Tumblr', 'rara-business-pro' ),            
                        'digg'      => __( 'Digg', 'rara-business-pro' ),            
                        'weibo'     => __( 'Weibo', 'rara-business-pro' ),            
                        'xing'      => __( 'Xing', 'rara-business-pro' ),            
                        'vk'        => __( 'VK', 'rara-business-pro' ),            
                        'pocket'    => __( 'Pocket', 'rara-business-pro' ),            
                	),
                    'active_callback' => 'rara_business_pro_social_share_ac',
    			)
    		)
    	);
        
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_general_sharing' );

if ( ! function_exists( 'rara_business_pro_social_share_ac' ) ) :
    /**
    * Active callback function for social share
    */
    function rara_business_pro_social_share_ac( $control ) {
        $enable_shocial_share = $control->manager->get_setting( 'ed_social_sharing' )->value();
        $control_id           = $control->id;

        if ( $control_id == 'social_share' && $enable_shocial_share ) return true;
        
        return false;
    }
endif;