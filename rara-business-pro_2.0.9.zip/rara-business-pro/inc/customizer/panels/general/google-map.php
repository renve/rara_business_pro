<?php
/**
 * Google Map Settings
 *
 * @package Rara_Business_Pro
 */

function rara_business_pro_customize_register_contact_map( $wp_customize ) {
    /** Load default theme options */
    $default_options =  rara_business_pro_default_theme_options();

    /** Google Map Settings */
    $wp_customize->add_section(
        'google_map_settings',
        array(
            'title'    => __( 'Google Map Settings', 'rara-business-pro' ),
            'priority' => 30,
            'panel'    => 'general_settings_panel',
        )
    );
    
    /** Enable Scrolling Wheel */
    $wp_customize->add_setting(
        'ed_map_scroll',
        array(
            'default'           => $default_options['ed_map_scroll'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_map_scroll',
			array(
				'section'	  => 'google_map_settings',
				'label'		  => __( 'Enable Scrolling Wheel', 'rara-business-pro' ),
				'description' => __( 'Zoom map on Scrolling.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Enable Map Controls */
    $wp_customize->add_setting(
        'ed_map_controls',
        array(
            'default'           => $default_options['ed_map_controls'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_map_controls',
			array(
				'section'	  => 'google_map_settings',
				'label'		  => __( 'Enable Map Controls', 'rara-business-pro' ),
				'description' => __( 'Controls icons that appears above Map.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Enable Map Marker */
    $wp_customize->add_setting(
        'ed_map_marker',
        array(
            'default'           => $default_options['ed_map_marker'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_map_marker',
			array(
				'section'	  => 'google_map_settings',
				'label'		  => __( 'Enable Map Marker', 'rara-business-pro' ),
				'description' => __( 'Marker icons that appears above Map.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Marker Title  */
    $wp_customize->add_setting(
        'marker_title',
        array(
            'default'           => $default_options['marker_title'],
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_control(
        'marker_title',
        array(
            'label'           => __( 'Marker Title', 'rara-business-pro' ),
            'description'     => __( 'Enter the Marker Title.', 'rara-business-pro' ),
            'section'         => 'google_map_settings',
            'active_callback' => 'rara_business_pro_google_map_ac'
        )
    );
    
    /** Google Map API Key  */
    $wp_customize->add_setting(
        'map_api',
        array(
            'default'           => $default_options['map_api'],
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    
    $wp_customize->add_control(
        'map_api',
        array(
            'label'       => __( 'Google Map API Key', 'rara-business-pro' ),
            'description' => sprintf( __( 'Enter the google map api key here. You can get API key from %1$shere.%2$s', 'rara-business-pro' ), '<a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">', '</a>' ),
            'section'     => 'google_map_settings',
        )
    );
    
    /** Latitude  */
    $wp_customize->add_setting(
        'latitude',
        array(
            'default'           => $default_options['latitude'],
            'sanitize_callback' => 'rara_business_pro_sanitize_number_floatval',
        )
    );
    
    $wp_customize->add_control(
        'latitude',
        array(
            'label'       => __( 'Latitude', 'rara-business-pro' ),
            'description' => __( 'Enter the Latitude of your location.', 'rara-business-pro' ),
            'section'     => 'google_map_settings',
            'type'        => 'number',                        
        )
    );
    
    /** Longitude  */
    $wp_customize->add_setting(
        'longitude',
        array(
            'default'           => $default_options['longitude'],
            'sanitize_callback' => 'rara_business_pro_sanitize_number_floatval',
        )
    );
    
    $wp_customize->add_control(
        'longitude',
        array(
            'label'       => __( 'Longitude', 'rara-business-pro' ),
            'description' => __( 'Enter the Longitude of your location.', 'rara-business-pro' ),
            'section'     => 'google_map_settings',
            'type'        => 'number',                        
        )
    );
    
    /** Zoom Level */
    $wp_customize->add_setting(
		'map_zoom',
		array(
			'default'			=> $default_options['map_zoom'],
			'sanitize_callback' => 'rara_business_pro_sanitize_select'
		)
	);
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Slider_Control( 
			$wp_customize,
			'map_zoom',
			array(
				'section' => 'google_map_settings',
				'label'	  => __( 'Zoom Level', 'rara-business-pro' ),
				'choices' => array(
					'min' 	=> 1,
					'max' 	=> 19,
					'step'	=> 1,
				)
			)
		)
	);
        
}
add_action( 'customize_register', 'rara_business_pro_customize_register_contact_map' );

/**
 * Active Callback for map marker
*/
function rara_business_pro_google_map_ac( $control ){
    
    $ed_marker  = $control->manager->get_setting( 'ed_map_marker' )->value();
    $control_id = $control->id;
    
    if( $control_id == 'marker_title' && $ed_marker ) return true;

    return false;
}