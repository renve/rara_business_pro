<?php
/**
 * Performance Settings
 *
 * @package Rara_Business_Pro
 */

function rara_business_pro_customize_register_general_performance( $wp_customize ) {
    
    /** Performance Settings */
    $wp_customize->add_section(
        'performance_settings',
        array(
            'title'    => __( 'Performance Settings', 'rara-business-pro' ),
            'priority' => 40,
            'panel'    => 'general_settings_panel',
        )
    );
    
    /** Lazy Load */
    $wp_customize->add_setting(
        'ed_lazy_load',
        array(
            'default'           => false,
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_lazy_load',
			array(
				'section'		=> 'performance_settings',
				'label'			=> __( 'Lazy Load', 'rara-business-pro' ),
				'description'	=> __( 'Enable lazy loading of featured images.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Lazy Load Content Images */
    $wp_customize->add_setting(
        'ed_lazy_load_cimage',
        array(
            'default'           => false,
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_lazy_load_cimage',
			array(
				'section'		=> 'performance_settings',
				'label'			=> __( 'Lazy Load Content Images', 'rara-business-pro' ),
				'description'	=> __( 'Enable lazy loading of images inside page/post content.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Defer JavaScript */
    $wp_customize->add_setting(
        'ed_defer',
        array(
            'default'           => false,
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_defer',
			array(
				'section'		=> 'performance_settings',
				'label'			=> __( 'Defer JavaScript', 'rara-business-pro' ),
				'description'	=> __( 'Adds "defer" attribute to script tags to improve page download speed.', 'rara-business-pro' ),
			)
		)
	);
    
    /** Sticky Header */
    $wp_customize->add_setting(
        'ed_ver',
        array(
            'default'           => false,
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
		new Rara_Business_Pro_Toggle_Control( 
			$wp_customize,
			'ed_ver',
			array(
				'section'		=> 'performance_settings',
				'label'			=> __( 'Remove ver parameters', 'rara-business-pro' ),
				'description'	=> __( 'Enable to remove "ver" parameter from CSS and JS file calls.', 'rara-business-pro' ),
			)
		)
	);
    
}
add_action( 'customize_register', 'rara_business_pro_customize_register_general_performance' );