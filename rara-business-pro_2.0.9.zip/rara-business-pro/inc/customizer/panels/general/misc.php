<?php
/**
 * Miscellaneous Settings
 *
 * @package Rara_Business_Pro
 */


if ( ! function_exists( 'rara_business_pro_customize_register_general_misc' ) ) :
    /**
     * Add miscellaneous controls
     */
    function rara_business_pro_customize_register_general_misc( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Miscellaneous Settings */
        $wp_customize->add_section(
            'misc_settings',
            array(
                'title'    => __( 'Misc Settings', 'rara-business-pro' ),
                'priority' => 35,
                'panel'    => 'general_settings_panel',
            )
        );
        
        /** Admin Bar */
        $wp_customize->add_setting(
            'ed_adminbar',
            array(
                'default'           => $default_options['ed_adminbar'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_adminbar',
                array(
                    'section'       => 'misc_settings',
                    'label'         => __( 'Admin Bar', 'rara-business-pro' ),
                    'description'   => __( 'Disable to hide Admin Bar in frontend when logged in.', 'rara-business-pro' ),
                )
            )
        );
        
         /** Admin Bar */
        $wp_customize->add_setting(
            'ed_animation',
            array(
                'default'           => $default_options['ed_animation'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_animation',
                array(
                    'section'       => 'misc_settings',
                    'label'         => __( 'Enable/Disable Animation', 'rara-business-pro' ),
                    'description'   => __( 'Disable Animation', 'rara-business-pro' ),
                )
            )
        );

        /** Sticky Header */
        $wp_customize->add_setting(
            'ed_sticky_header',
            array(
                'default'           => $default_options['ed_sticky_header'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_sticky_header',
                array(
                    'section'       => 'misc_settings',
                    'label'         => __( 'Sticky Header', 'rara-business-pro' ),
                    'description'   => __( 'Enable to stick header at top.', 'rara-business-pro' ),
                )
            )
        );

        /** Scroll to top */
        $wp_customize->add_setting( 'ed_scroll_to_top', array(
            'default'           => $default_options['ed_scroll_to_top'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        ) );

        $wp_customize->add_control( 
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_scroll_to_top', 
                array(
                    'label'             => __( 'Enable Scroll to Top.', 'rara-business-pro' ),
                    'section'           => 'misc_settings',
                )
            )
        );

    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_general_misc' );

function rara_business_pro_scroll_to_top_ac( $control ){
    $ed_scroll_to_top = $control->manager->get_setting( 'ed_scroll_to_top' )->value();
    $control_id       = $control->id;

    if ( $control_id == 'scroll_to_top_icon' && $ed_scroll_to_top ) return true;

    return false;
}