<?php
/**
 * Child Theme Support Settings
 *
 * @package Rara_Business_Pro
 */

function rara_business_pro_customize_register_general_child_support( $wp_customize ) {
    
    /** Load default theme options */
    $default_options =  rara_business_pro_default_theme_options();

    /** Shop Settings */
    $wp_customize->add_section(
        'child_support_settings',
        array(
            'title'    => __( 'Child Theme Support Settings', 'rara-business-pro' ),
            'priority' => 45,
            'panel'    => 'general_settings_panel',
        )
    );

    /** Shop Page Description */
    $wp_customize->add_setting( 
        'child_additional_support', 
        array(
            'default'           => $default_options['child_additional_support'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
        ) 
    );
    
    $wp_customize->add_control(
        new Rara_Business_Pro_Select_Control( 
            $wp_customize,
            'child_additional_support',
            array(
                'section'     => 'child_support_settings',
                'label'       => __( 'Child Theme Style', 'rara-business-pro' ),
                'description' => __( 'Select respective child theme style from the drop-down below.', 'rara-business-pro' ),
                'choices'     => array(
                    'default'       => __( 'Default','rara-business-pro' ),
                    'software_company'  => __( 'Software Company','rara-business-pro' ),
                ),
            )
        )
    );

    /** Note */
    $wp_customize->add_setting(
        'software_company_text',
        array(
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post' 
        )
    );
    
    $wp_customize->add_control(
        new Rara_Business_Pro_Note_Control( 
            $wp_customize,
            'software_company_text',
            array(
                'section'     => 'child_support_settings',
                'description' => sprintf( __( 'To achieve the exact layout of "Software Company" child theme please, select the %1$sHeader Layout Five%2$s.', 'rara-business-pro' ), '<span class="child-inner-link h-layout">', '</span>' ),
                'active_callback' => 'rara_business_pro_child_theme_support_callback',
            )
        )
    );
}
add_action( 'customize_register', 'rara_business_pro_customize_register_general_child_support' );

/**
 * Active Callback
*/
function rara_business_pro_child_theme_support_callback( $control ){
    
    $child_theme_support    = $control->manager->get_setting( 'child_additional_support' )->value();
    $control_id             = $control->id;
    
    if ( $control_id == 'software_company_text' && $child_theme_support == 'software_company' ) return true; 
    return false;
}