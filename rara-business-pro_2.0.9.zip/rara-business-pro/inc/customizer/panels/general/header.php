<?php
/**
 * Header Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_header_section' ) ) :
    /**
     * Add header section controls
     */
    function rara_business_pro_customize_register_header_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Header Section */
        $wp_customize->add_section(
            'header_section',
            array(
                'title'    => __( 'Header Section', 'rara-business-pro' ),
                'priority' => 10,
                'panel'    => 'general_settings_panel',
            )
        );

        /** Header Contact Detail Note */
        $wp_customize->add_setting(
            'header_contact_details_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'header_contact_details_notes',
                array(
                    'section'     => 'header_section',
                    'description' => sprintf( '<hr/><b>%1$s</b>', __( 'Contact Detail Options', 'rara-business-pro' ) ),
                )
            )
        );

        /** Enable header contact details */
        $wp_customize->add_setting( 
            'ed_header_contact_details', 
            array(
                'default'           => $default_options['ed_header_contact_details'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_header_contact_details',
                array(
                    'section'         => 'header_section',
                    'label'           => __( 'Enable Header Contact Details', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show contact details in header top section.', 'rara-business-pro' ),
                )
            )
        );

        /** Phone number  */
        $wp_customize->add_setting(
            'header_phone',
            array(
                'default'           => $default_options['header_phone'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );

        $wp_customize->selective_refresh->add_partial( 'header_phone', array(
            'selector' => '.header-t .phone a.tel-link',
            'render_callback' => 'rara_business_pro_header_phone_selective_refresh',
        ) );
        
        $wp_customize->add_control(
            'header_phone',
            array(
                'label'           => __( 'Phone Number', 'rara-business-pro' ),
                'description'     => __( 'Add phone no. in header.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_header_section_ac'
            )
        );
        
        /** Address  */
        $wp_customize->add_setting(
            'header_address',
            array(
                'default'           => $default_options['header_address'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->selective_refresh->add_partial( 'header_address', array(
            'selector'        => '.header-t .address address',
            'render_callback' => 'rara_business_pro_header_address_selective_refresh',
        ) );

        $wp_customize->add_control(
            'header_address',
            array(
                'label'           => __( 'Address', 'rara-business-pro' ),
                'description'     => __( 'Add address in header.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_header_section_ac'
            )
        );
        
        /** Email */
        $wp_customize->add_setting(
            'header_email',
            array(
                'default'           => $default_options['header_email'],
                'sanitize_callback' => 'sanitize_email',
                'transport'         => 'postMessage'
            )
        );

        $wp_customize->selective_refresh->add_partial( 'header_email', array(
            'selector'        => '.header-t .email a.email-link',
            'render_callback' => 'rara_business_pro_header_email_selective_refresh',
        ) );
        
        $wp_customize->add_control(
            'header_email',
            array(
                'label'           => __( 'Email', 'rara-business-pro' ),
                'description'     => __( 'Add email in header.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_header_section_ac'
            )
        );        

        /** Header Contact Detail Note */
        $wp_customize->add_setting(
            'header_social_link_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'header_social_link_notes',
                array(
                    'section'         => 'header_section',
                    'description'     => sprintf( '<hr/><b>%1$s</b>', __( 'Social Link Options', 'rara-business-pro' ) ),
                )
            )
        );

        /** Enable Social Links */
        $wp_customize->add_setting( 
            'ed_header_social_links', 
            array(
                'default'           => $default_options['ed_header_social_links'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_header_social_links',
                array(
                    'section'     => 'header_section',
                    'label'       => __( 'Enable Social Links', 'rara-business-pro' ),
                    'description' => __( 'Enable to show social links at header.', 'rara-business-pro' ),
                )
            )
        );
        
        $wp_customize->add_setting( 
            new Rara_Business_Pro_Repeater_Setting( 
                $wp_customize, 
                'header_social_links', 
                array(
                    'default' => $default_options['header_social_links'],
                    'sanitize_callback' => array( 'Rara_Business_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),
                ) 
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Control_Repeater(
                $wp_customize,
                'header_social_links',
                array(
                    'section' => 'header_section',               
                    'label'   => __( 'Social Links', 'rara-business-pro' ),
                    'fields'  => array(
                        'font' => array(
                            'type'        => 'font',
                            'label'       => __( 'Font Awesome Icon', 'rara-business-pro' ),
                            'description' => __( 'Example: fa-bell', 'rara-business-pro' ),
                        ),
                        'link' => array(
                            'type'        => 'url',
                            'label'       => __( 'Link', 'rara-business-pro' ),
                            'description' => __( 'Example: http://facebook.com', 'rara-business-pro' ),
                        )
                    ),
                    'row_label' => array(
                        'type'  => 'field',
                        'value' => __( 'links', 'rara-business-pro' ),
                        'field' => 'link'
                    ),
                    'active_callback' => 'rara_business_pro_header_section_ac',                 
                )
            )
        );

        /** Custom Links Note */
        $wp_customize->add_setting(
            'header_custom_link_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'header_custom_link_notes',
                array(
                    'section'     => 'header_section',
                    'description' => sprintf( '<hr/><b>%1$s</b>', __( 'Custom Link Options', 'rara-business-pro' ) ),
                )
            )
        );

        /** Custom Link option */
        $wp_customize->add_setting( 
            'custom_link_option', 
            array(
                'default'           => $default_options['custom_link_option'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio',
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Radio_Buttonset_Control(
                $wp_customize,
                'custom_link_option',
                array(
                    'section'     => 'header_section',
                    'label'       => __( 'Custom Link Option', 'rara-business-pro' ),
                    'description' => __( 'Choose Link as Custom or Page.', 'rara-business-pro' ),
                    'choices'     => array(
                        'custom'   => __( 'Custom', 'rara-business-pro' ),
                        'page'     => __( 'Page', 'rara-business-pro' ),
                    ),
                )
            )
        );

        /** Custom Link Icon  */
        $wp_customize->add_setting(
            'custom_link_icon',
            array(
                'default'           => $default_options['custom_link_icon'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'custom_link_icon',
            array(
                'type'            => 'font',
                'label'           => __( 'Custom Link Icon', 'rara-business-pro' ),
                'description'     => __( 'Insert Icon eg. fa fa-shopping-cart.', 'rara-business-pro' ),
                'section'         => 'header_section',
            )
        );

        /** Custom Link label  */
        $wp_customize->add_setting(
            'custom_link_label',
            array(
                'default'           => $default_options['custom_link_label'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'custom_link_label',
            array(
                'label'           => __( 'Custom Link Label', 'rara-business-pro' ),
                'description'     => __( 'Add cutom link button label in header.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_header_section_ac',
            )
        );

        $wp_customize->selective_refresh->add_partial( 'custom_link_label', array(
            'selector' => '.main-header .right .btn-buy.custom_label',
            'render_callback' => 'rara_business_pro_header_custom_link_label_selective_refresh',
        ) );

        /** Custom Link */
        $wp_customize->add_setting(
            'custom_link',
            array(
                'default'           => $default_options['custom_link'],
                'sanitize_callback' => 'esc_url_raw',
            )
        );
        
        $wp_customize->add_control(
            'custom_link',
            array(
                'label'           => __( 'Custom link Url', 'rara-business-pro' ),
                'description'     => __( 'Add custom link url in header.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'url',
                'active_callback' => 'rara_business_pro_header_section_ac',
            )
        );

        /** Page  */
        $wp_customize->add_setting(
            'custom_link_page',
            array(
                'default'           => $default_options['custom_link_page'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select',
            )
        );
        
        $wp_customize->add_control(
            'custom_link_page',
            array(
                'label'           => __( 'Select Page', 'rara-business-pro' ),
                'description'     => __( 'Page title of selected page will be used as button label.', 'rara-business-pro' ),
                'section'         => 'header_section',
                'type'            => 'select',
                'choices'         => rara_business_pro_get_posts( 'page' ),
                'active_callback' => 'rara_business_pro_header_section_ac',
            )
        );
        
        /** Open Link in new tab */
        $wp_customize->add_setting( 
            'ed_custom_link_tab', 
            array(
                'default'           => $default_options['ed_custom_link_tab'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'ed_custom_link_tab',
                array(
                    'section'         => 'header_section',
                    'label'           => __( 'Open Link in New Tab', 'rara-business-pro' ),
                    'description'     => __( 'Enable to open link in new tab.', 'rara-business-pro' ),
                )
            )
        );

    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_header_section' );

if ( ! function_exists( 'rara_business_pro_header_section_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_header_section_ac( $control ){

        $ed_header_details = $control->manager->get_setting( 'ed_header_contact_details' )->value();
        $ed_social_links   = $control->manager->get_setting( 'ed_header_social_links' )->value();
        $custom_link_type  = $control->manager->get_setting( 'custom_link_option' )->value();

        $control_id    = $control->id;

        // Phone number, Address, Email and Custom Link controls
        if ( $control_id == 'header_phone'  && $ed_header_details ) return true;
        if ( $control_id == 'header_address'  && $ed_header_details ) return true;
        if ( $control_id == 'header_email'  && $ed_header_details ) return true;

        // Social links
        if ( $control_id == 'header_social_links'  && $ed_social_links ) return true;

        // Custom Link
        if ( $control_id == 'custom_link_label'  && 'custom' == $custom_link_type ) return true;
        if ( $control_id == 'custom_link'  && 'custom' == $custom_link_type ) return true;

        if ( $control_id == 'custom_link_page'  && 'page' == $custom_link_type ) return true;

        return false;
    }
endif;