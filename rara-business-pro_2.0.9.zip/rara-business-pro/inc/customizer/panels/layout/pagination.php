<?php
/**
 * Pagination
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_pagination_type' ) ) :
    /**
     * Add pagination controls
     */
    function rara_business_pro_customize_register_pagination_type( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();   

        $wp_customize->add_section( 'pagination_section', array(
            'title'    => __( 'Pagination', 'rara-business-pro' ),
            'priority' => 50,
            'panel'    => 'layout_panel',
        ) );

        /** Pagination Type */
        $wp_customize->add_setting(
            'pagination_type',
            array(
                'default'           => $default_options['pagination_type'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select',
            )
        );
        
        $wp_customize->add_control(
            'pagination_type',
            array(
                'label'       => __( 'Pagination Type', 'rara-business-pro' ),
                'description' => __( 'Select pagination type for archive pages.', 'rara-business-pro' ),
                'section'     => 'pagination_section',
                'type'        => 'radio',
                'choices'     => array(
                    'default'         => __( 'Default (Next / Previous)', 'rara-business-pro' ),
                    'numbered'        => __( 'Numbered (1 2 3 4...)', 'rara-business-pro' ),
                    'load_more'       => __( 'AJAX (Load More Button)', 'rara-business-pro' ),
                    'infinite_scroll' => __( 'AJAX (Auto Infinite Scroll)', 'rara-business-pro' ),
                )
            )
        );

        /** Load More Label */
        $wp_customize->add_setting(
            'load_more_label',
            array(
                'default'           => $default_options['load_more_label'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->selective_refresh->add_partial( 'load_more_label', array(
            'selector'            => '#load-posts a',
            'render_callback'     => 'rara_business_pro_infinite_click_btn_text_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        $wp_customize->add_control(
           'load_more_label',
            array(
                'section' => 'pagination_section',
                'label'   => __( 'Load More Label', 'rara-business-pro' ),
                'type'    => 'text',
                'active_callback' => 'rara_business_pro_loading_ac' 
            )       
        );
        
        /** Loading Label */
        $wp_customize->add_setting(
            'loading_label',
            array(
                'default'           => $default_options['loading_label'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
           'loading_label',
            array(
                'section' => 'pagination_section',
                'label'   => __( 'Loading Label', 'rara-business-pro' ),
                'type'    => 'text',
                'active_callback' => 'rara_business_pro_loading_ac' 
            )       
        );

          /** Nomore Posts */
        $wp_customize->add_setting(
            'nomore_post_label',
            array(
                'default'           => $default_options['nomore_post_label'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
           'nomore_post_label',
            array(
                'section' => 'pagination_section',
                'label'   => __( 'No more Post Label', 'rara-business-pro' ),
                'type'    => 'text',
                'active_callback' => 'rara_business_pro_loading_ac' 
            )       
        );
    
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_pagination_type' );

if ( ! function_exists( 'rara_business_pro_loading_ac' ) ) :
    /**
    * Active callback function for pagination
    */
    function rara_business_pro_loading_ac( $control ){
        $pagination_type = $control->manager->get_setting( 'pagination_type' )->value();
    
        if ( $pagination_type == 'load_more' ) return true;
        
        return false;
    }
endif;