<?php
/**
 * General Sidebar Layout Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_general_sidebar_layout_section' ) ) :
    /**
     * Add general sidebar layout controls
     */
    function rara_business_pro_customize_register_general_sidebar_layout_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** General Sidebar Layout Settings */
        $wp_customize->add_section(
            'general_sidebar_layout_settings',
            array(
                'title'    => __( 'General Sidebar Layout', 'rara-business-pro' ),
                'priority' => 40,
                'panel'    => 'layout_panel',
            )
        );
        
        /** Page Sidebar layout */
        $wp_customize->add_setting( 
            'page_sidebar_layout', 
            array(
                'default'           => $default_options['page_sidebar_layout'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio'
            ) 
        );
        
        $wp_customize->add_control(
    		new Rara_Business_Pro_Radio_Image_Control(
    			$wp_customize,
    			'page_sidebar_layout',
    			array(
    				'section'	  => 'general_sidebar_layout_settings',
    				'label'		  => __( 'Page Sidebar Layout', 'rara-business-pro' ),
    				'description' => __( 'This is the general sidebar layout for pages. You can override the sidebar layout for individual page in repective page.', 'rara-business-pro' ),
    				'choices'	  => array(
    					'no-sidebar'    => get_template_directory_uri() . '/images/no-sidebar.png',
    					'left-sidebar'  => get_template_directory_uri() . '/images/left-sidebar.png',
                        'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
    				)
    			)
    		)
    	);
        
        /** Post Sidebar layout */
        $wp_customize->add_setting( 
            'post_sidebar_layout', 
            array(
                'default'           => $default_options['post_sidebar_layout'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio'
            ) 
        );
        
        $wp_customize->add_control(
    		new Rara_Business_Pro_Radio_Image_Control(
    			$wp_customize,
    			'post_sidebar_layout',
    			array(
    				'section'	  => 'general_sidebar_layout_settings',
    				'label'		  => __( 'Post Sidebar Layout', 'rara-business-pro' ),
    				'description' => __( 'This is the general sidebar layout for posts. You can override the sidebar layout for individual post in repective post.', 'rara-business-pro' ),
    				'choices'	  => array(
    					'no-sidebar'    => get_template_directory_uri() . '/images/no-sidebar.png',
    					'left-sidebar'  => get_template_directory_uri() . '/images/left-sidebar.png',
                        'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
    				)
    			)
    		)
    	);

        /** Blog Sidebar layout */
        $wp_customize->add_setting( 
            'blog_sidebar_layout', 
            array(
                'default'           => $default_options['blog_sidebar_layout'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio'
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Radio_Image_Control(
                $wp_customize,
                'blog_sidebar_layout',
                array(
                    'section'     => 'general_sidebar_layout_settings',
                    'label'       => __( 'Blog Sidebar Layout', 'rara-business-pro' ),
                    'description' => __( 'This is the sidebar layout for blog page.', 'rara-business-pro' ),
                    'choices'     => array(
                        'no-sidebar'    => get_template_directory_uri() . '/images/no-sidebar.png',
                        'left-sidebar'  => get_template_directory_uri() . '/images/left-sidebar.png',
                        'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
                    )
                )
            )
        );

        /** Default Sidebar layout */
        $wp_customize->add_setting( 
            'default_sidebar_layout', 
            array(
                'default'           => $default_options['default_sidebar_layout'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio'
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Radio_Image_Control(
                $wp_customize,
                'default_sidebar_layout',
                array(
                    'section'     => 'general_sidebar_layout_settings',
                    'label'       => __( 'Default Sidebar Layout', 'rara-business-pro' ),
                    'description' => __( 'This is the general sidebar layout for whole site.', 'rara-business-pro' ),
                    'choices'     => array(
                        'no-sidebar'    => get_template_directory_uri() . '/images/no-sidebar.png',
                        'left-sidebar'  => get_template_directory_uri() . '/images/left-sidebar.png',
                        'right-sidebar' => get_template_directory_uri() . '/images/right-sidebar.png',
                    )
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_general_sidebar_layout_section' );