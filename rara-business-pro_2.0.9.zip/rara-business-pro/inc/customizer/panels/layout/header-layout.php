<?php
/**
 * Header Layout Settings
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_layout_header' ) ) :
    /**
     * Add header layout controls
     */
    function rara_business_pro_customize_register_layout_header( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Header Layout Settings */
        $wp_customize->add_section(
            'header_layout_section',
            array(
                'title'    => __( 'Header Layout', 'rara-business-pro' ),
                'priority' => 10,
                'panel'    => 'layout_panel',
            )
        );
        
        /** Header layout */
        $wp_customize->add_setting( 
            'header_layout', 
            array(
                'default'           => $default_options['header_layout'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio'
            ) 
        );
        
        $wp_customize->add_control(
    		new Rara_Business_Pro_Radio_Image_Control(
    			$wp_customize,
    			'header_layout',
    			array(
    				'section'	  => 'header_layout_section',
    				'label'		  => __( 'Header Layout', 'rara-business-pro' ),
    				'description' => __( 'Choose the layout of the header for your site.', 'rara-business-pro' ),
    				'choices'	  => array(
    					'one'   => get_template_directory_uri() . '/images/layout/header-one.png',
    					'two'   => get_template_directory_uri() . '/images/layout/header-two.png',
                        'three' => get_template_directory_uri() . '/images/layout/header-three.png',
                        'four'  => get_template_directory_uri() . '/images/layout/header-four.png',
                        'five'  => get_template_directory_uri() . '/images/layout/header-five.png'
    				)
    			)
    		)
    	);
        
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_layout_header' );