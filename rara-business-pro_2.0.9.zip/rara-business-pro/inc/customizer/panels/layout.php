<?php
/**
 * Layout Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_layout_panel' ) ) :
	/**
	 * Add layout panel
	 */
	function rara_business_pro_customize_register_layout_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'layout_panel', array(
	        'title'          => __( 'Layout Settings', 'rara-business-pro' ),
	        'priority'       => 100,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_layout_panel' );