<?php
/**
 * Color Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_color_controls' ) ) :
    /**
     * Add color controls in default color section
     */
    function rara_business_pro_customize_register_color_controls( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        // Move default color section to appearance settings panel
        $wp_customize->get_section( 'colors' )->panel   = 'appearance_panel';

        /** Primary Color Scheme */
        $wp_customize->add_setting( 'primary_color_scheme', array(
            'default'           => $default_options['primary_color_scheme'],
            'sanitize_callback' => 'sanitize_hex_color'
        ) );

        $wp_customize->add_control( 
            new WP_Customize_Color_Control( 
                $wp_customize, 
                'primary_color_scheme', 
                array(
                    'label'           => __( 'Primary Color Scheme', 'rara-business-pro' ),
                    'description'     => __( 'Customize primary color of your theme.', 'rara-business-pro' ),
                    'section'         => 'colors',     
                    'active_callback' => 'rara_business_pro_colors_callback',           
                )
            )
        );

        /** Secondary Color Scheme */
        $wp_customize->add_setting( 'secondary_color_scheme', array(
            'default'           => $default_options['secondary_color_scheme'],
            'sanitize_callback' => 'sanitize_hex_color'
        ) );

        $wp_customize->add_control( 
            new WP_Customize_Color_Control( 
                $wp_customize, 
                'secondary_color_scheme', 
                array(
                    'label'           => __( 'Secondary Color Scheme', 'rara-business-pro' ),
                    'description'     => __( 'Customize secondary color of your theme.', 'rara-business-pro' ),
                    'section'         => 'colors',  
                    'active_callback' => 'rara_business_pro_colors_callback',              
                )
            )
        );

        /** Software Company Primary Color*/
        $wp_customize->add_setting( 
            'primary_color_scheme_sc', 
            array(
                'default'           => $default_options['primary_color_scheme_sc'],
                'sanitize_callback' => 'sanitize_hex_color'
            ) 
        );

        $wp_customize->add_control( 
            new WP_Customize_Color_Control( 
                $wp_customize, 
                'primary_color_scheme_sc', 
                array(
                    'label'       => __( 'Primary Color', 'rara-business-pro' ),
                    'description' => __( 'Primary color of the theme.', 'rara-business-pro' ),
                    'section'     => 'colors',
                    'active_callback' => 'rara_business_pro_colors_callback',
                )
            )
        );

        /** Software Company Secondary Color*/
        $wp_customize->add_setting( 
            'secondary_color_scheme_sc', 
            array(
                'default'           => $default_options['secondary_color_scheme_sc'],
                'sanitize_callback' => 'sanitize_hex_color'
            ) 
        );

        $wp_customize->add_control( 
            new WP_Customize_Color_Control( 
                $wp_customize, 
                'secondary_color_scheme_sc', 
                array(
                    'label'       => __( 'Secondary Color', 'rara-business-pro' ),
                    'description' => __( 'Secondary color of the theme.', 'rara-business-pro' ),
                    'section'     => 'colors',
                    'active_callback' => 'rara_business_pro_colors_callback',
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_color_controls' );

/**
 * Active Callback
*/
function rara_business_pro_colors_callback( $control ){
    
    $child_theme_support    = $control->manager->get_setting( 'child_additional_support' )->value();
    $control_id             = $control->id;
    
    if ( $control_id == 'primary_color_scheme' && $child_theme_support == 'default' ) return true;
    if ( $control_id == 'secondary_color_scheme' && $child_theme_support == 'default' ) return true;
    if ( $control_id == 'primary_color_scheme_sc' && $child_theme_support == 'software_company' ) return true;
    if ( $control_id == 'secondary_color_scheme_sc' && $child_theme_support == 'software_company' ) return true;
        
    return false;
}