<?php
/**
 * Background controls
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_background_controls' ) ) :
    /**
     * Add Background controls
     */
    function rara_business_pro_customize_register_background_controls( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        // Move default background section to appearance settings panel
        $wp_customize->get_section( 'background_image' )->panel   = 'appearance_panel';
        $wp_customize->get_section( 'background_image' )->title   = __( 'Background', 'rara-business-pro' );
        $wp_customize->get_control( 'background_image' )->active_callback = 'rara_business_pro_body_bg_choice_ac';
        $wp_customize->get_control( 'background_preset' )->active_callback = 'rara_business_pro_body_bg_choice_ac';
        $wp_customize->get_control( 'background_position' )->active_callback = 'rara_business_pro_body_bg_choice_ac';
        $wp_customize->get_control( 'background_size' )->active_callback = 'rara_business_pro_body_bg_choice_ac';
        $wp_customize->get_control( 'background_repeat' )->active_callback = 'rara_business_pro_body_bg_choice_ac';
        $wp_customize->get_control( 'background_attachment' )->active_callback = 'rara_business_pro_body_bg_choice_ac';

        /** Body Background */
        $wp_customize->add_setting( 
            'body_bg', 
            array(
                'default'           => $default_options['body_bg'],
                'sanitize_callback' => 'rara_business_pro_sanitize_radio',
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Radio_Buttonset_Control(
                $wp_customize,
                'body_bg',
                array(
                    'section'     => 'background_image',
                    'label'       => __( 'Body Background', 'rara-business-pro' ),
                    'description' => __( 'Choose body background as image or pattern.', 'rara-business-pro' ),
                    'choices'     => array(
                        'image'   => __( 'Image', 'rara-business-pro' ),
                        'pattern' => __( 'Pattern', 'rara-business-pro' ),
                    ),
                    'priority'          => 1
                )
            )
        );

        /** Background Pattern */
        $wp_customize->add_setting( 'bg_pattern', array(
            'default'           => $default_options['bg_pattern'],
            'sanitize_callback' => 'esc_attr'
        ) );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Radio_Image_Control(
                $wp_customize,
                'bg_pattern',
                array(
                    'label'           => __( 'Background Pattern', 'rara-business-pro' ),
                    'description'     => __( 'Choose from any of 63 awesome background patterns for your site background.', 'rara-business-pro' ),
                    'section'         => 'background_image',
                    'choices'         => rara_business_pro_get_patterns(),
                    'active_callback' => 'rara_business_pro_body_bg_choice_ac'
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_background_controls' );

if ( ! function_exists( 'rara_business_pro_body_bg_choice_ac' ) ) :
    /**
     * Active Callback for Body Background
     */
    function rara_business_pro_body_bg_choice_ac( $control ){
        $body_bg    = $control->manager->get_setting( 'body_bg' )->value();
        $control_id = $control->id;
             
        if ( $control_id == 'background_image' && $body_bg == 'image' ) return true;
        if ( $control_id == 'background_preset' && $body_bg == 'image' ) return true;
        if ( $control_id == 'background_position' && $body_bg == 'image' ) return true;
        if ( $control_id == 'background_size' && $body_bg == 'image' ) return true;
        if ( $control_id == 'background_repeat' && $body_bg == 'image' ) return true;
        if ( $control_id == 'background_attachment' && $body_bg == 'image' ) return true;

        if ( $control_id == 'bg_pattern' && $body_bg == 'pattern' ) return true;
        
        return false;
    }
endif;