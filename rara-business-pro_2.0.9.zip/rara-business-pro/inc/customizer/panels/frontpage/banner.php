<?php
/**
 * Banner Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_banner_section' ) ) :
    /**
     * Add banner section controls
     */
    function rara_business_pro_customize_register_banner_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        $wp_customize->get_section( 'header_image' )->panel    = 'frontpage_panel';
        $wp_customize->get_section( 'header_image' )->title    = __( 'Banner Section', 'rara-business-pro' );
        $wp_customize->get_section( 'header_image' )->priority = 10;
        $wp_customize->get_control( 'header_image' )->active_callback = 'rara_business_pro_banner_ac';
        $wp_customize->get_control( 'header_video' )->active_callback = 'rara_business_pro_banner_ac';
        $wp_customize->get_control( 'external_header_video' )->active_callback = 'rara_business_pro_banner_ac';
        $wp_customize->get_section( 'header_image' )->description = '';                                               
        $wp_customize->get_setting( 'header_image' )->transport = 'refresh';
        $wp_customize->get_setting( 'header_video' )->transport = 'refresh';
        $wp_customize->get_setting( 'external_header_video' )->transport = 'refresh';

        /** Banner Options */
        $wp_customize->add_setting(
            'ed_banner_section',
            array(
                'default'           => $default_options['ed_banner_section'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'ed_banner_section',
                array(
                    'label'       => __( 'Banner Options', 'rara-business-pro' ),
                    'description' => __( 'Choose banner as static image/video.', 'rara-business-pro' ),
                    'section'     => 'header_image',
                    'choices'     => array(
                        'no_banner'        => __( 'Disable Banner Section', 'rara-business-pro' ),
                        'static_banner'    => __( 'Static/Video CTA Banner', 'rara-business-pro' ),
                        'static_nl_banner' => __( 'Static/Video Newsletter Banner', 'rara-business-pro' ),
                        'slider_banner'    => __( 'Banner as Slider', 'rara-business-pro' ),
                    ),
                    'priority' => 5 
                )            
            )
        );

        /** Banner title */
        $wp_customize->add_setting(
            'banner_title',
            array(
                'default'           => $default_options['banner_title'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'banner_title',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Banner Title', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        // banner title selective refresh
        $wp_customize->selective_refresh->add_partial( 'banner_title', array(
            'selector'            => '.banner .text-holder h2.title.banner-title',
            'render_callback'     => 'rara_business_pro_banner_title_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Banner description */
        $wp_customize->add_setting(
            'banner_description',
            array(
                'default'           => $default_options['banner_description'],
                'sanitize_callback' => 'wp_kses_post',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'banner_description',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Banner Description', 'rara-business-pro' ),
                'type'            => 'textarea',
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        // Banner description selective refresh
        $wp_customize->selective_refresh->add_partial( 'banner_description', array(
            'selector'            => '.banner .text-holder p.banner-desc',
            'render_callback'     => 'rara_business_pro_banner_description_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Banner link one label */
        $wp_customize->add_setting(
            'banner_link_one_label',
            array(
                'default'           => $default_options['banner_link_one_label'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'banner_link_one_label',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Link One Label', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        // Selective refresh for banner link one label
        $wp_customize->selective_refresh->add_partial( 'banner_link_one_label', array(
            'selector'            => '.banner .btn-holder a.btn-free-inquiry.btn1',
            'render_callback'     => 'rara_business_pro_banner_link_one_label_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Banner link one url */
        $wp_customize->add_setting(
            'banner_link_one_url',
            array(
                'default'           => $default_options['banner_link_one_url'],
                'sanitize_callback' => 'esc_url_raw',
            )
        );

        $wp_customize->add_control(
            'banner_link_one_url',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Link One Url', 'rara-business-pro' ),
                'type'            => 'url',
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        /** Banner link two label */
        $wp_customize->add_setting(
            'banner_link_two_label',
            array(
                'default'           => $default_options['banner_link_two_label'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'banner_link_two_label',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Link Two Label', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        // Selective refresh for banner link two label.
        $wp_customize->selective_refresh->add_partial( 'banner_link_two_label', array(
            'selector'            => '.banner .btn-holder a.btn-view-service.btn2',
            'render_callback'     => 'rara_business_pro_banner_link_two_label_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Banner link two url */
        $wp_customize->add_setting(
            'banner_link_two_url',
            array(
                'default'           => $default_options['banner_link_two_url'],
                'sanitize_callback' => 'esc_url_raw',
            )
        );

        $wp_customize->add_control(
            'banner_link_two_url',
            array(
                'section'         => 'header_image',
                'label'           => __( 'Link Two Url', 'rara-business-pro' ),
                'type'            => 'url',
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        /** Banner Newsletter */
        $wp_customize->add_setting(
            'banner_newsletter',
            array(
                'default'           => $default_options['banner_newsletter'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );
        
        $wp_customize->add_control(
            'banner_newsletter',
            array(
                'label'           => __( 'Banner Newsletter', 'rara-business-pro' ),
                'description'     => __( 'Add shortcode here.', 'rara-business-pro' ),
                'section'         => 'header_image',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );

        /** Slider Content Style */
        $wp_customize->add_setting(
            'slider_type',
            array(
                'default'           => $default_options['slider_type'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'slider_type',
                array(
                    'label'   => __( 'Slider Content Style', 'rara-business-pro' ),
                    'section' => 'header_image',
                    'choices' => array(
                        'latest_posts' => __( 'Latest Posts', 'rara-business-pro' ),
                        'cat'          => __( 'Category', 'rara-business-pro' ),
                        'pages'        => __( 'Pages', 'rara-business-pro' ),
                        'custom'       => __( 'Custom', 'rara-business-pro' ),
                    ),
                    'active_callback' => 'rara_business_pro_banner_ac'  
                )
            )
        );
        
        /** Slider Category */
        $wp_customize->add_setting(
            'slider_cat',
            array(
                'default'           => $default_options['slider_cat'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'slider_cat',
                array(
                    'label'           => __( 'Slider Category', 'rara-business-pro' ),
                    'section'         => 'header_image',
                    'choices'         => rara_business_pro_get_categories(),
                    'active_callback' => 'rara_business_pro_banner_ac'  
                )
            )
        );
        
        /** No. of slides */
        $wp_customize->add_setting(
            'no_of_slides',
            array(
                'default'           => $default_options['no_of_slides'],
                'sanitize_callback' => 'rara_business_pro_sanitize_number_absint'
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Slider_Control( 
                $wp_customize,
                'no_of_slides',
                array(
                    'section'     => 'header_image',
                    'label'       => __( 'Number of Slides', 'rara-business-pro' ),
                    'description' => __( 'Choose the number of slides you want to display', 'rara-business-pro' ),
                    'choices'     => array(
                        'min'   => 1,
                        'max'   => 20,
                        'step'  => 1,
                    ),
                    'active_callback' => 'rara_business_pro_banner_ac'                 
                )
            )
        );
        
        /** Slider Pages */
        $wp_customize->add_setting( 
            new Rara_Business_Pro_Repeater_Setting( 
                $wp_customize, 
                'slider_pages', 
                array(
                    'default'           => $default_options['slider_pages'],
                    'sanitize_callback' => array( 'Rara_Business_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),
                ) 
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Control_Repeater(
                $wp_customize,
                'slider_pages',
                array(
                    'section' => 'header_image',                
                    'label'   => __( 'Slider Pages ', 'rara-business-pro' ),
                    'fields'  => array(
                        'page' => array(
                            'type'    => 'select',
                            'label'   => __( 'Select Page for slider', 'rara-business-pro' ),
                            'choices' => rara_business_pro_get_posts( 'page', true )
                        )
                    ),
                    'row_label' => array(
                        'type'  => 'field',
                        'value' => __( 'pages', 'rara-business-pro' ),
                        'field' => 'page'
                    ),
                    'active_callback' => 'rara_business_pro_banner_ac'                        
                )
            )
        );
        
        /** Add Slides */
        $wp_customize->add_setting( 
            new Rara_Business_Pro_Repeater_Setting( 
                $wp_customize, 
                'slider_custom', 
                array(
                    'default'           => $default_options['slider_custom'],
                    'sanitize_callback' => array( 'Rara_Business_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),                             
                ) 
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Control_Repeater(
                $wp_customize,
                'slider_custom',
                array(
                    'section' => 'header_image',                
                    'label'   => __( 'Add Sliders', 'rara-business-pro' ),
                    'fields'  => array(
                        'thumbnail' => array(
                            'type'  => 'image', 
                            'label' => __( 'Add Image', 'rara-business-pro' ),                
                        ),
                        'title'     => array(
                            'type'  => 'text',
                            'label' => __( 'Title', 'rara-business-pro' ),
                        ),
                        'subtitle'   => array(
                            'type'  => 'textarea',
                            'label' => __( 'Description', 'rara-business-pro' ),
                        ),
                        'link'     => array(
                            'type'  => 'text',
                            'label' => __( 'Link', 'rara-business-pro' ),
                        ),
                    ),
                    'row_label' => array(
                        'type'  => 'field',
                        'value' => __( 'Slide', 'rara-business-pro' ),
                        'field' => 'title'
                    ),
                    'active_callback' => 'rara_business_pro_banner_ac'                                              
                )
            )
        );
        
        /** HR */
        $wp_customize->add_setting(
            'hr',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'hr',
                array(
                    'section'     => 'header_image',
                    'description' => '<hr/>',
                    'active_callback' => 'rara_business_pro_banner_ac'
                )
            )
        ); 
        
        /** Slider Auto */
        $wp_customize->add_setting(
            'slider_auto',
            array(
                'default'           => $default_options['slider_auto'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'slider_auto',
                array(
                    'section'     => 'header_image',
                    'label'       => __( 'Slider Auto', 'rara-business-pro' ),
                    'description' => __( 'Enable slider auto transition.', 'rara-business-pro' ),
                    'active_callback' => 'rara_business_pro_banner_ac'
                )
            )
        );
        
        /** Slider Loop */
        $wp_customize->add_setting(
            'slider_loop',
            array(
                'default'           => $default_options['slider_loop'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'slider_loop',
                array(
                    'section'     => 'header_image',
                    'label'       => __( 'Slider Loop', 'rara-business-pro' ),
                    'description' => __( 'Enable slider loop.', 'rara-business-pro' ),
                    'active_callback' => 'rara_business_pro_banner_ac'
                )
            )
        );
        
        /** Slider Caption */
        $wp_customize->add_setting(
            'slider_caption',
            array(
                'default'           => $default_options['slider_caption'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control( 
                $wp_customize,
                'slider_caption',
                array(
                    'section'     => 'header_image',
                    'label'       => __( 'Slider Caption', 'rara-business-pro' ),
                    'description' => __( 'Enable slider caption.', 'rara-business-pro' ),
                    'active_callback' => 'rara_business_pro_banner_ac'
                )
            )
        );
        
        /** Slider Animation */
        $wp_customize->add_setting(
            'slider_animation',
            array(
                'default'           => $default_options['slider_animation'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'slider_animation',
                array(
                    'label'       => __( 'Slider Animation', 'rara-business-pro' ),
                    'section'     => 'header_image',
                    'choices'     => array(
                        'bounceOut'      => __( 'Bounce Out', 'rara-business-pro' ),
                        'bounceOutLeft'  => __( 'Bounce Out Left', 'rara-business-pro' ),
                        'bounceOutRight' => __( 'Bounce Out Right', 'rara-business-pro' ),
                        'bounceOutUp'    => __( 'Bounce Out Up', 'rara-business-pro' ),
                        'bounceOutDown'  => __( 'Bounce Out Down', 'rara-business-pro' ),
                        'fadeOut'        => __( 'Fade Out', 'rara-business-pro' ),
                        'fadeOutLeft'    => __( 'Fade Out Left', 'rara-business-pro' ),
                        'fadeOutRight'   => __( 'Fade Out Right', 'rara-business-pro' ),
                        'fadeOutUp'      => __( 'Fade Out Up', 'rara-business-pro' ),
                        'fadeOutDown'    => __( 'Fade Out Down', 'rara-business-pro' ),
                        'flipOutX'       => __( 'Flip OutX', 'rara-business-pro' ),
                        'flipOutY'       => __( 'Flip OutY', 'rara-business-pro' ),
                        'hinge'          => __( 'Hinge', 'rara-business-pro' ),
                        'pulse'          => __( 'Pulse', 'rara-business-pro' ),
                        'rollOut'        => __( 'Roll Out', 'rara-business-pro' ),
                        'rotateOut'      => __( 'Rotate Out', 'rara-business-pro' ),
                        'rubberBand'     => __( 'Rubber Band', 'rara-business-pro' ),
                        'shake'          => __( 'Shake', 'rara-business-pro' ),
                        ''               => __( 'Slide', 'rara-business-pro' ),
                        'slideOutLeft'   => __( 'Slide Out Left', 'rara-business-pro' ),
                        'slideOutRight'  => __( 'Slide Out Right', 'rara-business-pro' ),
                        'slideOutUp'     => __( 'Slide Out Up', 'rara-business-pro' ),
                        'slideOutDown'   => __( 'Slide Out Down', 'rara-business-pro' ),
                        'swing'          => __( 'Swing', 'rara-business-pro' ),
                        'tada'           => __( 'Tada', 'rara-business-pro' ),
                        'zoomOut'        => __( 'Zoom Out', 'rara-business-pro' ),
                        'zoomOutLeft'    => __( 'Zoom Out Left', 'rara-business-pro' ),
                        'zoomOutRight'   => __( 'Zoom Out Right', 'rara-business-pro' ),
                        'zoomOutUp'      => __( 'Zoom Out Up', 'rara-business-pro' ),
                        'zoomOutDown'    => __( 'Zoom Out Down', 'rara-business-pro' ),                    
                    ),
                    'active_callback' => 'rara_business_pro_banner_ac'                                  
                )
            )
        );
        
        /** Readmore Text */
        $wp_customize->add_setting(
            'slider_readmore',
            array(
                'default'           => $default_options['slider_readmore'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage' 
            )
        );
        
        $wp_customize->add_control(
            'slider_readmore',
            array(
                'type'            => 'text',
                'section'         => 'header_image',
                'label'           => __( 'Slider Readmore', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_banner_ac'
            )
        );
        
        $wp_customize->selective_refresh->add_partial( 'slider_readmore', array(
            'selector' => '.banner .banner-slider .text-holder a.slider-btn',
            'render_callback' => 'rara_business_pro_get_slider_readmore',
        ) );
        /** Slider Settings Ends */  
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_banner_section' );

if ( ! function_exists( 'rara_business_pro_banner_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_banner_ac( $control ){
        $banner      = $control->manager->get_setting( 'ed_banner_section' )->value();
        $slider_type = $control->manager->get_setting( 'slider_type' )->value();
        $control_id  = $control->id;
        
        // static banner controls
        if ( $control_id == 'header_image' && ( $banner == 'static_banner' || $banner == 'static_nl_banner' ) ) return true;
        if ( $control_id == 'header_video' && ( $banner == 'static_banner' || $banner == 'static_nl_banner' ) ) return true;
        if ( $control_id == 'external_header_video' && ( $banner == 'static_banner' || $banner == 'static_nl_banner' ) ) return true;

        // banner title, description and button controls
        if ( $control_id == 'banner_title' && $banner == 'static_banner' ) return true;
        if ( $control_id == 'banner_description' && $banner == 'static_banner' ) return true;
        if ( $control_id == 'banner_link_one_label' && $banner == 'static_banner' ) return true;
        if ( $control_id == 'banner_link_one_url' && $banner == 'static_banner' ) return true;
        if ( $control_id == 'banner_link_two_label' && $banner == 'static_banner' ) return true;
        if ( $control_id == 'banner_link_two_url' && $banner == 'static_banner' ) return true;

        // Newsletter Banner
        if ( $control_id == 'banner_newsletter' && $banner == 'static_nl_banner' ) return true;
    
        if ( $control_id == 'slider_type' && $banner == 'slider_banner' ) return true;
        if ( $control_id == 'slider_auto' && $banner == 'slider_banner' ) return true;
        if ( $control_id == 'slider_loop' && $banner == 'slider_banner' ) return true;
        if ( $control_id == 'slider_caption' && $banner == 'slider_banner' ) return true;          
        if ( $control_id == 'slider_readmore' && $banner == 'slider_banner' ) return true;    
        if ( $control_id == 'slider_cat' && $banner == 'slider_banner' && $slider_type == 'cat' ) return true;
        if ( $control_id == 'no_of_slides' && $banner == 'slider_banner' && $slider_type == 'latest_posts' ) return true;
        if ( $control_id == 'slider_pages' && $banner == 'slider_banner' && $slider_type == 'pages' ) return true;
        if ( $control_id == 'slider_custom' && $banner == 'slider_banner' && $slider_type == 'custom' ) return true;
        if ( $control_id == 'slider_animation' && $banner == 'slider_banner' ) return true;
        if ( $control_id == 'hr' && $banner == 'slider_banner' ) return true;

        return false;
    }
endif;