<?php
/**
 * Frontpage Section Sortable.
 *
 * @package Rara_Business_Pro
 */
if( ! function_exists( 'rara_business_pro_customize_register_frontpage_sort' ) ) :
    /**
    * Sort Homepage Section Settings 
    */ 
    function rara_business_pro_customize_register_frontpage_sort( $wp_customize ) {
        /* Get default theme options */   
        $default_options  = rara_business_pro_default_theme_options();

        /** Sort Section */
        $wp_customize->add_section(
            'sort_frontpage_settings',
            array(
                'title'    => __( 'Sort or Toggle Frontpage Section', 'rara-business-pro' ),
                'priority' => 150,
                'panel'    => 'frontpage_panel',
            )
        );
        
        /** Sort Frontpage Section Section */
        $wp_customize->add_setting(
    		'sort_frontpage_section', 
    		array(
    			'default' => $default_options['sort_frontpage_section'],
    			'sanitize_callback' => 'rara_business_pro_sanitize_sortable',						
    		)
    	);

    	$wp_customize->add_control(
    		new Rara_Business_Pro_Sortable(
    			$wp_customize,
    			'sort_frontpage_section',
    			array(
    				'section'     => 'sort_frontpage_settings',
    				'label'       => __( 'Sort Sections', 'rara-business-pro' ),
    				'description' => sprintf( __( 'Sort or toggle home page sections. Click on %1$sEye%2$s icon to Enable / Disable sections, Click and %3$sDrag%4$s section to sort.', 'rara-business-pro' ), '<b>', '</b>', '<b>', '</b>' ), 
    				'choices'     => array(
                        'services'    => __( 'Services Section', 'rara-business-pro' ),
                        'about'       => __( 'About Section', 'rara-business-pro' ),
                        'choose-us'   => __( 'Feature Section', 'rara-business-pro' ),
                        'team'        => __( 'Team Section', 'rara-business-pro' ),
                        'testimonial' => __( 'Testimonial Section', 'rara-business-pro' ),
                        'stats'       => __( 'Stat Counter Section', 'rara-business-pro' ),
                        'skill'       => __( 'Skill Section', 'rara-business-pro' ),
                        'portfolio'   => __( 'Portfolio Section', 'rara-business-pro' ),
                        'pricing'     => __( 'Pricing Section', 'rara-business-pro' ),
                        'blog'        => __( 'Blog Section', 'rara-business-pro' ),
                        'cta'         => __( 'CTA Section', 'rara-business-pro' ),
                        'faq'         => __( 'FAQ Section', 'rara-business-pro' ),
                        'contact'     => __( 'Contact Section', 'rara-business-pro' ),
                        'client'      => __( 'Clients Section', 'rara-business-pro' ),
                	),
    			)
    		)
    	);
            
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_frontpage_sort' );