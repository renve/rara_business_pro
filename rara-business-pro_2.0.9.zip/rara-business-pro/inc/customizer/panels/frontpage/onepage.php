<?php
/**
 * One Page Settings
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_frontpage_onepage' ) ) :
    /**
     * Add onepage option for frontpage sections
     */
    function rara_business_pro_customize_register_frontpage_onepage( $wp_customize ){
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Sort Front Page Section */
        $wp_customize->add_section(
            'one_page_settings',
            array(
                'title'    => __( 'One Page Settings', 'rara-business-pro' ),
                'priority' => 160,
                'panel'    => 'frontpage_panel',
            )
        );
        
        /** Enable / Disable Options */
        $wp_customize->add_setting(
            'ed_one_page',
            array(
                'default'           => false,
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_one_page',
                array(
                    'label'       => __( 'Enable Section Menu', 'rara-business-pro' ),
                    'description' => __( 'Enable to make home page one page scrolling with section menu.', 'rara-business-pro' ),
                    'section'     => 'one_page_settings',
                )            
            )
        );
        
        /** Enable / Disable Home Options */
        $wp_customize->add_setting(
            'ed_home_link',
            array(
                'default'           => true,
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_home_link',
                array(
                    'label'           => __( 'Home Link', 'rara-business-pro' ),
                    'description'     => __( 'Enable to display "Home" link in section menu.', 'rara-business-pro' ),
                    'section'         => 'one_page_settings',
                    'active_callback' => 'rara_business_pro_onepage_menu_ac'
                )            
            )
        );
        
        /** Service Section Menu Label  */
        $wp_customize->add_setting(
            'label_service',
            array(
                'default'           => $default_options['label_service'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_service',
            array(
                'label'           => __( 'Service Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
        
        /** About Section Menu Label  */
        $wp_customize->add_setting(
            'label_about',
            array(
                'default'           => $default_options['label_about'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_about',
            array(
                'label'           => __( 'About Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
        
        /** Why Choose Us Section Menu Label  */
        $wp_customize->add_setting(
            'label_choose_us',
            array(
                'default'           => $default_options['label_choose_us'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_choose_us',
            array(
                'label'           => __( 'Why Choose Us Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
        
        /** Team Section Menu Label  */
        $wp_customize->add_setting(
            'label_team',
            array(
                'default'           => $default_options['label_team'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_team',
            array(
                'label'           => __( 'Team Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
        
        /** Testimonial Section Menu Label  */
        $wp_customize->add_setting(
            'label_testimonial',
            array(
                'default'           => $default_options['label_testimonial'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_testimonial',
            array(
                'label'           => __( 'Testimonial Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Stat Counter Section Menu Label  */
        $wp_customize->add_setting(
            'label_stats',
            array(
                'default'           => $default_options['label_stats'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_stats',
            array(
                'label'           => __( 'Stat Counter Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Skill Section Menu Label  */
        $wp_customize->add_setting(
            'label_skill',
            array(
                'default'           => $default_options['label_skill'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_skill',
            array(
                'label'           => __( 'Skill Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
        
        /** Portfolio Section Menu Label  */
        $wp_customize->add_setting(
            'label_portfolio',
            array(
                'default'           => $default_options['label_portfolio'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_portfolio',
            array(
                'label'           => __( 'Portfolio Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Pricing Section Menu Label  */
        $wp_customize->add_setting(
            'label_pricing',
            array(
                'default'           => $default_options['label_pricing'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_pricing',
            array(
                'label'           => __( 'Pricing Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Blog Section Menu Label  */
        $wp_customize->add_setting(
            'label_blog',
            array(
                'default'           => $default_options['label_blog'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_blog',
            array(
                'label'           => __( 'Blog Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** CTA Section Menu Label  */
        $wp_customize->add_setting(
            'label_cta',
            array(
                'default'           => $default_options['label_cta'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_cta',
            array(
                'label'           => __( 'CTA Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** FAQs Section Menu Label  */
        $wp_customize->add_setting(
            'label_faq',
            array(
                'default'           => $default_options['label_faq'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_faq',
            array(
                'label'           => __( 'FAQs Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Contact Section Menu Label  */
        $wp_customize->add_setting(
            'label_contact',
            array(
                'default'           => $default_options['label_contact'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_contact',
            array(
                'label'           => __( 'Contact Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );

        /** Client Section Menu Label  */
        $wp_customize->add_setting(
            'label_client',
            array(
                'default'           => $default_options['label_client'],
                'sanitize_callback' => 'sanitize_text_field',
            )
        );
        
        $wp_customize->add_control(
            'label_client',
            array(
                'label'           => __( 'Client Section Menu Label', 'rara-business-pro' ),
                'description'     => __( 'Left blank to hide the section in the menu.', 'rara-business-pro' ),
                'section'         => 'one_page_settings',
                'type'            => 'text',
                'active_callback' => 'rara_business_pro_onepage_menu_ac'
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_frontpage_onepage' );

if ( ! function_exists( 'rara_business_pro_onepage_menu_ac' ) ) :
    /**
     * Active Callback
    */
    function rara_business_pro_onepage_menu_ac( $control ){
        $enabled_sections = $control->manager->get_setting( 'sort_frontpage_section' )->value();
        $ed_one_page      = $control->manager->get_setting( 'ed_one_page' )->value();
        $control_id       = $control->id;
        
        $show_service     = in_array( 'services', $enabled_sections ) ? true : false;
        $show_about       = in_array( 'about', $enabled_sections ) ? true : false;
        $show_choose_us   = in_array( 'choose-us', $enabled_sections ) ? true : false;
        $show_team        = in_array( 'team', $enabled_sections ) ? true : false;
        $show_testimonial = in_array( 'testimonial', $enabled_sections ) ? true : false;
        $show_stats       = in_array( 'stats', $enabled_sections ) ? true : false;
        $show_skill       = in_array( 'skill', $enabled_sections ) ? true : false;
        $show_portfolio   = in_array( 'portfolio', $enabled_sections ) ? true : false;
        $show_pricing     = in_array( 'pricing', $enabled_sections ) ? true : false;
        $show_blog        = in_array( 'blog', $enabled_sections ) ? true : false;
        $show_cta         = in_array( 'cta', $enabled_sections ) ? true : false;
        $show_faq         = in_array( 'faq', $enabled_sections ) ? true : false;
        $show_contact     = in_array( 'contact', $enabled_sections ) ? true : false;
        $show_client      = in_array( 'client', $enabled_sections ) ? true : false;
        
        if ( $control_id == 'ed_home_link' && $ed_one_page == true ) return true; 
        if ( $control_id == 'label_service' && $ed_one_page == true && $show_service ) return true; 
        if ( $control_id == 'label_about' && $ed_one_page == true && $show_about ) return true;   
        if ( $control_id == 'label_choose_us' && $ed_one_page == true && $show_choose_us ) return true;   
        if ( $control_id == 'label_team' && $ed_one_page == true && $show_team ) return true;
        if ( $control_id == 'label_testimonial' && $ed_one_page == true && $show_testimonial ) return true;
        if ( $control_id == 'label_stats' && $ed_one_page == true && $show_stats ) return true;
        if ( $control_id == 'label_skill' && $ed_one_page == true && $show_skill ) return true;
        if ( $control_id == 'label_portfolio' && $ed_one_page == true && $show_portfolio ) return true;
        if ( $control_id == 'label_pricing' && $ed_one_page == true && $show_pricing ) return true;
        if ( $control_id == 'label_blog' && $ed_one_page == true && $show_blog ) return true;
        if ( $control_id == 'label_cta' && $ed_one_page == true && $show_cta ) return true;
        if ( $control_id == 'label_faq' && $ed_one_page == true && $show_faq ) return true;
        if ( $control_id == 'label_contact' && $ed_one_page == true && $show_contact ) return true;
        if ( $control_id == 'label_client' && $ed_one_page == true && $show_client ) return true;
        
        return false;
    }
endif;