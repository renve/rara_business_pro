<?php
/**
 * Frontpage FAQ Widget
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_frontpage_faq_widget' ) ) :
    /**
     * Add frontpage testimonial section controls
     */
    function rara_business_pro_customize_register_frontpage_faq_widget( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Faq Readmore Settings */
        $wp_customize->add_section(
            'frontpage_widget_faq_settings',
            array(
                'title'    => esc_html__( 'FAQs Widgets', 'rara-business-pro' ),
                'priority' => 270,
                'panel'    => 'frontpage_panel',
            )
        );

        // Frontpage faq readmore button label.
        $wp_customize->add_setting(
            'frontpage_faq_widget_readmore_text',
            array(
                'default'           => $default_options['frontpage_faq_widget_readmore_text'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage' 
            )
        );
            
        $wp_customize->add_control(
            'frontpage_faq_widget_readmore_text',
            array(
                'section'         => 'frontpage_widget_faq_settings',
                'priority'        => 100,
                'label'           => esc_html__( 'Readmore Text', 'rara-business-pro' ),
                'description'     => esc_html__( 'Button label for readmore text in frontpage faq section.', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_frontpage_faq_widget_ac'
            )
        );

        $wp_customize->selective_refresh->add_partial( 'frontpage_faq_widget_readmore_text', array(
            'selector' => '.home .faq-section .container .btn-holder a.btn-view',
            'render_callback' => 'rara_business_pro_get_fp_faq_viewall_label',
        ) );

        $frontpage_faq_section = $wp_customize->get_section( 'sidebar-widgets-faq' );

        if ( ! empty( $frontpage_faq_section ) ) {
            $frontpage_faq_section->panel = 'frontpage_panel';
            $frontpage_faq_section->priority = 270;
            $wp_customize->get_control( 'frontpage_faq_widget_readmore_text' )->section  = 'sidebar-widgets-faq';
        }
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_frontpage_faq_widget' );

if ( ! function_exists( 'rara_business_pro_frontpage_faq_widget_ac' ) ) :

    /**
     * Active Callback
     */
    function rara_business_pro_frontpage_faq_widget_ac( $control ){
        $faq_template_link = rara_business_pro_get_template_page_url( 'templates/faq.php' );
        $control_id         = $control->id;

        // Team view all label
        if ( $control_id == 'frontpage_faq_widget_readmore_text' && $faq_template_link ) return true;

        return false;
    }
endif;