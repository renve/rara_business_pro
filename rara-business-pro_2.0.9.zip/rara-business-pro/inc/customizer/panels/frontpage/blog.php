<?php
/**
 * Blog Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_blog_section' ) ) :
    /**
     * Add blog section controls
     */
    function rara_business_pro_customize_register_blog_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Blog Sectopm */
        $wp_customize->add_section(
            'blog_section',
            array(
                'title'    => __( 'Blog Section', 'rara-business-pro' ),
                'priority' => 95,
                'panel'    => 'frontpage_panel',
            )
        );

        /** Blog title */
        $wp_customize->add_setting(
            'blog_title',
            array(
                'default'           => $default_options['blog_title'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'blog_title',
            array(
                'section'         => 'blog_section',
                'label'           => __( 'Blog Title', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_blog_ac'
            )
        );

        // Selective refresh for blog title.
        $wp_customize->selective_refresh->add_partial( 'blog_title', array(
            'selector'            => '.blog-section .widget_text h2.widget-title',
            'render_callback'     => 'rara_business_pro_blog_title_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Blog description */
        $wp_customize->add_setting(
            'blog_description',
            array(
                'default'           => $default_options['blog_description'],
                'sanitize_callback' => 'wp_kses_post',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'blog_description',
            array(
                'section'         => 'blog_section',
                'label'           => __( 'Blog Description', 'rara-business-pro' ),
                'type'            => 'textarea',
                'active_callback' => 'rara_business_pro_blog_ac'
            )
        ); 

        // Selective refresh for blog description.
        $wp_customize->selective_refresh->add_partial( 'blog_description', array(
            'selector'            => '.blog-section .textwidget p',
            'render_callback'     => 'rara_business_pro_blog_description_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );   

        // Readmore button label.
        $wp_customize->add_setting(
            'blog_viewall_label',
            array(
                'default'           => $default_options['blog_viewall_label'],
                'sanitize_callback' => 'sanitize_text_field', 
                'transport'         => 'postMessage'
            )
        );
            
        $wp_customize->add_control(
            'blog_viewall_label',
            array(
                'section'         => 'blog_section',
                'priority'        => 100,
                'label'           => esc_html__( 'View All Posts', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_blog_ac'
            )
        );

        $wp_customize->selective_refresh->add_partial( 'blog_viewall_label', array(
            'selector' => '.home .blog-section .container .btn-holder a.btn-view',
            'render_callback' => 'rara_business_pro_get_blog_viewall_label',
        ) );
   
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_blog_section' );

if ( ! function_exists( 'rara_business_pro_blog_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_blog_ac( $control ){
        $enabled_sections  = $control->manager->get_setting( 'sort_frontpage_section' )->value();
        $show_blog_section = in_array( 'blog', $enabled_sections ) ? true : false;
        $blog_page         = get_option( 'page_for_posts' );
        $control_id        = $control->id;

        // Blog title, description and number of posts controls
        if ( $control_id == 'blog_title' && $show_blog_section ) return true;
        if ( $control_id == 'blog_description' && $show_blog_section ) return true;
        if ( $control_id == 'blog_viewall_label' && $show_blog_section && $blog_page ) return true;

        return false;
    }
endif;