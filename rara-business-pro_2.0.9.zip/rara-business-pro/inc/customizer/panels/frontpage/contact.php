<?php
/**
 * Contact Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_contact_section' ) ) :
    /**
     * Add contact section controls
     */
    function rara_business_pro_customize_register_contact_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();
        // check if contact form 7 plugin is activated
        $cf7_activated   =  rara_business_pro_is_cf7_activated(); 

        /** Contact Sectopm */
        $wp_customize->add_section(
            'contact_section',
            array(
                'title'    => __( 'Contact Section', 'rara-business-pro' ),
                'priority' => 110,
                'panel'    => 'frontpage_panel',
            )
        );

         /** Contact Detail Note */
        $wp_customize->add_setting(
            'contact_section_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'contact_section_notes',
                array(
                    'section'     => 'contact_section',
                    'description' => sprintf( '<hr/><b>%1$s</b>', __( 'Section Heading and Description.', 'rara-business-pro' ) ),
                    'active_callback' => 'rara_business_pro_contact_ac'
                )
            )
        );

        /** Contact title */
        $wp_customize->add_setting(
            'contact_title',
            array(
                'default'           => $default_options['contact_title'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'contact_title',
            array(
                'section'         => 'contact_section',
                'label'           => __( 'Contact Title', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_contact_ac'
            )
        );

        // Selective refresh for contact title.
        $wp_customize->selective_refresh->add_partial( 'contact_title', array(
            'selector'            => '.contact-section .widget_text h2.widget-title',
            'render_callback'     => 'rara_business_pro_contact_title_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Contact description */
        $wp_customize->add_setting(
            'contact_description',
            array(
                'default'           => $default_options['contact_description'],
                'sanitize_callback' => 'wp_kses_post',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'contact_description',
            array(
                'section'         => 'contact_section',
                'label'           => __( 'Contact Description', 'rara-business-pro' ),
                'type'            => 'textarea',
                'active_callback' => 'rara_business_pro_contact_ac'
            )
        );

        // Selective refresh for contact description.
        $wp_customize->selective_refresh->add_partial( 'contact_description', array(
            'selector'            => '.contact-section .widget_text p',
            'render_callback'     => 'rara_business_pro_contact_description_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** Contact Detail Note */
        $wp_customize->add_setting(
            'contact_details_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'contact_details_notes',
                array(
                    'section'         => 'contact_section',
                    'description'     => sprintf( '<hr/><b>%1$s</b>', __( 'Contact Details.', 'rara-business-pro' ) ),
                    'active_callback' => 'rara_business_pro_contact_ac'
                )
            )
        );

        /** As in header */
        $wp_customize->add_setting(
            'ed_contact_detail_as_in_header',
            array(
                'default'           => $default_options['ed_contact_detail_as_in_header'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_contact_detail_as_in_header',
                array(
                    'label'           => __( 'Show Contact Details as in Header', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show contact details as in header section.', 'rara-business-pro' ),
                    'section'         => 'contact_section',
                    'active_callback' => 'rara_business_pro_contact_ac'
                )            
            )
        );

        /** Contact Phone  */
        $wp_customize->add_setting(
            'contact_phone',
            array(
                'default'           => $default_options['contact_phone'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'contact_phone',
            array(
                'label'           => __( 'Contact Phone', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact phone.', 'rara-business-pro' ),
                'section'         => 'contact_section',
                'active_callback' => 'rara_business_pro_contact_ac'
            )
        );

        /** Contact Address  */
        $wp_customize->add_setting(
            'contact_address',
            array(
                'default'           => $default_options['contact_address'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'contact_address',
            array(
                'label'           => __( 'Contact Address', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact address.', 'rara-business-pro' ),
                'section'         => 'contact_section',
                'type'            => 'textarea', 
                'active_callback' => 'rara_business_pro_contact_ac'                                   
            )
        );

        /** Contact Email  */
        $wp_customize->add_setting(
            'contact_email',
            array(
                'default'           => $default_options['contact_email'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'contact_email',
            array(
                'label'           => __( 'Contact Email', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact email.', 'rara-business-pro' ),
                'section'         => 'contact_section',
                'active_callback' => 'rara_business_pro_contact_ac'
            )
        );

        /** As in header */
        $wp_customize->add_setting(
            'ed_social_links_as_in_header',
            array(
                'default'           => $default_options['ed_social_links_as_in_header'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_social_links_as_in_header',
                array(
                    'label'           => __( 'Show Social Links as in Header', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show social links as in header section.', 'rara-business-pro' ),
                    'section'         => 'contact_section',
                    'active_callback' => 'rara_business_pro_contact_ac'
                )            
            )
        );

        // Social media controls
        $wp_customize->add_setting( 
            new Rara_Business_Pro_Repeater_Setting( 
                $wp_customize, 
                'contact_social_links', 
                array(
                    'default' => $default_options['contact_social_links'],
                    'sanitize_callback' => array( 'Rara_Business_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),
                ) 
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Control_Repeater(
                $wp_customize,
                'contact_social_links',
                array(
                    'section' => 'contact_section',               
                    'label'   => __( 'Social Links', 'rara-business-pro' ),
                    'fields'  => array(
                        'font' => array(
                            'type'        => 'font',
                            'label'       => __( 'Font Awesome Icon', 'rara-business-pro' ),
                            'description' => __( 'Example: fa-bell', 'rara-business-pro' ),
                        ),
                        'link' => array(
                            'type'        => 'url',
                            'label'       => __( 'Link', 'rara-business-pro' ),
                            'description' => __( 'Example: http://facebook.com', 'rara-business-pro' ),
                        )
                    ),
                    'row_label' => array(
                        'type'  => 'field',
                        'value' => __( 'links', 'rara-business-pro' ),
                        'field' => 'link'
                    ),
                    'active_callback' => 'rara_business_pro_contact_ac',                 
                )
            )
        );

        if( $cf7_activated ){
            $cf7_description =  __( 'Enter contact form 7 shortcode here.', 'rara-business-pro' );
        }else{
            $cf7_description = sprintf( __( 'Please install/activate the %1$sContact Form 7%2$s plugin to add shortcode.', 'rara-business-pro' ), '<a href="' . admin_url( 'themes.php?page=tgmpa-install-plugins' ) . '" target="_blank">', '</a>' );
        }

        /** Enable google map */
        $wp_customize->add_setting(
            'ed_frontpage_google_map',
            array(
                'default'           => $default_options['ed_frontpage_google_map'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_frontpage_google_map',
                array(
                    'label'           => __( 'Show Google Map', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show google map.', 'rara-business-pro' ),
                    'section'         => 'contact_section',
                    'active_callback' => 'rara_business_pro_contact_ac'
                )            
            )
        );

        /** CF7 Shortcode */
        $wp_customize->add_setting(
            'contact_cf7_shortcode',
            array(
                'default'           =>  $default_options['contact_cf7_shortcode'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );
        
        $wp_customize->add_control(
            'contact_cf7_shortcode',
            array(
                'label'           => __( 'CF7 Shortcode', 'rara-business-pro' ),
                'description'     => $cf7_description,
                'section'         => 'contact_section',
                'active_callback' => 'rara_business_pro_contact_ac'
            )
        );
        
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_contact_section' );

if ( ! function_exists( 'rara_business_pro_contact_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_contact_ac( $control ){
        $enabled_sections         = $control->manager->get_setting( 'sort_frontpage_section' )->value();
        $show_contact_section     = in_array( 'contact', $enabled_sections ) ? true : false;
        $header_contact_ctrl      = $control->manager->get_setting( 'ed_header_contact_details' )->value();
        $header_social_link_ctrl  = $control->manager->get_setting( 'ed_header_social_links' )->value();
        $show_contact_from_header = $control->manager->get_setting( 'ed_contact_detail_as_in_header' )->value();
        $show_social_from_header  = $control->manager->get_setting( 'ed_social_links_as_in_header' )->value();
        $control_id               = $control->id;

        // Contact title, description
        if ( $control_id == 'contact_section_notes' &&  $show_contact_section ) return true;
        if ( $control_id == 'contact_title' &&  $show_contact_section ) return true;
        if ( $control_id == 'contact_description' &&  $show_contact_section ) return true;

        // Contact Details
        if ( $control_id == 'contact_details_notes' &&  $show_contact_section ) return true;
        if ( $control_id == 'ed_contact_detail_as_in_header' &&  $show_contact_section && $header_contact_ctrl ) return true;
        if ( $control_id == 'contact_phone' &&  $show_contact_section && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;
        if ( $control_id == 'contact_address' &&  $show_contact_section && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;
        if ( $control_id == 'contact_email' &&  $show_contact_section && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;

        // Social links
        if ( $control_id == 'ed_social_links_as_in_header' &&  $show_contact_section && $header_social_link_ctrl ) return true;
        if ( $control_id == 'contact_social_links' &&  $show_contact_section && ( ! $header_social_link_ctrl || $header_social_link_ctrl && ! $show_social_from_header ) ) return true;

        // Google Map
        if ( $control_id == 'ed_frontpage_google_map' &&  $show_contact_section ) return true;
        
        // Contact form
        if ( $control_id == 'contact_cf7_shortcode' &&  $show_contact_section ) return true;

        return false;
    }
endif;