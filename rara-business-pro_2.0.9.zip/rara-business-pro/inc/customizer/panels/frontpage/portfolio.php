<?php
/**
 * Portfolio Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_portfolio_section' ) ) :
    /**
     * Add portfolio section controls
     */
    function rara_business_pro_customize_register_portfolio_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Portfolio Sectopm */
        $wp_customize->add_section(
            'portfolio_section',
            array(
                'title'    => __( 'Portfolio Section', 'rara-business-pro' ),
                'priority' => 85,
                'panel'    => 'frontpage_panel',
            )
        );

        if ( rara_business_pro_is_rara_theme_companion_activated() ) {

            /** Portfolio title */
            $wp_customize->add_setting(
                'portfolio_title',
                array(
                    'default'           => $default_options['portfolio_title'],
                    'sanitize_callback' => 'sanitize_text_field',
                    'transport'         => 'postMessage'
                )
            );
            
            $wp_customize->add_control(
                'portfolio_title',
                array(
                    'section'         => 'portfolio_section',
                    'label'           => __( 'Portfolio Title', 'rara-business-pro' ),
                    'active_callback' => 'rara_business_pro_portfolio_ac'
                )
            );

            // Selective refresh for portfolio title.
            $wp_customize->selective_refresh->add_partial( 'portfolio_title', array(
                'selector'            => '.portfolio .widget_text h2.widget-title',
                'render_callback'     => 'rara_business_pro_portfolio_title_selective_refresh',
                'container_inclusive' => false,
                'fallback_refresh'    => true,
            ) );

            /** Portfolio description */
            $wp_customize->add_setting(
                'portfolio_description',
                array(
                    'default'           => $default_options['portfolio_description'],
                    'sanitize_callback' => 'wp_kses_post',
                    'transport'         => 'postMessage'
                )
            );
            
            $wp_customize->add_control(
                'portfolio_description',
                array(
                    'section'         => 'portfolio_section',
                    'label'           => __( 'Portfolio Description', 'rara-business-pro' ),
                    'type'            => 'textarea',
                    'active_callback' => 'rara_business_pro_portfolio_ac'
                )
            );

            // Selective refresh for portfolio description.
            $wp_customize->selective_refresh->add_partial( 'portfolio_description', array(
                'selector'            => '.portfolio .textwidget p',
                'render_callback'     => 'rara_business_pro_portfolio_description_selective_refresh',
                'container_inclusive' => false,
                'fallback_refresh'    => true,
            ) );

            /** Number Of Portfolio Posts */
            $wp_customize->add_setting(
                'portfolio_no_of_posts',
                array(
                    'default'           => $default_options['portfolio_no_of_posts'],
                    'sanitize_callback' => 'rara_business_pro_sanitize_select'
                )
            );

            $wp_customize->add_control(
                new Rara_Business_Pro_Select_Control(
                    $wp_customize,
                    'portfolio_no_of_posts',
                    array(
                        'label'       => __( 'Number of Posts', 'rara-business-pro' ),
                        'description' => __( 'Choose number of portfolio posts to be displayed.', 'rara-business-pro' ),
                        'section'     => 'portfolio_section',
                        'choices'     => array(
                            '5'     => __( '5', 'rara-business-pro' ),
                            '10'    => __( '10', 'rara-business-pro' ),
                        ),
                        'active_callback' => 'rara_business_pro_portfolio_ac'
                    )            
                )
            );

            // readmore button label.
            $wp_customize->add_setting(
                'fp_portfolio_viewall_label',
                array(
                    'default'           => $default_options['fp_portfolio_viewall_label'],
                    'sanitize_callback' => 'sanitize_text_field', 
                    'transport'         => 'postMessage'
                )
            );
                
            $wp_customize->add_control(
                'fp_portfolio_viewall_label',
                array(
                    'section'         => 'portfolio_section',
                    'label'           => esc_html__( 'View All Label', 'rara-business-pro' ),
                    'active_callback' => 'rara_business_pro_portfolio_ac'
                )
            );

            $wp_customize->selective_refresh->add_partial( 'fp_portfolio_viewall_label', array(
                'selector' => '.home .portfolio .btn-holder a.btn-view',
                'render_callback' => 'rara_business_pro_get_fp_portfolio_viewall_label',
            ) );

        } else {
            /** Activate RaraTheme Companion Plugin Note */
            $wp_customize->add_setting(
                'portfolio_note',
                array(
                    'sanitize_callback' => 'wp_kses_post' 
                )
            );
            
            $wp_customize->add_control(
                new Rara_Business_Pro_Note_Control( 
                    $wp_customize,
                    'portfolio_note',
                    array(
                        'section'         => 'portfolio_section',
                        'description'     => sprintf( __( 'Please install and activate the recommended plugin %1$sRaraTheme Companion%2$s.', 'rara-business-pro' ), '<a href="' . esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ) . '" target="_blank">', '</a>' ),
                        'active_callback' => 'rara_business_pro_portfolio_ac'
                    )
                )
            );
        }
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_portfolio_section' );

if ( ! function_exists( 'rara_business_pro_portfolio_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_portfolio_ac( $control ){
        $enabled_sections       = $control->manager->get_setting( 'sort_frontpage_section' )->value();
        $portfolio_template_link = rara_business_pro_get_template_page_url( 'templates/portfolio.php' );
        $show_portfolio_section = in_array( 'portfolio', $enabled_sections ) ? true : false;
        $control_id             = $control->id;

        // Portfolio title, description and number of posts controls
        if ( $control_id == 'portfolio_title' &&  $show_portfolio_section ) return true;
        if ( $control_id == 'portfolio_description' && $show_portfolio_section ) return true;
        if ( $control_id == 'portfolio_no_of_posts' && $show_portfolio_section ) return true;
        if ( $control_id == 'portfolio_note' && $show_portfolio_section ) return true;
        if ( $control_id == 'fp_portfolio_viewall_label' && $show_portfolio_section && $portfolio_template_link ) return true;

        return false;
    }
endif;