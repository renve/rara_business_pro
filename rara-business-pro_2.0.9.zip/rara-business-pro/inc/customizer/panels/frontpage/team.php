<?php
/**
 * Frontpage Team Widget
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_frontpage_team_widget' ) ) :
    /**
     * Add frontpage team section controls
     */
    function rara_business_pro_customize_register_frontpage_team_widget( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Team Secton */
        $wp_customize->add_section(
            'frontpage_team_widget',
            array(
                'title'    => __( 'Team Widget', 'rara-business-pro' ),
                'priority' => 55,
                'panel'    => 'frontpage_panel',
            )
        );

        // readmore button label.
        $wp_customize->add_setting(
            'fp_team_viewall_label',
            array(
                'default'           => $default_options['fp_team_viewall_label'],
                'sanitize_callback' => 'sanitize_text_field', 
                'transport'         => 'postMessage'
            )
        );
            
        $wp_customize->add_control(
            'fp_team_viewall_label',
            array(
                'section'         => 'frontpage_team_widget',
                'priority'        => 100,
                'label'           => esc_html__( 'View All Label', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_frontpage_team_widget_ac'
            )
        );

        $wp_customize->selective_refresh->add_partial( 'fp_team_viewall_label', array(
            'selector' => '.home .our-team .container .btn-holder a.btn-view',
            'render_callback' => 'rara_business_pro_get_fp_team_viewall_label',
        ) );

        $frontpage_team_widget = $wp_customize->get_section( 'sidebar-widgets-team' );

        if ( ! empty( $frontpage_team_widget ) ) {
            $frontpage_team_widget->panel = 'frontpage_panel';
            $frontpage_team_widget->priority = 55;
            $wp_customize->get_control( 'fp_team_viewall_label' )->section  = 'sidebar-widgets-team';
        }
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_frontpage_team_widget' );

if ( ! function_exists( 'rara_business_pro_frontpage_team_widget_ac' ) ) :

    /**
     * Active Callback
     */
    function rara_business_pro_frontpage_team_widget_ac( $control ){
        $team_template_link = rara_business_pro_get_template_page_url( 'templates/team.php' );
        $control_id         = $control->id;

        // Team view all label
        if ( $control_id == 'fp_team_viewall_label' && $team_template_link ) return true;

        return false;
    }
endif;