<?php
/**
 * H3 ( Content ) Typography Options
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_typography_h3' ) ) :
    /**
     * Add h3 content typography controls
     */
    function rara_business_pro_customize_register_typography_h3( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** H3 Settings */
        $wp_customize->add_section( 'typography_h3_section', array(
            'title'      => __( 'H3 Settings (Content)', 'rara-business-pro' ),
            'priority'   => 11,
            'capability' => 'edit_theme_options',
            'panel'      => 'typography_panel'
        ) );
        
        /** H3 Font */
        $wp_customize->add_setting( 'h3_font', array(
            'default'           => $default_options['h3_font'],
            'sanitize_callback' => array( 'Rara_Business_Pro_Fonts', 'sanitize_typography' )
        ) );

        $wp_customize->add_control( 
            new Rara_Business_Pro_Typography_Control( 
                $wp_customize, 
                'h3_font', 
                array(
                    'label'       => __( 'H3 Font', 'rara-business-pro' ),
                    'section'     => 'typography_h3_section',     
                ) 
             ) 
        );
        
        /** H3 Font Size */
        $wp_customize->add_setting( 'h3_font_size', array(
            'default'           => $default_options['h3_font_size'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
        ) );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Slider_Control( 
                $wp_customize,
                'h3_font_size',
                array(
                    'section'     => 'typography_h3_section',
                    'label'       => __( 'H3 Font Size', 'rara-business-pro' ),
                    'choices'     => array(
                        'min'     => 20,
                        'max'     => 70,
                        'step'    => 1,
                    )
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_typography_h3' );