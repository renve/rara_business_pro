<?php
/**
 * Body Typography Options
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_typography_body' ) ) :
    /**
     * Add body typography controls
     */
    function rara_business_pro_customize_register_typography_body( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** Body Settings */
        $wp_customize->add_section( 'typography_body_section', array(
            'title'      => __( 'Body Settings', 'rara-business-pro' ),
            'priority'   => 11,
            'capability' => 'edit_theme_options',
            'panel'      => 'typography_panel'
        ) );
        
        /** Primary Font */
        $wp_customize->add_setting( 'primary_font', array(
            'default'           => $default_options['primary_font'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
    	) );

    	$wp_customize->add_control( 
            new Rara_Business_Pro_Select_Control( 
                $wp_customize, 
                'primary_font', 
                array(
                    'label'           => __( 'Primary Font', 'rara-business-pro' ),
                    'description'     => __( 'Primary font of the site.', 'rara-business-pro' ),
                    'section'         => 'typography_body_section',
                    'choices'         => rara_business_pro_get_all_fonts(),
                    'active_callback' => 'rara_business_pro_fonts_callback'	
            	) 
             ) 
        );
        
        /** Primary Font Size */
        $wp_customize->add_setting( 'primary_font_size', array(
            'default'           => $default_options['primary_font_size'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
        ) );
        
        $wp_customize->add_control(
    		new Rara_Business_Pro_Slider_Control( 
    			$wp_customize,
    			'primary_font_size',
    			array(
                    'section'     => 'typography_body_section',
                    'label'       => __( 'Primary Font Size', 'rara-business-pro' ),
                    'description' => __( 'Change primary font size of your site.', 'rara-business-pro' ),
                    'choices'     => array(
                        'min'         => 10,
                        'max'         => 35,
                        'step'        => 1,
                    ),
    			)
    		)
    	);
        
        /** Secondary Font */
        $wp_customize->add_setting( 'secondary_font', array(
            'default'           => $default_options['secondary_font'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
        ) );

        $wp_customize->add_control( 
            new Rara_Business_Pro_Select_Control( 
                $wp_customize, 
                'secondary_font', 
                array(
                    'label'           => __( 'Secondary Font', 'rara-business-pro' ),
                    'description'     => __( 'Secondary font of the site.', 'rara-business-pro' ),
                    'section'         => 'typography_body_section',
                    'choices'         => rara_business_pro_get_all_fonts(),  
                    'active_callback' => 'rara_business_pro_fonts_callback'     
                ) 
             ) 
        );

        /** Software Company Primary Font */
        $wp_customize->add_setting(
            'primary_font_sc',
            array(
                'default'           => $default_options['primary_font_sc'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'primary_font_sc',
                array(
                    'label'       => __( 'Primary Font', 'rara-business-pro' ),
                    'description' => __( 'Primary font of the site.', 'rara-business-pro' ),
                    'section'     => 'typography_body_section',
                    'choices'     => rara_business_pro_get_all_fonts(),
                    'active_callback' => 'rara_business_pro_fonts_callback',   
                )
            )
        );
        
        /** Software Company Secondary Font */
        $wp_customize->add_setting(
            'secondary_font_sc',
            array(
                'default'           => $default_options['secondary_font_sc'],
                'sanitize_callback' => 'rara_business_pro_sanitize_select'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Select_Control(
                $wp_customize,
                'secondary_font_sc',
                array(
                    'label'       => __( 'Secondary Font', 'rara-business-pro' ),
                    'description' => __( 'Secondary font of the site.', 'rara-business-pro' ),
                    'section'     => 'typography_body_section',
                    'choices'     => rara_business_pro_get_all_fonts(),
                    'active_callback' => 'rara_business_pro_fonts_callback',   
                )
            )
        );  
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_typography_body' );

/**
 * Active Callback
*/
function rara_business_pro_fonts_callback( $control ){
    
    $child_theme_support    = $control->manager->get_setting( 'child_additional_support' )->value();
    $control_id             = $control->id;
    
    if ( $control_id == 'primary_font' && $child_theme_support == 'default' ) return true;
    if ( $control_id == 'secondary_font' && $child_theme_support == 'default' ) return true;
    if ( $control_id == 'primary_font_sc' && $child_theme_support == 'software_company' ) return true;
    if ( $control_id == 'secondary_font_sc' && $child_theme_support == 'software_company' ) return true;
        
    return false;
}