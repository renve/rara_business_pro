<?php
/**
 * H1 ( Content ) Typography Options
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_typography_h1' ) ) :
    /**
     * Add h1 content typography controls
     */
    function rara_business_pro_customize_register_typography_h1( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        /** H1 Settings */
        $wp_customize->add_section( 'typography_h1_section', array(
            'title'      => __( 'H1 Settings (Content)', 'rara-business-pro' ),
            'priority'   => 11,
            'capability' => 'edit_theme_options',
            'panel'      => 'typography_panel'
        ) );
        
        /** H1 Font */
        $wp_customize->add_setting( 'h1_font', array(
            'default'           => $default_options['h1_font'],
            'sanitize_callback' => array( 'Rara_Business_Pro_Fonts', 'sanitize_typography' )
        ) );

        $wp_customize->add_control( 
            new Rara_Business_Pro_Typography_Control( 
                $wp_customize, 
                'h1_font', 
                array(
                    'label'       => __( 'H1 Font', 'rara-business-pro' ),
                    'section'     => 'typography_h1_section',     
                ) 
             ) 
        );
        
        /** H1 Font Size */
        $wp_customize->add_setting( 'h1_font_size', array(
            'default'           => $default_options['h1_font_size'],
            'sanitize_callback' => 'rara_business_pro_sanitize_select'
        ) );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Slider_Control( 
                $wp_customize,
                'h1_font_size',
                array(
                    'section'     => 'typography_h1_section',
                    'label'       => __( 'H1 Font Size', 'rara-business-pro' ),
                    'choices'     => array(
                        'min'     => 25,
                        'max'     => 75,
                        'step'    => 1,
                    )
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_typography_h1' );