<?php
/**
 * Team Template Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_team_template_panel' ) ) :
	/**
	 * Add team template panel
	 */
	function rara_business_pro_customize_register_team_template_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'team_template_panel', array(
	        'title'          => __( 'Team Template Settings', 'rara-business-pro' ),
	        'priority'       => 40,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_team_template_panel' );