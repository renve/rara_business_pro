<?php
/**
 * Typography Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_typography_panel' ) ) :
	/**
	 * Add typography panel
	 */
	function rara_business_pro_customize_register_typography_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'typography_panel', array(
	        'title'          => __( 'Typography Settings', 'rara-business-pro' ),
	        'priority'       => 120,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_typography_panel' );