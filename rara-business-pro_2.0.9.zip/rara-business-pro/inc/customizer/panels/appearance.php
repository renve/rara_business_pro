<?php
/**
 * Appearance Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_appearance_panel' ) ) :
	/**
	 * Add Appearance panel
	 */
	function rara_business_pro_customize_register_appearance_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'appearance_panel', array(
	        'title'          => __( 'Appearance Settings', 'rara-business-pro' ),
	        'priority'       => 90,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_appearance_panel' );