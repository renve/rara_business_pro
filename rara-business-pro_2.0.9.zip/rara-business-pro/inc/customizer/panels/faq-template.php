<?php
/**
 * Faq Template Panel
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_faq_template_panel' ) ) :
	/**
	 * Add team template panel
	 */
	function rara_business_pro_customize_register_faq_template_panel( $wp_customize ) {

	    $wp_customize->add_panel( 'faq_template_panel', array(
	        'title'          => __( 'Faq Template Settings', 'rara-business-pro' ),
	        'priority'       => 60,
	        'capability'     => 'edit_theme_options',
	    ) );
	    
	}
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_faq_template_panel' );