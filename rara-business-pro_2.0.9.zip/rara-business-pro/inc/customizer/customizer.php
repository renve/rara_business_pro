<?php
/**
 * Rara Business Theme Customizer
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register' ) ) :
    /**
     * Add postMessage support for site title and description for the Theme Customizer.
     *
     * @param WP_Customize_Manager $wp_customize Theme Customizer object.
     */
    function rara_business_pro_customize_register( $wp_customize ) {
        $wp_customize->get_section( 'background_image' )->priority = 40;
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register' );

$rara_business_pro_panels       = array( 'frontpage', 'team-template', 'testimonial-template', 'faq-template', 'typography', 'appearance', 'layout', 'general' );
$rara_business_pro_sections     = array( 'site-identity', 'contact-template', 'sidebar', 'footer' );

$rara_business_pro_sub_sections = array(
    'frontpage'  => array( 'banner', 'team', 'testimonial', 'portfolio', 'blog', 'faq', 'contact', 'frontpage-sort', 'onepage' ),
    'typography' => array( 'body', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ),
    'appearance' => array( 'background', 'color' ),
    'layout'     => array( 'header-layout', 'general-sidebar-layout', 'pagination' ),
    'general'    => array( 'header', 'seo', 'post-page', 'social-share', 'google-map', 'misc', 'performance', 'child-theme-support' ),
);

/**
 * Reset Theme Options
 */
require get_template_directory() . '/inc/customizer/customizer-reset/customizer-reset.php';

foreach( $rara_business_pro_panels as $p ){
   require get_template_directory() . '/inc/customizer/panels/' . $p . '.php';
}

foreach( $rara_business_pro_sections as $s ){
    require get_template_directory() . '/inc/customizer/sections/' . $s . '.php';
}

foreach( $rara_business_pro_sub_sections as $k => $v ){
    foreach( $v as $w ){        
        require get_template_directory() . '/inc/customizer/panels/' . $k . '/' . $w . '.php';
    }
}

if ( ! function_exists( 'rara_business_pro_customize_preview_js' ) ) :
    /**
     * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
     */
    function rara_business_pro_customize_preview_js() {
        wp_enqueue_script( 'rara-business-pro-customizer', get_template_directory_uri() . '/js/build/customizer.js', array( 'customize-preview' ), '20151215', true );
    }
endif;
add_action( 'customize_preview_init', 'rara_business_pro_customize_preview_js' );

if ( ! function_exists( 'rara_business_pro_customizer_script' ) ) :
    /**
     * Customizer Scripts
     */
    function rara_business_pro_customizer_script(){
        wp_enqueue_script( 'rara-business-pro-customize-controls', get_template_directory_uri() . '/inc/js/customize-controls.js', array('jquery', 'customize-controls' ), false, true  );

        $contact_page_url     = rara_business_pro_get_template_page_url( 'templates/contact.php', 'page' );
        $frontpage_url        = get_permalink( get_option( 'page_on_front' ) );
        $team_page_url        = rara_business_pro_get_template_page_url( 'templates/team.php', 'page' );
        $faq_page_url         = rara_business_pro_get_template_page_url( 'templates/faq.php', 'page' );
        $testimonial_page_url = rara_business_pro_get_template_page_url( 'templates/testimonial.php', 'page' );

        $array = array(
            'url1'          => $contact_page_url,
            'url2'          => $frontpage_url,
            'url3'          => $team_page_url,
            'url4'          => $faq_page_url,
            'url5'          => $testimonial_page_url,
        );

        wp_localize_script( 'rara-business-pro-customize-controls', 'rbp_customizer_data', $array );
    }
endif;
add_action( 'customize_controls_enqueue_scripts', 'rara_business_pro_customizer_script' );

/*
 * Notifications in customizer
 */
require get_template_directory() . '/inc/customizer-plugin-recommend/customizer-notice/class-customizer-notice.php';

require get_template_directory() . '/inc/customizer-plugin-recommend/plugin-install/class-plugin-install-helper.php';

$config_customizer = array(
    'recommended_plugins' => array( 
        'raratheme-companion' => array(
            'recommended' => true,
            'description' => sprintf( 
                /* translators: %s: plugin name */
                esc_html__( 'If you want to take full advantage of the features this theme has to offer, please install and activate %s plugin.', 'rara-business-pro' ), '<strong>RaraTheme Companion</strong>' 
            ),
        ),
    ),
    'recommended_plugins_title' => esc_html__( 'Recommended Plugin', 'rara-business-pro' ),
    'install_button_label'      => esc_html__( 'Install and Activate', 'rara-business-pro' ),
    'activate_button_label'     => esc_html__( 'Activate', 'rara-business-pro' ),
    'deactivate_button_label'   => esc_html__( 'Deactivate', 'rara-business-pro' ),
);
Rara_Business_Pro_Customizer_Notice::init( apply_filters( 'rara_business_customizer_notice_array', $config_customizer ) );
