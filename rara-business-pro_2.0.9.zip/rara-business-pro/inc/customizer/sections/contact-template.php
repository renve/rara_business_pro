<?php
/**
 * Contact Template Section
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_customize_register_contact_template_section' ) ) :
    /**
     * Add contact template section controls
     */
    function rara_business_pro_customize_register_contact_template_section( $wp_customize ) {
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();
        // check if contact form 7 plugin is activated
        $cf7_activated   =  rara_business_pro_is_cf7_activated(); 

        /** Contact Section */
        $wp_customize->add_section(
            'contact_template_section',
            array(
                'title'    => __( 'Contact Template Settings', 'rara-business-pro' ),
                'priority' => 60,
            )
        );

        /** Show contact form */
        $wp_customize->add_setting(
            'ed_ct_cf7_as_in_frontpage',
            array(
                'default'           => $default_options['ed_ct_cf7_as_in_frontpage'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_ct_cf7_as_in_frontpage',
                array(
                    'label'           => __( 'Show Contact Form as in Frontpage.', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show contact form as in frontpage contact section.', 'rara-business-pro' ),
                    'section'         => 'contact_template_section',
                    'active_callback' => 'rara_business_pro_contact_template_ac'
                )            
            )
        );

        if( $cf7_activated ){
            $cf7_description =  __( 'Enter contact form 7 shortcode here.', 'rara-business-pro' );
        }else{
            $cf7_description = sprintf( __( 'Please install/activate the %1$sContact Form 7%2$s plugin to add shortcode.', 'rara-business-pro' ), '<a href="' . admin_url( 'themes.php?page=tgmpa-install-plugins' ) . '" target="_blank">', '</a>' );
        }

        /** CF7 Shortcode */
        $wp_customize->add_setting(
            'ct_cf7_shortcode',
            array(
                'default'           =>  $default_options['ct_cf7_shortcode'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );
        
        $wp_customize->add_control(
            'ct_cf7_shortcode',
            array(
                'label'           => __( 'CF7 Shortcode', 'rara-business-pro' ),
                'description'     => $cf7_description,
                'section'         => 'contact_template_section',
                'active_callback' => 'rara_business_pro_contact_template_ac'
            )
        );

        /** Show google map */
        $wp_customize->add_setting(
            'ed_ct_google_map',
            array(
                'default'           => $default_options['ed_ct_google_map'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_ct_google_map',
                array(
                    'label'           => __( 'Show Google Map.', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show google map. If disabled contact template featured image will be used as fallback.', 'rara-business-pro' ),
                    'section'         => 'contact_template_section',
                )            
            )
        );

        /** Contact Detail Note */
        $wp_customize->add_setting(
            'ct_details_notes',
            array(
                'default'           => '',
                'sanitize_callback' => 'wp_kses_post' 
            )
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Note_Control( 
                $wp_customize,
                'ct_details_notes',
                array(
                    'section'         => 'contact_template_section',
                    'description'     => sprintf( '<hr/><b>%1$s</b>', __( 'Contact Details.', 'rara-business-pro' ) ),
                )
            )
        );

        /** Contact title */
        $wp_customize->add_setting(
            'ct_detail_title',
            array(
                'default'           => $default_options['ct_detail_title'],
                'sanitize_callback' => 'sanitize_text_field',
                'transport'         => 'postMessage'
            )
        );
        
        $wp_customize->add_control(
            'ct_detail_title',
            array(
                'section'         => 'contact_template_section',
                'label'           => __( 'Contact Details Title', 'rara-business-pro' ),
                'active_callback' => 'rara_business_pro_contact_template_ac'
            )
        );

        // Selective refresh for contact title.
        $wp_customize->selective_refresh->add_partial( 'ct_detail_title', array(
            'selector'            => '.contact-grid .contact-info h3',
            'render_callback'     => 'rara_business_pro_ct_detail_title_selective_refresh',
            'container_inclusive' => false,
            'fallback_refresh'    => true,
        ) );

        /** As in header */
        $wp_customize->add_setting(
            'ed_ct_detail_as_in_header',
            array(
                'default'           => $default_options['ed_ct_detail_as_in_header'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_ct_detail_as_in_header',
                array(
                    'label'           => __( 'Show Contact Details as in Header', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show contact details as in header section.', 'rara-business-pro' ),
                    'section'         => 'contact_template_section',
                    'active_callback' => 'rara_business_pro_contact_template_ac'
                )            
            )
        );

        /** Contact Phone  */
        $wp_customize->add_setting(
            'ct_phone',
            array(
                'default'           => $default_options['ct_phone'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'ct_phone',
            array(
                'label'           => __( 'Contact Phone', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact phone.', 'rara-business-pro' ),
                'section'         => 'contact_template_section',
                'active_callback' => 'rara_business_pro_contact_template_ac'
            )
        );

        /** Contact Address  */
        $wp_customize->add_setting(
            'ct_address',
            array(
                'default'           => $default_options['ct_address'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'ct_address',
            array(
                'label'           => __( 'Contact Address', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact address.', 'rara-business-pro' ),
                'section'         => 'contact_template_section',
                'type'            => 'textarea', 
                'active_callback' => 'rara_business_pro_contact_template_ac'                                   
            )
        );

        /** Contact Email  */
        $wp_customize->add_setting(
            'ct_email',
            array(
                'default'           => $default_options['ct_email'],
                'sanitize_callback' => 'wp_kses_post',
            )
        );

        $wp_customize->add_control(
            'ct_email',
            array(
                'label'           => __( 'Contact Email', 'rara-business-pro' ),
                'description'     => __( 'Enter the contact email.', 'rara-business-pro' ),
                'section'         => 'contact_template_section',
                'active_callback' => 'rara_business_pro_contact_template_ac'
            )
        );

        /** As in header */
        $wp_customize->add_setting(
            'ed_ct_sl_as_in_header',
            array(
                'default'           => $default_options['ed_ct_sl_as_in_header'],
                'sanitize_callback' => 'rara_business_pro_sanitize_checkbox'
            )
        );

        $wp_customize->add_control(
            new Rara_Business_Pro_Toggle_Control(
                $wp_customize,
                'ed_ct_sl_as_in_header',
                array(
                    'label'           => __( 'Show Social Links as in Header', 'rara-business-pro' ),
                    'description'     => __( 'Enable to show social links as in header section.', 'rara-business-pro' ),
                    'section'         => 'contact_template_section',
                    'active_callback' => 'rara_business_pro_contact_template_ac'
                )            
            )
        );

        // Social media controls
        $wp_customize->add_setting( 
            new Rara_Business_Pro_Repeater_Setting( 
                $wp_customize, 
                'ct_social_links', 
                array(
                    'default' => $default_options['ct_social_links'],
                    'sanitize_callback' => array( 'Rara_Business_Pro_Repeater_Setting', 'sanitize_repeater_setting' ),
                ) 
            ) 
        );
        
        $wp_customize->add_control(
            new Rara_Business_Pro_Control_Repeater(
                $wp_customize,
                'ct_social_links',
                array(
                    'section' => 'contact_template_section',               
                    'label'   => __( 'Social Links', 'rara-business-pro' ),
                    'fields'  => array(
                        'font' => array(
                            'type'        => 'font',
                            'label'       => __( 'Font Awesome Icon', 'rara-business-pro' ),
                            'description' => __( 'Example: fa-bell', 'rara-business-pro' ),
                        ),
                        'link' => array(
                            'type'        => 'url',
                            'label'       => __( 'Link', 'rara-business-pro' ),
                            'description' => __( 'Example: http://facebook.com', 'rara-business-pro' ),
                        )
                    ),
                    'row_label' => array(
                        'type'  => 'field',
                        'value' => __( 'links', 'rara-business-pro' ),
                        'field' => 'link'
                    ),
                    'active_callback' => 'rara_business_pro_contact_template_ac',                 
                )
            )
        );
    }
endif;
add_action( 'customize_register', 'rara_business_pro_customize_register_contact_template_section' );

if ( ! function_exists( 'rara_business_pro_contact_template_ac' ) ) :
    /**
     * Active Callback
     */
    function rara_business_pro_contact_template_ac( $control ){
        $show_cf_frontpage        = $control->manager->get_setting( 'ed_ct_cf7_as_in_frontpage' )->value();
        $contact_frontpage        = $control->manager->get_setting( 'contact_cf7_shortcode' )->value();
        $header_contact_ctrl      = $control->manager->get_setting( 'ed_header_contact_details' )->value();
        $header_social_link_ctrl  = $control->manager->get_setting( 'ed_header_social_links' )->value();
        $show_contact_from_header = $control->manager->get_setting( 'ed_ct_detail_as_in_header' )->value();
        $show_social_from_header  = $control->manager->get_setting( 'ed_ct_sl_as_in_header' )->value();
        $control_id               = $control->id;

        // Contact form 
        if ( $control_id == 'ed_ct_cf7_as_in_frontpage' && ! empty( $contact_frontpage ) ) return true;
        if ( $control_id == 'ct_cf7_shortcode' &&  ( empty( $contact_frontpage ) || ! empty( $contact_frontpage ) && ! $show_cf_frontpage )) return true;

        // Contact Details
        if ( $control_id == 'ed_ct_detail_as_in_header' && $header_contact_ctrl ) return true;
        if ( $control_id == 'ct_phone' && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;
        if ( $control_id == 'ct_address' && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;
        if ( $control_id == 'ct_email' && ( ! $header_contact_ctrl || $header_contact_ctrl && ! $show_contact_from_header ) ) return true;

        // Social links
        if ( $control_id == 'ed_ct_sl_as_in_header' && $header_social_link_ctrl ) return true;
        if ( $control_id == 'ct_social_links' && ( ! $header_social_link_ctrl || $header_social_link_ctrl && ! $show_social_from_header ) ) return true;

        return false;
    }
endif;