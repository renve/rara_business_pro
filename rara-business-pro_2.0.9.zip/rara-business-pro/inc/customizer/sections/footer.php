<?php
/**
 * Footer Setting
 *
 * @package Rara_Business_Pro
 */

function rara_business_pro_customize_register_footer( $wp_customize ) {
                                                                           
    // Get default theme options
    $default_options = rara_business_pro_default_theme_options();

    $wp_customize->add_section(
        'footer_settings',
        array(
            'title'      => __( 'Footer Settings', 'rara-business-pro' ),
            'priority'   => 199,
            'capability' => 'edit_theme_options',
        )
    );
    
    /** Footer Copyright */
    $wp_customize->add_setting(
        'footer_copyright',
        array(
            'default'           => '',
            'sanitize_callback' => 'wp_kses_post',
            'transport'         => 'postMessage'
        )
    );
    
    $wp_customize->add_control(
        'footer_copyright',
        array(
            'label'       => __( 'Footer Copyright Text', 'rara-business-pro' ),
            'section'     => 'footer_settings',
            'type'        => 'textarea',
        )
    );
    
    $wp_customize->selective_refresh->add_partial( 'footer_copyright', array(
        'selector' => '.site-footer .footer-b span.copyright',
        'render_callback' => 'rara_business_pro_get_footer_copyright',
    ) );

     /** Hide Author Link */
    $wp_customize->add_setting(
        'ed_author_link',
        array(
            'default'           => $default_options['ed_author_link'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
        new Rara_Business_Pro_Toggle_Control( 
            $wp_customize,
            'ed_author_link',
            array(
                'section' => 'footer_settings',
                'label'   => __( 'Hide Author Link', 'rara-business-pro' ),
            )
        )
    );
    
    /** Hide WordPress Link */
    $wp_customize->add_setting(
        'ed_wp_link',
        array(
            'default'           => $default_options['ed_wp_link'],
            'sanitize_callback' => 'rara_business_pro_sanitize_checkbox',
        )
    );
    
    $wp_customize->add_control(
        new Rara_Business_Pro_Toggle_Control( 
            $wp_customize,
            'ed_wp_link',
            array(
                'section' => 'footer_settings',
                'label'   => __( 'Hide WordPress Link', 'rara-business-pro' ),
            )
        )
    );
}
add_action( 'customize_register', 'rara_business_pro_customize_register_footer' );