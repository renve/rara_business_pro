<?php
/**
 * Rara Business Theme Customizer Default Value.
 *
 * @package Rara_Business_Pro
 */

function rara_business_pro_default_theme_options() {
	$default_options = array(
		
		// Header section
        'ed_header_contact_details' => true,
        'header_phone'              => __( '1-800-567-0123', 'rara-business-pro' ),
        'header_address'            => __( '12 Street, New York City', 'rara-business-pro' ),
        'header_email'              => __( 'support@raracorporate.com', 'rara-business-pro' ),
        'custom_link_option'        => 'custom',
        'custom_link_icon'          => 'fa fa-edit',
        'custom_link_label'         => __( 'Inquiry', 'rara-business-pro' ),
        'custom_link_page'          => '',
        'custom_link'               => '#',

        'ed_header_social_links' => true,
        'header_social_links'    => array(
            array(
                'font' 			=> 'fa fa-facebook',
                'link' 			=> 'https://www.facebook.com/',                        
            ),
            array(
                'font' 			=> 'fa fa-twitter',
                'link' 			=> 'https://twitter.com/',
            ),
            array(
                'font' 			=> 'fa fa-youtube-play',
                'link' 			=> 'https://www.youtube.com/',
            ),
            array(
                'font' 			=> 'fa fa-instagram',
                'link' 			=> 'https://www.instagram.com/',
            ),
            array(
                'font' 			=> 'fa fa-google-plus-circle',
                'link' 			=> 'https://plus.google.com',
            ),
            array(
                'font' 			=> 'fa fa-odnoklassniki',
                'link' 			=> 'https://ok.ru/',
            ),
            array(
                'font' 			=> 'fa fa-vk',
                'link' 			=> 'https://vk.com/',
            ),
            array(
                'font' 			=> 'fa fa-xing',
                'link' 			=> 'https://www.xing.com/',
            )
        ),
         'header_layout'                  => 'one',
         
         // Colors
         'primary_color_scheme'           => '#0aa3f3',
         'secondary_color_scheme'         => '#9de8fb',
         'primary_color_scheme_sc'        => '#1f3d83',
         'secondary_color_scheme_sc'      => '#2ac59f',
         
         // Seo section
         'ed_post_update_date'            => true,
         'ed_breadcrumb'                  => true,
         'breadcrumb_separator'           => __( '>', 'rara-business-pro' ),
         'home_text'                      => __( 'Home', 'rara-business-pro' ),
         
         // Post/Page section
         'page_sidebar_layout'            => 'right-sidebar',
         'post_sidebar_layout'            => 'right-sidebar',
         'blog_sidebar_layout'            => 'right-sidebar',
         'default_sidebar_layout'         => 'right-sidebar',
         'ed_excerpt'                     => true,
         'excerpt_length'                 => '55',
         'read_more_text'                 => __( 'Read More', 'rara-business-pro' ),
         'post_note_text'                 => '',
         'ed_author'                      => false,
         'ed_related'                     => true,
         'related_post_title'             => __( 'You may also like...', 'rara-business-pro' ),
         'ed_popular_posts'               => true,
         'popular_post_title'             => __( 'Popular Posts', 'rara-business-pro' ),
         'post_meta_order'                => array( 'date', 'author' ),
         'ed_featured_image'              => true,
         'ed_prefix_archive'              => false,
         'ed_comments'                    => true,
         'ed_auth_comments'               => false,
         
         // Social share
         'ed_social_sharing'              => '1',         
         'social_share'                   => array( 'facebook', 'twitter', 'linkedin', 'pinterest' ),   
         
         // Google map section
         'ed_map_scroll'                  => true,
         'ed_map_controls'                => true,
         'ed_map_marker'                  => false,
         'marker_title'                   => '',
         'map_api'                        => '',
         'latitude'                       => 27.7204766,
         'longitude'                      => 85.3389148,
         'map_zoom'                       => 17,
         
         // Miscellaneous settings
         'ed_adminbar'                    => true,
         'ed_animation'                   => true,
         'ed_sticky_header'               => false,
         'ed_scroll_to_top'               => true,
         
         // Banner section 
         'ed_banner_section'              => 'static_banner',
         'banner_title'                   => __( 'Perfectionist at Every Level', 'rara-business-pro' ),
         'banner_description'             => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.', 'rara-business-pro' ),
         'banner_link_one_label'          => __( 'Free Inquiry', 'rara-business-pro' ),
         'banner_link_one_url'            => '#',
         'banner_link_two_label'          => __( 'View Services', 'rara-business-pro' ),
         'banner_link_two_url'            => '#',
         'banner_newsletter'              => '',
         'slider_type'                    => 'latest_posts',
         'slider_cat'                     => '',
         'no_of_slides'                   => 3,
         'slider_pages'                   => '',
         'slider_custom'                  => '',
         'slider_auto'                    => true,
         'slider_loop'                    => true,
         'slider_caption'                 => true,
         'slider_animation'               => '',
         'slider_readmore'                => __( 'Readmore', 'rara-business-pro' ),
         
         // Team section
         'fp_team_viewall_label'              => __( 'View All Team', 'rara-business-pro' ),
         'fp_testimonial_viewall_label'       => __( 'View All Testimonial', 'rara-business-pro' ),
         'fp_portfolio_viewall_label'         => __( 'View All Portfolio', 'rara-business-pro' ),
         'blog_viewall_label'                 => __( 'View All Posts', 'rara-business-pro' ),
         'frontpage_faq_widget_readmore_text' => __( 'View All', 'rara-business-pro' ),

         // Portfolio section
         'portfolio_title'                => __( 'Our Case Studies', 'rara-business-pro' ),
         'portfolio_description'          => __( 'It looks perfect on all major browsers, tablets and phones. The kind of product you&rsquo;re looking for. Phasellus lacus nibh, ullamcorper in pulvinar semper, mollis sed turpis.', 'rara-business-pro' ),
         'portfolio_no_of_posts'          => '10',
         
         // Blog section
         'blog_title'                     => __( 'Our Blog', 'rara-business-pro' ),
         'blog_description'               => __( 'It looks perfect on all major browsers, tablets and phones. The kind of product you &rsquo; re looking for.', 'rara-business-pro' ),
         
         // Contact section
         'ed_contact_section'             => true, 
         'contact_title'                  => __( 'Try Rara Business today!', 'rara-business-pro' ), 
         'contact_description'            => __( 'It looks perfect on all major browsers, tablets and phones. The kind of product you&apos;re looking for.', 'rara-business-pro' ), 
         'ed_contact_detail_as_in_header' => true,
         'contact_phone'                  => __( '1-800-567-0123', 'rara-business-pro' ),
         'contact_address'                => __( '12 Street, New York City', 'rara-business-pro' ),
         'contact_email'                  => __( 'support@raracorporate.com', 'rara-business-pro' ),
         'ed_social_links_as_in_header'   => true,
         'contact_social_links'           => array(
            array(
                'font'          => 'fa fa-facebook',
                'link'          => 'https://www.facebook.com/',                        
            ),
            array(
                'font'          => 'fa fa-twitter',
                'link'          => 'https://twitter.com/',
            ),
            array(
                'font'          => 'fa fa-youtube-play',
                'link'          => 'https://www.youtube.com/',
            ),
            array(
                'font'          => 'fa fa-instagram',
                'link'          => 'https://www.instagram.com/',
            ),
            array(
                'font'          => 'fa fa-google-plus-circle',
                'link'          => 'https://plus.google.com',
            ),
            array(
                'font'          => 'fa fa-odnoklassniki',
                'link'          => 'https://ok.ru/',
            ),
            array(
                'font'          => 'fa fa-vk',
                'link'          => 'https://vk.com/',
            ),
            array(
                'font'          => 'fa fa-xing',
                'link'          => 'https://www.xing.com/',
            )
        ),
        'ed_frontpage_google_map' => true,
        'contact_cf7_shortcode'     => '',
        
        // Contact template
        'ed_ct_cf7_as_in_frontpage' => true,
        'ct_cf7_shortcode'          => '',
        'ed_ct_google_map'          => true,
        'ct_detail_title'           => __( 'Contact Information', 'rara-business-pro' ),
        'ed_ct_detail_as_in_header' => true,
        'ct_phone'                  => __( '1-800-567-0123', 'rara-business-pro' ),
        'ct_address'                => __( '12 Street, New York City', 'rara-business-pro' ),
        'ct_email'                  => __( 'support@raratheme.com', 'rara-business-pro' ),
        'ed_ct_sl_as_in_header'     => true,
        'ct_social_links'           => array(
            array(
                'font'          => 'fa fa-facebook',
                'link'          => 'https://www.facebook.com/',                        
            ),
            array(
                'font'          => 'fa fa-twitter',
                'link'          => 'https://twitter.com/',
            ),
            array(
                'font'          => 'fa fa-youtube-play',
                'link'          => 'https://www.youtube.com/',
            ),
            array(
                'font'          => 'fa fa-instagram',
                'link'          => 'https://www.instagram.com/',
            ),
            array(
                'font'          => 'fa fa-google-plus-circle',
                'link'          => 'https://plus.google.com',
            ),
            array(
                'font'          => 'fa fa-odnoklassniki',
                'link'          => 'https://ok.ru/',
            ),
            array(
                'font'          => 'fa fa-vk',
                'link'          => 'https://vk.com/',
            ),
            array(
                'font'          => 'fa fa-xing',
                'link'          => 'https://www.xing.com/',
            )
        ),

        // Frontpage sort
        'sort_frontpage_section'      => array( 'services','about','choose-us','team','testimonial','stats','skill','portfolio','pricing','blog','cta','faq','contact','client'),
        
        // Onepage settings
        'ed_one_page'                 => false,
        'ed_home_link'                => true,
        'label_service'               => __( 'Service', 'rara-business-pro' ),
        'label_about'                 => __( 'About', 'rara-business-pro' ),
        'label_choose_us'             => __( 'Why Choose Us', 'rara-business-pro' ),
        'label_team'                  => __( 'Team', 'rara-business-pro' ),
        'label_testimonial'           => __( 'Testimonial', 'rara-business-pro' ),
        'label_stats'                 => __( 'Stat Counter', 'rara-business-pro' ),
        'label_skill'                 => __( 'Skill', 'rara-business-pro' ),
        'label_portfolio'             => __( 'Portfolio', 'rara-business-pro' ),
        'label_pricing'               => __( 'Pricing', 'rara-business-pro' ),
        'label_blog'                  => __( 'Blog', 'rara-business-pro' ),
        'label_cta'                   => __( 'CTA', 'rara-business-pro' ),
        'label_faq'                   => __( 'FAQs', 'rara-business-pro' ),
        'label_contact'               => __( 'Contact', 'rara-business-pro' ),
        'label_client'                => __( 'Client', 'rara-business-pro' ),
        
        // Sidebar settings
        'dynamic_sidebar'             => array(),
        'home_page_sidebar'           => 'primary-sidebar',
        'single_page_sidebar'         => 'primary-sidebar',
        'single_post_sidebar'         => 'primary-sidebar',
        'archive_page_sidebar'        => 'primary-sidebar',
        'cat_archive_page_sidebar'    => 'default-sidebar',
        'tag_archive_page_sidebar'    => 'default-sidebar',
        'date_archive_page_sidebar'   => 'default-sidebar',
        'author_archive_page_sidebar' => 'default-sidebar',
        'search_page_sidebar'         => 'primary-sidebar',
        
        // Pagination
        'pagination_type'             => 'numbered',
        'load_more_label'             => esc_html__( 'Load More Posts', 'rara-business-pro' ),
        'loading_label'               => esc_html__( 'Loading...', 'rara-business-pro' ),
        'nomore_post_label'           => esc_html__( 'No more Post', 'rara-business-pro' ),
        
        
        /** Typography */
        // Body 
        'primary_font'                => 'Lato',
        'primary_font_size'           => 20,
        'secondary_font'              => 'Montserrat',
        'primary_font_sc'             => 'Nunito',
        'secondary_font_sc'           => 'Poppins',

        // H1
        'h1_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h1_font_size'                => 60,
        
        // H2
        'h2_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h2_font_size'                => 46,
        
        // H3
        'h3_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h3_font_size'                => 34,
        
        // H4
        'h4_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h4_font_size'                => 22,
        
        // H5
        'h5_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h5_font_size'                => 18,
        
        // H6
        'h6_font'                     => array(         
            'font-family' => 'Montserrat',
            'variant'     => '700',
        ),
        'h6_font_size'                => 16,

        // Background control
        'body_bg'        => 'image',
        'bg_pattern'     => 'nobg',
        
        // Footer control
        'ed_author_link' => false,
        'ed_wp_link'     => false,
        'ed_custom_link_tab' => false,

        // Child theme support
        'child_additional_support' => 'default',
    );

	$output = apply_filters( 'rara_business_pro_default_theme_options', $default_options );

	return $output;
}