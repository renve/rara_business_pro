jQuery(document).ready(function($){

	function check_page_templates(){
        $('.inside #page_template').each(function(i,e){
            if( 
                ( $(this).val() === "templates/contact.php" ) ||
                ( $(this).val() === "templates/faq.php" ) ||
                ( $(this).val() === "templates/portfolio.php" )|| 
                ( $(this).val() === "templates/team.php" ) ||
                ( $(this).val() === "templates/testimonial.php" )
            ){
                $('#rara_business_pro_sidebar_options').hide();
            }else{
                $('#rara_business_pro_sidebar_options').show();
            }
        });
    }
    $('.inside #page_template').on( 'change', check_page_templates );
    
    // Hide metabox options when static front page is set
    if( rb_show_metabox.hide_metabox == '1' ){
        $('#rara_business_pro_sidebar_options').hide();
    }
} )