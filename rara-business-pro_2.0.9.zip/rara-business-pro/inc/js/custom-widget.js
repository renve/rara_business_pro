jQuery(document).ready(function($) {

    $('body').on('click', '#remove-icon-list', function(e) {
        e.preventDefault();
        $(this).parent().fadeOut('slow',function(){
            $(this).remove();
        });
    });
    
    $('body').on('click', '.del-rtc-icon', function() {
        var con = confirm(sociconsmsg.msg);
        if (!con) {
            return false;
        }
        $(this).parent().fadeOut('slow', function() {
            $(this).remove();
            $('ul.rtc-sortable-icons input').trigger('change');
        });
        if ($('.del-rtc-icon').length < 1) {
            $('.rtc-social-add').removeAttr('disabled');
        }
    });

    var frame;

    // ADD IMAGE LINK
    $('body').on('click','.rbp-upload-button',function(e) {
        e.preventDefault();
        var clicked = $(this).closest('div');
        var custom_uploader = wp.media({
            title: 'RARA Image Uploader',
            // button: {
            //     text: 'Custom Button Text',
            // },
            multiple: false  // Set this to true to allow multiple files to be selected
            })
        .on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            var str = attachment.url.split('.').pop(); 
            var strarray = [ 'jpg', 'gif', 'png', 'jpeg' ]; 
            if( $.inArray( str, strarray ) != -1 ){
                clicked.find('.rara-screenshot').empty().hide().append('<img src="' + attachment.url + '"><a class="rbp-remove-image"></a>').slideDown('fast');
            }else{
                clicked.find('.rara-screenshot').empty().hide().append('<small>'+raratheme_companion_uploader.msg+'</small>').slideDown('fast');    
            }
            
            clicked.find('.rbp-upload').val(attachment.id).trigger('change');
            clicked.find('.rbp-upload-button').val(raratheme_companion_uploader.change);
        }) 
        .open();
    });

    $('body').on('click','.rbp-remove-image',function(e) {
        
        var selector = $(this).parent('div').parent('div');
        selector.find('.rbp-upload').val('').trigger('change');
        selector.find('.rbp-remove-image').hide();
        selector.find('.rara-screenshot').slideUp();
        selector.find('.rbp-upload-button').val(raratheme_companion_uploader.upload);
        
        return false;
    });

    // set var
    var in_customizer = false;

    // check for wp.customize return boolean
    if (typeof wp !== 'undefined') {
        in_customizer = typeof wp.customize !== 'undefined' ? true : false;
    }
    $(document).on('click', '.rbp-font-group li', function() {
        var id = $(this).parents('.widget').attr('id');
        $('#' + id).find('.rbp-font-group li').removeClass();
        $('#' + id).find('.icon-receiver').siblings('a').remove('.rara-remove-icon');
        $(this).addClass('selected');
        var aa = $(this).parents('.rbp-font-awesome-list').find('.rbp-font-group li.selected').children('i').attr('class');
        $(this).parents('.rbp-font-awesome-list').siblings('p').find('.hidden-icon-input').val(aa);
        $(this).parents('.rbp-font-awesome-list').siblings('p').find('.icon-receiver').html('<i class="' + aa + '"></i>');
        $('#' + id).find('.icon-receiver').append('<a class="rara-remove-icon"></a>');

        if (in_customizer) {
            $('.hidden-icon-input').trigger('change');
        }
        return $(this).focus().trigger('change');
    });

    function rara_initColorPicker(widget) {
        widget.find('.rara-widget-color-field').wpColorPicker({
         change: _.throttle(function () { // For Customizer
         jQuery(this).trigger('change');
            }, 3000)
        });
    }
    function onFormUpdate(event, widget) {
       rara_initColorPicker(widget);
    }

    jQuery(document).on('widget-added widget-updated', onFormUpdate);

    jQuery(document).ready(function () {
       jQuery('.widget:has(.rara-widget-color-field)').each(function () {
          rara_initColorPicker(jQuery(this));
       });
    });


    /** Remove icon function */
    $(document).on('click', '.rara-remove-icon', function() {
        var id = $(this).parents('.widget').attr('id');
        $('#' + id).find('.rbp-font-group li').removeClass();
        $('#' + id).find('.hidden-icon-input').val('');
        $('#' + id).find('.icon-receiver').html('<i class=""></i>').siblings('a').remove('.rara-remove-icon');
        if (in_customizer) {
            $('.hidden-icon-input').trigger('change');
        }
        return $(this).focus().trigger('change');
    });

    /** To add remove button if icon is selected in widget update event */
    $(document).on('widget-updated', function(e, widget) {
        // "widget" represents jQuery object of the affected widget's DOM element
        var $this = $('#' + widget[0].id).find('.icon-receiver');
        if ($this.find('i').hasClass('fa')) {
            $this.after('<a class="rara-remove-icon"></a>');
        }
    });

    raratheme_pro_check_icon();

    /** function to check if icon is selected and saved when loading in widget.php */
    function raratheme_pro_check_icon() {
        $('.icon-receiver').each(function() {
            var id = $(this).parents('.widget').attr('id');
            if ($('#' + id).find('.icon-receiver').find('i').hasClass('fa')) {
                $('#' + id).find('.icon-receiver').after('<a class="rara-remove-icon"></a>');
            }
        });
    }

    // script for pricing table widget
    $('body').on('click', '.rbp-items-add', function(e) {
        e.preventDefault();
        
        da = $(this).siblings('.rbp-sortable-items').attr('id');
        suffix = da.match(/\d+/);
        var len = $('.items-length:visible').length;
        len++;
        var newinput = $('.rbp-item-template').clone();
        newinput.html(function(i, oldHTML) {
            newinput.find( '.items-length' ).attr('name', 'widget-rbp_pt_widget['+suffix+'][items]['+len+']');
        });
        $(this).siblings('.rbp-sortable-items').find('.rbp-items-holder').before(newinput.html());
    });
    $('body').on('click', '.rbp-del-item', function() {
        var con = confirm(confirming.are_you_sure);
        if (!con) {
            return false;
        }
        $(this).parent().parent().fadeOut('slow', function() {
            $(this).remove();
            $('ul.rbp-sortable-items input').trigger('change');
        });
    });

    // script for skills widget
    $('body').on('click', '#add-skill:visible', function(e) {
        e.preventDefault();
        da = $(this).siblings('.widget-skills-repeater').attr('id');
        suffix = da.match(/\d+/);
        len=0;
        $( '.skills-repeat:visible' ).each(function() {
            var value =  $(this).attr( 'data-id' );
            if(!isNaN(value))
            {
                value = parseInt(value);
                len = (value > len) ? value : len;
            }
        });
        len++;
        var newinput = $('.rbp-skills-template').clone();
        newinput.html(function(i, oldHTML) {
            newinput.find( '.skills-repeat' ).attr('data-id',len);
            newinput.find( '.skill_title' ).attr('name','widget-rbp_skills_widget['+suffix+'][skill_title]['+len+']');
            newinput.find( '.skill_value' ).attr('name','widget-rbp_skills_widget['+suffix+'][skill_value]['+len+']');
        });
        $('.cl-skill-holder').before(newinput.html());
        return $(this).focus().trigger('change');
    });
});
