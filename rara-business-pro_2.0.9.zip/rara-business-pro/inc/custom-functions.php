<?php
/**
 * Rara Business Custom functions 
 * 
 * @package Rara_Business_Pro
 */

/**
 * Show/Hide Admin Bar in frontend.
 */
if( ! get_theme_mod( 'ed_adminbar', true ) ) add_filter( 'show_admin_bar', '__return_false' );

if ( ! function_exists( 'rara_business_pro_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function rara_business_pro_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Rara Business, use a find and replace
	 * to change 'rara-business-pro' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'rara-business-pro', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'rara-business-pro' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'rara_business_pro_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add excerpt support for page.
	add_post_type_support( 'page', 'excerpt' );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support( 'custom-logo', array(
		'header-text' => array( 'site-title', 'site-description' ),
	) );
    
    add_theme_support( 'custom-header', apply_filters( 'rara_business_pro_custom_header_args', array(
		'default-image'    => get_template_directory_uri().'/images/banner-image.jpg',
		'width'            => 1920,
		'height'           => 780,
		'header-text'      => false,
		'video'            => true,
	) ) );

    register_default_headers( array(
        'default-image' => array(
            'url'           => '%s/images/banner-image.jpg',
            'thumbnail_url' => '%s/images/banner-image.jpg',
            'description'   => __( 'Default Header Image', 'rara-business-pro' ),
        ),
    ) );

    /** Starter Content */
    $starter_content = array(
        // Specify the core-defined pages to create and add custom thumbnails to some of them.
        'posts' => array( 
            'home', 
            'blog',
            'portfolio' => array(
                'post_type'  => 'page',
                'post_title' => 'Portfolio',
                'template'   => 'templates/portfolio.php',
            ),
            'team' => array(
                'post_type'  => 'page',
                'post_title' => 'Team',
                'template'   => 'templates/team.php',
            ),
            'testimonial' => array(
                'post_type'  => 'page',
                'post_title' => 'Testimonial',
                'template'   => 'templates/testimonial.php',
            ),
            'faq' => array(
                'post_type'  => 'page',
                'post_title' => 'FAQ',
                'template'   => 'templates/faq.php',
            ),
            'contact' => array(
                'template' => 'templates/contact.php',
            )

        ),
        
        // Default to a static front page and assign the front and posts pages.
        'options' => array(
            'show_on_front' => 'page',
            'page_on_front' => '{{home}}',
            'page_for_posts' => '{{blog}}',
        ),
        
        // Set up nav menus for each of the two areas registered in the theme.
        'nav_menus' => array(
            // Assign a menu to the "top" location.
            'primary' => array(
                'name' => __( 'Primary', 'rara-business-pro' ),
                'items' => array(
                    'page_home',
                    'page_blog',
                    'page_portfolio' => array(
                        'type'      => 'post_type',
                        'object'    => 'page',
                        'object_id' => '{{portfolio}}',
                    ),
                    'page_team' => array(
                        'type'      => 'post_type',
                        'object'    => 'page',
                        'object_id' => '{{team}}',
                    ),
                    'page_testimonial' => array(
                        'type'      => 'post_type',
                        'object'    => 'page',
                        'object_id' => '{{testimonial}}',
                    ),
                    'page_faq' => array(
                        'type'      => 'post_type',
                        'object'    => 'page',
                        'object_id' => '{{faq}}',
                    ),
                    'page_contact',
                )
            )
        ),
    );
    
    $starter_content = apply_filters( 'rara_business_pro_starter_content', $starter_content );

    add_theme_support( 'starter-content', $starter_content );
    
    /** Images sizes */
    add_image_size( 'rara-business-slider', 1920, 780, true );
    add_image_size( 'rara-business-featured', 770, 499, true );
    add_image_size( 'rara-business-team', 370, 280, true );
    add_image_size( 'rara-business-blog', 370, 240, true );
    add_image_size( 'rara-business-portfolio', 370, 370, true );
    add_image_size( 'rara-business-gmap', 570, 420, true );
    add_image_size( 'rara-business-schema', 600, 60 );
    
    // Add theme support for Responsive Videos.
   add_theme_support( 'jetpack-responsive-videos' );
}
endif;
add_action( 'after_setup_theme', 'rara_business_pro_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function rara_business_pro_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'rara_business_pro_content_width', 770 );
}
add_action( 'after_setup_theme', 'rara_business_pro_content_width', 0 );

/**
 * Enqueue scripts and styles.
 */
function rara_business_pro_scripts() {
	// Use minified libraries if SCRIPT_DEBUG is turned off
    $build  = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '/build' : '';
    $suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

    /** Load default theme options */
    $default_options      = rara_business_pro_default_theme_options();
    $homepage_section     = get_theme_mod( 'sort_frontpage_section', $default_options['sort_frontpage_section'] );
    $enable_sticky_header = get_theme_mod( 'ed_sticky_header', $default_options['ed_sticky_header'] );
    $onepage_menu         = get_theme_mod( 'ed_one_page', $default_options['ed_one_page'] );
    $animation            = get_theme_mod( 'ed_animation', $default_options['ed_animation'] );
    $show_sticky_menu     = $enable_sticky_header ? true : false;
    
    wp_enqueue_style( 'jquery-mCustomScrollbar', get_template_directory_uri(). '/css' . $build . '/jquery.mCustomScrollbar' . $suffix . '.css', array(), '3.1.5' );
    wp_enqueue_style( 'animate', get_template_directory_uri(). '/css' . $build . '/animate' . $suffix . '.css', array(), '3.5.2' );
    wp_enqueue_style( 'rara-business-pro-google-fonts', rara_business_pro_fonts_url(), array(), null );
    wp_enqueue_style( 'owl-carousel', get_template_directory_uri(). '/css'. $build .'/owl.carousel'. $suffix .'.css', array(), '2.2.1' );
    wp_enqueue_style( 'owl-theme-default', get_template_directory_uri(). '/css'. $build .'/owl.theme.default'. $suffix .'.css', array(), '2.2.1' );

    if( rara_business_pro_is_woocommerce_activated() ){
        wp_enqueue_style( 'rara-business-pro-woocommerce', get_template_directory_uri(). '/css' . $build . '/woocommerce-style' . $suffix . '.css' );
    }

    wp_enqueue_style( 'rara-business-pro-style', get_stylesheet_uri(), array(), RARA_BUSINESS_PRO_THEME_VERSION );

    if( get_theme_mod( 'ed_lazy_load', false ) || get_theme_mod( 'ed_lazy_load_cimage', false ) ) {
        wp_enqueue_script( 'layzr', get_template_directory_uri() . '/js' . $build . '/layzr' . $suffix . '.js', array('jquery'), '2.0.4', true );
    }
    
    if( is_front_page() || is_page_template( 'templates/portfolio.php' ) ){
        wp_enqueue_script( 'masonry' );
        wp_enqueue_script( 'isotope-pkgd', get_template_directory_uri() . '/js' . $build . '/isotope.pkgd' . $suffix . '.js', array( 'jquery' ), '3.0.5', true );    
    }

    if( is_page_template( 'contact.php' ) || in_array( 'contact', $homepage_section ) ){
        $map_api_key   = get_theme_mod( 'map_api', '' );
        $latitude      = get_theme_mod( 'latitude', 27.7204766 );
        $latitude      = get_theme_mod( 'latitude', $default_options['latitude'] );
        $longitude     = get_theme_mod( 'longitude', $default_options['longitude'] );
        $map_zoom      = get_theme_mod( 'map_zoom', $default_options['map_zoom'] );
        $map_scroll    = get_theme_mod( 'ed_map_scroll', $default_options['ed_map_scroll'] );
        $map_control   = get_theme_mod( 'ed_map_controls', $default_options['ed_map_controls'] );
        $map_api_key   = ! empty( $map_api_key ) ? $map_api_key : 'AIzaSyDSpFEIkAaNbDXI5o57mvGZ_aE-Gz51sy0' ;
        $ed_map_marker = get_theme_mod( 'ed_map_marker', $default_options['ed_map_marker'] );
        $marker_title  = get_theme_mod( 'marker_title', $default_options['marker_title'] );
        $custom_css    = '#map-canvas{ width : 100%; height : 310px }';

        wp_add_inline_style( 'rara-business-pro-style', $custom_css );
        wp_enqueue_script( 'rara-business-pro-google-map', '//maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=' . $map_api_key );
        wp_enqueue_script( 'rara-business-pro-google', get_template_directory_uri() . '/js' . $build . '/google' . $suffix . '.js', array( 'jquery', 'rara-business-pro-google-map' ), RARA_BUSINESS_PRO_THEME_VERSION, true );        
        
        $array = array(
            'latitude'     => esc_attr( $latitude ),
            'longitude'    => esc_attr( $longitude ),
            'zoom'         => absint( $map_zoom ), 
            'scroll'       => (bool) $map_scroll,
            'control'      => (bool) $map_control,
            'ed_marker'    => (bool) $ed_map_marker,
            'marker_title' => esc_html( $marker_title )
        );
        wp_localize_script( 'rara-business-pro-google', 'rbp_gdata', $array );
    }
    if( $animation ){
        wp_enqueue_script( 'wow', get_template_directory_uri() . '/js' . $build . '/wow' . $suffix . '.js', array( 'jquery' ), RARA_BUSINESS_PRO_THEME_VERSION, true );
    }

    wp_enqueue_script( 'all', get_template_directory_uri() . '/js' . $build . '/all' . $suffix . '.js', array( 'jquery' ), '5.2.0', true );
    wp_enqueue_script( 'v4-shims', get_template_directory_uri() . '/js' . $build . '/v4-shims' . $suffix . '.js', array( 'jquery' ), '5.2.0', true );
    wp_enqueue_script( 'jquery-mCustomScrollbar', get_template_directory_uri() . '/js' . $build . '/jquery.mCustomScrollbar' . $suffix . '.js', array( 'jquery' ), '3.1.5', true );  
    wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/js'. $build .'/owl.carousel'. $suffix .'.js', array( 'jquery' ), '2.2.1', true );

    if( $onepage_menu ){
        wp_enqueue_script( 'scroll-nav', get_template_directory_uri() . '/js'. $build .'/scroll-nav'. $suffix .'.js', array( 'jquery' ), '3.3.0', true );
    }

    // Register custom js
    wp_register_script( 'rara-business-pro-custom', get_template_directory_uri() . '/js' . $build . '/custom' . $suffix . '.js', array( 'jquery' ), RARA_BUSINESS_PRO_THEME_VERSION, true );

    $localize_array = array(
        'rtl'          => is_rtl(),
        'sticky_menu'  => esc_attr( $show_sticky_menu ),
        'onepage_menu' => esc_attr( $onepage_menu ),
        'auto'         => get_theme_mod( 'slider_auto', $default_options['slider_auto'] ),
        'loop'         => get_theme_mod( 'slider_loop', $default_options['slider_loop'] ),
        'animation'    => get_theme_mod( 'slider_animation', $default_options['slider_animation'] ),
        'ed_animation' => get_theme_mod( 'ed_animation', $default_options['ed_animation'] ),
    );

    wp_localize_script( 'rara-business-pro-custom', 'rb_localize_data', $localize_array );

    // Enqueued custom script with localized data.
    wp_enqueue_script( 'rara-business-pro-custom' );

    $pagination = get_theme_mod( 'pagination_type', $default_options['pagination_type'] );
    $loadmore   = get_theme_mod( 'load_more_label', $default_options['load_more_label'] );
    $loading    = get_theme_mod( 'loading_label', $default_options['loading_label'] );
    $nomore     = get_theme_mod( 'nomore_post_label', $default_options['nomore_post_label'] );

    if ( $pagination == 'load_more' || $pagination == 'infinite_scroll' ) {
        global $wp_query;
        $max = $wp_query->max_num_pages;

        // Add parameters for the JS
        $paged = ( get_query_var( 'paged', '1' ) > 1 ) ? get_query_var( 'paged', '1' ) : 1;

        // Register ajax js script
        wp_register_script( 'rara-business-pro-ajax', get_template_directory_uri() . '/js'. $build .'/ajax'. $suffix .'.js', array('jquery'), RARA_BUSINESS_PRO_THEME_VERSION, true );
        
        $ajax_localized_array = array(
            'url'               => admin_url( 'admin-ajax.php' ),
            'startPage'         => $paged,
            'maxPages'          => $max,
            'nextLink'          => next_posts( $max, false ),
            'autoLoad'          => $pagination,
            'loadmore'          => $loadmore,
            'loading'           => $loading,
            'nomore'            => $nomore,
            'plugin_url'        => plugins_url(),
        );

        // Localize ajax js script
        wp_localize_script( 'rara-business-pro-ajax', 'rbp_ajax', $ajax_localized_array );

        // Enqueue ajax js script
        wp_enqueue_script( 'rara-business-pro-ajax' );
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'rara_business_pro_scripts' );

/**
 * Enqueue admin scripts.
 */
function rara_business_pro_admin_scripts( $hook_suffix ) {

    // Enqueue wp default jquery-ui-sortable js
    wp_enqueue_script( 'jquery-ui-sortable' );

    wp_enqueue_style( 'rara-business-pro-admin-style',get_template_directory_uri().'/inc/css/admin.css', RARA_BUSINESS_PRO_THEME_VERSION, 'screen' );

    // Add pricing table widget
    wp_register_script( 'rara-business-pro-custom-widget-js', get_template_directory_uri() . '/inc/js/custom-widget.js',  array( 'jquery', 'jquery-ui-sortable' ), RARA_BUSINESS_PRO_THEME_VERSION ); 

    $confirming = array( 'are_you_sure' => esc_html__( 'Are you sure?', 'rara-business-pro' ) );

    wp_localize_script( 'rara-business-pro-custom-widget-js', 'confirming', $confirming );

    wp_enqueue_script( 'rara-business-pro-custom-widget-js' );

    // Register admin js script
    wp_register_script( 'rara-business-pro-admin-js', get_template_directory_uri().'/inc/js/admin.js', array( 'jquery' ), RARA_BUSINESS_PRO_THEME_VERSION, true );

    // localize script to remove metabox in front page
    $show_front         = get_option( 'show_on_front' ); //What to show on the front page
    $front_page_id      = get_option( 'page_on_front' ); //The ID of the static front page.
    $frontpage_sections = rara_business_pro_get_home_sections();

	$admin_data    = array();
	if ( $hook_suffix == 'post.php' || $hook_suffix == 'post-new.php' ) {

        if( isset( $_GET['post'] ) && ! empty( $_GET['post'] ) ) {
            $post_id = $_GET['post'];
        } else {
            $post_id = -9999;
        }

        // Get page template
        $page_template = get_page_template_slug( $post_id );

        if( ( 'page' == $show_front && $front_page_id > 0 ) && $post_id == $front_page_id && ! empty( $frontpage_sections ) ){
            $admin_data['hide_metabox'] = 1;
        } elseif ( '' != $page_template ) {
            $admin_data['hide_metabox'] = 1;
        } else {
            $admin_data['hide_metabox'] = '';
        }
    }else {
		$admin_data['hide_metabox'] = '';
	}
	wp_localize_script( 'rara-business-pro-admin-js', 'rb_show_metabox', $admin_data );

	// Enqueued script with localized data.
	wp_enqueue_script( 'rara-business-pro-admin-js' );
}
add_action( 'admin_enqueue_scripts', 'rara_business_pro_admin_scripts' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function rara_business_pro_body_classes( $classes ) {
    $default_options     = rara_business_pro_default_theme_options(); // Get default theme options
    $banner_control      = get_theme_mod( 'ed_banner_section', $default_options['ed_banner_section'] );
    $custom_header_image = get_header_image_tag(); // get custom header image tag
    $active_child_theme  = get_theme_mod( 'child_additional_support', $default_options['child_additional_support'] ); 

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	if( is_front_page() && ! is_home() && 'no_banner' != $banner_control && ( has_header_video() ||  ! empty( $custom_header_image ) ) ){
        $classes[] = 'homepage hasbanner';
    }

    // Add sibebar layout classes.
    $classes[] = rara_business_pro_sidebar( true );

    // Add class if pattern is used as background image
    $bg_control       = get_theme_mod( 'body_bg', $default_options['body_bg'] );
    $bg_pattern       = get_theme_mod( 'bg_pattern', $default_options['bg_pattern'] );
    $background_image = get_background_image();

    if( 'pattern' == $bg_control && $bg_pattern != 'nobg' ){
        $classes[] = 'pattern-bg';
    }

    if( 'default' != $active_child_theme ){
        $classes[] = $active_child_theme;
    }

	return $classes;
}
add_filter( 'body_class', 'rara_business_pro_body_classes' );

if( ! function_exists( 'rara_business_pro_post_classes' ) ) :
    /**
     * Add custom classes to the array of post classes.
     */
    function rara_business_pro_post_classes( $classes ){
        
        $classes[] = 'latest_post';
        
        return $classes;
    }
endif;
add_filter( 'post_class', 'rara_business_pro_post_classes' );

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function rara_business_pro_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
	}
}
add_action( 'wp_head', 'rara_business_pro_pingback_header' );

if( ! function_exists( 'rara_business_pro_change_comment_form_default_fields' ) ) :
/**
 * Change Comment form default fields i.e. author, email & url.
 * https://blog.josemcastaneda.com/2016/08/08/copy-paste-hurting-theme/
*/
function rara_business_pro_change_comment_form_default_fields( $fields ){
    
    // get the current commenter if available
    $commenter = wp_get_current_commenter();
 
    // core functionality
    $req = get_option( 'require_name_email' );
    $aria_req = ( $req ? " aria-required='true'" : '' );    
 
    // Change just the author field
    $fields['author'] = '<p class="comment-form-author"><label for="author">' . esc_html__( 'Name', 'rara-business-pro' ) . '<span class="required">*</span></label><input id="author" name="author" placeholder="' . esc_attr__( 'Name*', 'rara-business-pro' ) . '" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';
    
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . esc_html__( 'Email', 'rara-business-pro' ) . '<span class="required">*</span></label><input id="email" name="email" placeholder="' . esc_attr__( 'Email*', 'rara-business-pro' ) . '" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';
    
    $fields['url'] = '<p class="comment-form-url"><label for="url">' . esc_html__( 'Website', 'rara-business-pro' ) . '</label><input id="url" name="url" placeholder="' . esc_attr__( 'Website', 'rara-business-pro' ) . '" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>'; 
    
    return $fields;
    
}
endif;
add_filter( 'comment_form_default_fields', 'rara_business_pro_change_comment_form_default_fields' );

if( ! function_exists( 'rara_business_pro_change_comment_form_defaults' ) ) :
/**
 * Change Comment Form defaults
 * https://blog.josemcastaneda.com/2016/08/08/copy-paste-hurting-theme/
*/
function rara_business_pro_change_comment_form_defaults( $defaults ){
    
    $defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Comment', 'rara-business-pro' ) . '</label><textarea id="comment" name="comment" placeholder="' . esc_attr__( 'Comment', 'rara-business-pro' ) . '" cols="45" rows="5" aria-required="true"></textarea></p>';
    
    return $defaults;
    
}
endif;
add_filter( 'comment_form_defaults', 'rara_business_pro_change_comment_form_defaults' );

if ( ! function_exists( 'rara_business_pro_excerpt_more' ) ) :
/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... * 
 */
function rara_business_pro_excerpt_more( $more ) {
	 return is_admin() ? $more : ' &hellip; ';
}
endif;
add_filter( 'excerpt_more', 'rara_business_pro_excerpt_more' );

if ( ! function_exists( 'rara_business_pro_excerpt_length' ) ) :
/**
 * Changes the default 55 character in excerpt 
*/
function rara_business_pro_excerpt_length( $length ) {
	$excerpt_length = get_theme_mod( 'excerpt_length', 55 );
    return is_admin() ? $length : absint( $excerpt_length );    
}
endif;
add_filter( 'excerpt_length', 'rara_business_pro_excerpt_length', 999 );

if ( !function_exists( 'rara_business_pro_video_controls' ) ) :
/**
 * Customize video play/pause button in the custom header.
 *
 * @param array $settings Video settings.
 */
function rara_business_pro_video_controls( $settings ) {
    $settings['l10n']['play'] = '<span class="screen-reader-text">' . __( 'Play background video', 'rara-business-pro' ) . '</span>' . rara_business_pro_get_svg( array( 'icon' => 'play' ) );
    $settings['l10n']['pause'] = '<span class="screen-reader-text">' . __( 'Pause background video', 'rara-business-pro' ) . '</span>' . rara_business_pro_get_svg( array( 'icon' => 'pause' ) );
    return $settings;
}
endif;
add_filter( 'header_video_settings', 'rara_business_pro_video_controls' );

if( ! function_exists( 'rara_business_pro_include_svg_icons' ) ) :
/**
 * Add SVG definitions to the footer.
 */
function rara_business_pro_include_svg_icons() {
    // Define SVG sprite file.
    $svg_icons = get_parent_theme_file_path( '/images/svg-icons.svg' );

    // If it exists, include it.
    if ( file_exists( $svg_icons ) ) {
        require_once( $svg_icons );
    }
}
endif;
add_action( 'wp_footer', 'rara_business_pro_include_svg_icons', 9999 );

if( ! function_exists( 'rara_business_pro_get_the_archive_title' ) ) :
/**
 * Filter Archive Title
 */
function rara_business_pro_get_the_archive_title( $title ){
    /** Load default theme options */
	$default_options =  rara_business_pro_default_theme_options();
	$hide_prefix     = get_theme_mod( 'ed_prefix_archive', $default_options['ed_prefix_archive'] );

    if( $hide_prefix ){
        if( is_category() ){
            $title = single_cat_title( '', false );
        }elseif ( is_tag() ){
            $title = single_tag_title( '', false );
        }elseif( is_author() ){
            $title = '<span class="vcard">' . get_the_author() . '</span>';
        }elseif ( is_year() ) {
            $title = get_the_date( __( 'Y', 'rara-business-pro' ) );
        }elseif ( is_month() ) {
            $title = get_the_date( __( 'F Y', 'rara-business-pro' ) );
        }elseif ( is_day() ) {
            $title = get_the_date( __( 'F j, Y', 'rara-business-pro' ) );
        }elseif ( is_post_type_archive() ) {
            $title = post_type_archive_title( '', false );
        }elseif ( is_tax() ) {
            $tax = get_taxonomy( get_queried_object()->taxonomy );
            $title = single_term_title( '', false );
        }
    }    
    return $title;
}
endif;
add_filter( 'get_the_archive_title', 'rara_business_pro_get_the_archive_title' );


if( ! function_exists( 'rara_business_pro_get_comment_author_link' ) ) :
    /**
     * Filter to modify comment author link
     * @link https://developer.wordpress.org/reference/functions/get_comment_author_link/
     */
    function rara_business_pro_get_comment_author_link( $return, $author, $comment_ID ){
        $comment = get_comment( $comment_ID );
        $url     = get_comment_author_url( $comment );
        $author  = get_comment_author( $comment );
     
        if ( empty( $url ) || 'http://' == $url ){
            $return = '<span itemprop="name">'. esc_html( $author ) .'</span>';
        }else{
            $return = '<span itemprop="name"><a href="'. esc_url( $url ) .'" rel="external nofollow" class="url" itemprop="url">'. esc_html( $author ) .'</a></span>';
        }

        return $return;
    }
endif;
add_filter( 'get_comment_author_link', 'rara_business_pro_get_comment_author_link', 10, 3 );

if( ! function_exists( 'rara_business_pro_single_post_schema' ) ) :
/**
 * Single Post Schema
 *
 * @return string
 */
function rara_business_pro_single_post_schema() {
    if ( is_singular( 'post' ) ) {
        global $post;
        $custom_logo_id = get_theme_mod( 'custom_logo' );

        $site_logo   = wp_get_attachment_image_src( $custom_logo_id , 'rara-business-schema' );
        $images      = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
        $excerpt     = rara_business_pro_escape_text_tags( $post->post_excerpt );
        $content     = $excerpt === "" ? mb_substr( rara_business_pro_escape_text_tags( $post->post_content ), 0, 110 ) : $excerpt;
        $schema_type = ! empty( $custom_logo_id ) && has_post_thumbnail( $post->ID ) ? "BlogPosting" : "Blog";

        $args = array(
            "@context"  => "http://schema.org",
            "@type"     => $schema_type,
            "mainEntityOfPage" => array(
                "@type" => "WebPage",
                "@id"   => get_permalink( $post->ID )
            ),
            "headline"  => ( function_exists( '_wp_render_title_tag' ) ? wp_get_document_title() : wp_title( '', false, 'right' ) ),
            "image"     => array(
                "@type"  => "ImageObject",
                "url"    => $images[0],
                "width"  => $images[1],
                "height" => $images[2]
            ),
            "datePublished" => get_the_time( DATE_ISO8601, $post->ID ),
            "dateModified"  => get_post_modified_time(  DATE_ISO8601, __return_false(), $post->ID ),
            "author"        => array(
                "@type"     => "Person",
                "name"      => rara_business_pro_escape_text_tags( get_the_author_meta( 'display_name', $post->post_author ) )
            ),
            "publisher" => array(
                "@type"       => "Organization",
                "name"        => get_bloginfo( 'name' ),
                "description" => get_bloginfo( 'description' ),
                "logo"        => array(
                    "@type"   => "ImageObject",
                    "url"     => $site_logo[0],
                    "width"   => $site_logo[1],
                    "height"  => $site_logo[2]
                )
            ),
            "description" => ( class_exists('WPSEO_Meta') ? WPSEO_Meta::get_value( 'metadesc' ) : $content )
        );

        if ( has_post_thumbnail( $post->ID ) ) :
            $args['image'] = array(
                "@type"  => "ImageObject",
                "url"    => $images[0],
                "width"  => $images[1],
                "height" => $images[2]
            );
        endif;

        if ( ! empty( $custom_logo_id ) ) :
            $args['publisher'] = array(
                "@type"       => "Organization",
                "name"        => get_bloginfo( 'name' ),
                "description" => get_bloginfo( 'description' ),
                "logo"        => array(
                    "@type"   => "ImageObject",
                    "url"     => $site_logo[0],
                    "width"   => $site_logo[1],
                    "height"  => $site_logo[2]
                )
            );
        endif;

        echo '<script type="application/ld+json">' , PHP_EOL;

        if ( version_compare( PHP_VERSION, '5.4.0' , '>=' ) ) {
            echo wp_json_encode( $args, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) , PHP_EOL;
        } else {
            echo wp_json_encode( $args ) , PHP_EOL;
        }
        
        echo '</script>' , PHP_EOL;
    }
}
endif;
add_action( 'wp_head', 'rara_business_pro_single_post_schema' );

if ( ! function_exists( 'rara_business_pro_migrate_theme_options' ) ) :

    /**
    * Function to migrate rara business theme option to rara business pro theme options
    */
    function rara_business_pro_migrate_theme_options(){
        
        $fresh  = get_option( '_rara_business_pro_fresh_install', false ); //flag to check if it is first switch
        
        if( ! $fresh ){
            $free_theme_options = get_option( 'theme_mods_rara-business' );

            if( ! empty( $free_theme_options ) ){
                foreach( $free_theme_options as $option => $value ){
                    if( $option !== 'sidebars_widgets' ){
                        set_theme_mod( $option, $value );
                    }    
                }
            }
            
            update_option( '_rara_business_pro_fresh_install', true );  
        }
    }
endif;
add_action( 'after_switch_theme', 'rara_business_pro_migrate_theme_options' );