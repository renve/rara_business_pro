<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Rara_Business_Pro
 */

if ( ! function_exists( 'rara_business_pro_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time.
 */
function rara_business_pro_posted_on() {
    $default_options   = rara_business_pro_default_theme_options(); // Get default theme options
    $post_updated_date = get_theme_mod( 'ed_post_update_date', $default_options['ed_post_update_date'] );
    $post_entry_meta   = get_theme_mod( 'post_meta_order', $default_options['post_meta_order'] );
    $on                = '';

    if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
        if( $post_updated_date ){
            $time_string = '<time class="entry-date published updated" datetime="%3$s" itemprop="dateModified">%4$s</time></time><time class="updated" datetime="%1$s" itemprop="datePublished">%2$s</time>';
            $on = __( 'Updated on ', 'rara-business-pro' );         
        }else{
            $time_string = '<time class="entry-date published" datetime="%1$s" itemprop="datePublished">%2$s</time><time class="updated" datetime="%3$s" itemprop="dateModified">%4$s</time>';  
        }        
    }else{
       $time_string = '<time class="entry-date published updated" datetime="%1$s" itemprop="datePublished">%2$s</time><time class="updated" datetime="%3$s" itemprop="dateModified">%4$s</time>';   
    }

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

    if ( 'date' == $post_entry_meta[0] && ( count( $post_entry_meta ) > 1 ) ) {
        $separator = '<span class="separator">/</span>'; 
    } else {
        $separator = '';
    }

    $posted_on = sprintf( '%1$s %2$s', esc_html( $on ), '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
    );

	echo '<span class="posted-on">'. $posted_on .'</span>'. $separator; // WPCS: XSS OK.

}
endif;

if( ! function_exists( 'rara_business_pro_posted_by' ) ) :
    /**
     * Prints HTML with meta information for the current author
     */
    function rara_business_pro_posted_by(){      
        $default_options = rara_business_pro_default_theme_options(); // Get default theme options
        $post_entry_meta = get_theme_mod( 'post_meta_order', $default_options['post_meta_order'] );

        $byline = '<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" itemprop="url"><span itemprop="name">' . esc_html( get_the_author() ) . '</span></a></span>';

        if ( 'author' == $post_entry_meta[0] && ( count( $post_entry_meta ) > 1 ) ) {
            $separator = '<span class="separator">/</span>'; 
        } else {
            $separator = '';
        }

        echo '<span class="byline" itemprop="author" itemscope itemtype="https://schema.org/Person"> ' . $byline . '</span>'. $separator ;
    }
endif;

if( ! function_exists( 'rara_business_pro_categories' ) ) :
/**
 * Categories
*/
function rara_business_pro_categories(){
    // Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		$categories_list = get_the_category_list( esc_html__( ' ', 'rara-business-pro' ) );
		if ( $categories_list ) {
			echo '<div class="categories">' . $categories_list . '</div>';
		}
	}
}
endif;

if( ! function_exists( 'rara_business_pro_tags' ) ) :
/**
 * Tags
*/
function rara_business_pro_tags(){
    // Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		$tags_list = get_the_tag_list( '', esc_html_x( ' ', 'list item separator', 'rara-business-pro' ) );
		if ( $tags_list ) {
			echo '<div class="tag">' . $tags_list . '</span>';
		}
	}
}
endif;

if( ! function_exists( 'rara_business_pro_theme_comment' ) ) :
/**
 * Callback function for Comment List *
 * 
 * @link https://codex.wordpress.org/Function_Reference/wp_list_comments 
 */
function rara_business_pro_theme_comment( $comment, $args, $depth ){
	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
?>
	<<?php echo $tag ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	
    <?php if ( 'div' != $args['style'] ) : ?>
    <div id="div-comment-<?php comment_ID() ?>" class="comment-body" itemscope itemtype="http://schema.org/UserComments">
	<?php endif; ?>
    	
        <footer class="comment-meta">
            <div class="comment-author vcard">
        	   <?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] ); ?>
        	</div><!-- .comment-author vcard -->
        </footer>
        
        <div class="text-holder">
        	<div class="top">
                <div class="left">
                    <?php if ( $comment->comment_approved == '0' ) : ?>
                		<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'rara-business-pro' ); ?></em>
                		<br />
                	<?php endif; ?>
                    <?php printf( __( '<b class="fn" itemprop="creator" itemscope itemtype="http://schema.org/Person">%s</b> <span class="says">says:</span>', 'rara-business-pro' ), get_comment_author_link() ); ?>
                	<div class="comment-metadata commentmetadata">
                        <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
                    		<time itemprop="commentTime" datetime="<?php echo esc_attr( get_gmt_from_date( get_comment_date() . get_comment_time(), 'Y-m-d H:i:s' ) ); ?>"><?php printf( esc_html__( '%1$s at %2$s', 'rara-business-pro' ), get_comment_date(),  get_comment_time() ); ?></time>
                        </a>
                	</div>
                </div>
                <div class="reply">
                    <?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
            	</div>
            </div>            
            <div class="comment-content" itemprop="commentText"><?php comment_text(); ?></div>        
        </div><!-- .text-holder -->
        
	<?php if ( 'div' != $args['style'] ) : ?>
    </div><!-- .comment-body -->
	<?php endif; ?>
    
<?php
}
endif;

if( ! function_exists( 'rara_business_pro_social_links' ) ) :
/**
 * Prints social links in header
*/
function rara_business_pro_social_links( $ed_social = false , $social_links = array() ){
    
    if( $ed_social && $social_links ){
        echo '<ul class="social-networks">';
    	foreach( $social_links as $link ){
            if( $link['link'] && $link['font'] ) echo '<li><a href="' . esc_url( $link['link'] ) . '"  target="_blank" rel="nofollow"><i class="' . esc_attr( $link['font'] ) . '"></i></a></li>';    	   
    	}
	   echo '</ul>';    
    }
}
endif;

if( ! function_exists( 'rara_business_pro_header_phone' ) ) :
/**
 * Phone
*/
function rara_business_pro_header_phone( $phone ){ ?>
    <div class="phone">
		<i class="fa fa-mobile-phone"></i>
		<a href="<?php echo esc_url( 'tel:' . preg_replace( '/\D/', '', $phone ) ); ?>" class="tel-link"><?php echo esc_html( $phone ); ?></a>
	</div>
    <?php
}
endif;

if( ! function_exists( 'rara_business_pro_header_address' ) ) :
/**
 * Address
*/
function rara_business_pro_header_address( $address ){ ?>
    <div class="address" itemscope itemtype="http://schema.org/PostalAddress">
		<i class="fa fa-map-marker"></i>
		<address><?php echo esc_html( $address ); ?></address>
	</div>
    <?php
}
endif;

if( ! function_exists( 'rara_business_pro_header_email' ) ) :
/**
 * Email
*/
function rara_business_pro_header_email( $email ){ ?>
    <div class="email">
		<i class="fa fa-envelope-o"></i>
		<a href="<?php echo esc_url( 'mailto:' . sanitize_email( $email ) ); ?>" class="email-link"><?php echo esc_html( $email ); ?></a>
	</div>
    <?php
}
endif;

if( ! function_exists( 'rara_business_pro_header_site_branding' ) ) :
/**
 * Site Branding
*/
function rara_business_pro_header_site_branding(){
    $display_header_text = get_theme_mod( 'header_text', 1 );
    $site_title          = get_bloginfo( 'name', 'display' );
    $description         = get_bloginfo( 'description', 'display' );

    if( ( function_exists( 'has_custom_logo' ) && has_custom_logo() ) && $display_header_text && ( ! empty( $site_title ) || ! empty(  $description  ) ) ){
       $branding_class = 'logo-with-site-identity';                                                                                                                          
    } else {
        $branding_class = '';
    }
    ?>
    <div class="site-branding <?php echo esc_attr( $branding_class ); ?>" itemscope itemtype="http://schema.org/Organization">
        <?php 
            if( function_exists( 'has_custom_logo' ) && has_custom_logo() ){
                the_custom_logo();
            } 

            echo '<div class="text-logo">';
                if( is_front_page() ){ ?>
                    <h1 class="site-title" itemprop="name"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" itemprop="url"><?php bloginfo( 'name' ); ?></a></h1>
                <?php 
                } else { ?>
                    <p class="site-title" itemprop="name"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" itemprop="url"><?php bloginfo( 'name' ); ?></a></p>
                <?php } 

                if ( $description || is_customize_preview() ){ ?>
                    <p class="site-description" itemprop="description"><?php echo esc_html( $description ); ?></p>
                <?php
                }
            echo '</div><!-- .text-logo -->';
        ?>
    </div>
    <?php
}
endif;

if( ! function_exists( 'rara_business_pro_header_primary_toggle_btn' ) ) :
/**
 * Header Primary Toggle Btn
*/
function rara_business_pro_header_primary_toggle_btn(){ ?>
   <div id="primary-toggle-button">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <?php
}
endif;

if( ! function_exists( 'rara_business_pro_primary_nagivation' ) ) :
/**
 * Primary Navigation.
 */
function rara_business_pro_primary_nagivation(){ 

    $default_options   = rara_business_pro_default_theme_options();
    $enabled_section   = array();
    $ed_one_page       = get_theme_mod( 'ed_one_page' );
    $ed_home_link      = get_theme_mod( 'ed_home_link', true );
    $home_sections     = get_theme_mod( 'sort_frontpage_section', $default_options['sort_frontpage_section'] );
    
    $label_service     = get_theme_mod( 'label_service', $default_options['label_service'] ); 
    $label_about       = get_theme_mod( 'label_about', $default_options['label_about'] );   
    $label_choose_us   = get_theme_mod( 'label_choose_us', $default_options['label_choose_us'] );   
    $label_team        = get_theme_mod( 'label_team', $default_options['label_team'] );
    $label_testimonial = get_theme_mod( 'label_testimonial', $default_options['label_testimonial'] );
    $label_stats       = get_theme_mod( 'label_stats', $default_options['label_stats'] );
    $label_skill       = get_theme_mod( 'label_skill', $default_options['label_skill'] );
    $label_portfolio   = get_theme_mod( 'label_portfolio', $default_options['label_portfolio'] );
    $label_pricing     = get_theme_mod( 'label_pricing', $default_options['label_pricing'] );
    $label_blog        = get_theme_mod( 'label_blog', $default_options['label_blog'] );
    $label_cta         = get_theme_mod( 'label_cta', $default_options['label_cta'] );
    $label_faq         = get_theme_mod( 'label_faq', $default_options['label_faq'] );
    $label_contact     = get_theme_mod( 'label_contact', $default_options['label_contact'] );
    $label_client      = get_theme_mod( 'label_client', $default_options['label_client'] );
    
    $test = array( 'services','about','choose-us','team','testimonial','stats','skill','portfolio','pricing','blog','cta','faq','contact','client');

    $menu_label = array();
    if( ! empty( $label_service ) ) $menu_label['services'] = $label_service;      
    if( ! empty( $label_about ) ) $menu_label['about'] = $label_about;          
    if( ! empty( $label_choose_us ) ) $menu_label['choose-us'] = $label_choose_us;      
    if( ! empty( $label_team ) ) $menu_label['team'] = $label_team;        
    if( ! empty( $label_testimonial ) ) $menu_label['testimonial'] = $label_testimonial; 
    if( ! empty( $label_stats ) ) $menu_label['stats'] = $label_stats;       
    if( ! empty( $label_skill ) ) $menu_label['skill'] = $label_skill;       
    if( ! empty( $label_portfolio ) ) $menu_label['portfolio'] = $label_portfolio;   
    if( ! empty( $label_pricing ) ) $menu_label['pricing'] = $label_pricing;     
    if( ! empty( $label_blog ) ) $menu_label['blog'] = $label_blog;        
    if( ! empty( $label_cta ) ) $menu_label['cta'] = $label_cta;         
    if( ! empty( $label_faq ) ) $menu_label['faq'] = $label_faq;         
    if( ! empty( $label_contact ) ) $menu_label['contact'] = $label_contact;     
    if( ! empty( $label_client ) ) $menu_label['client'] = $label_client;      

    
    foreach( $home_sections as $section ){
        if( array_key_exists( $section, $menu_label ) ){
            $enabled_section[] = array(
                'id'    => $section . '-section',
                'label' => $menu_label[$section],
            );
        }
    }
    
    if( $ed_one_page && ( 'page' == get_option( 'show_on_front' ) ) && $enabled_section ){ ?>
        <ul>
            <?php if( $ed_home_link ){ ?>
            <li class="<?php if( is_front_page() ) echo esc_attr( 'current-menu-item' ); ?>"><a href="<?php echo esc_url( home_url( '#banner-section' ) ); ?>"><?php esc_html_e( 'Home', 'rara-business-pro' ); ?></a></li>
        <?php }
            foreach( $enabled_section as $section ){ 
                if( $section['label'] ){
        ?>
                <li><a href="<?php echo esc_url( home_url( '#' . esc_attr( $section['id'] ) ) ); ?>"><?php echo esc_html( $section['label'] );?></a></li>                        
        <?php 
                } 
            }
        ?>
        </ul>
    <?php } else { 
        
        wp_nav_menu( array(
            'theme_location' => 'primary',
            'menu_id'        => 'primary-menu',
            'fallback_cb'    => 'rara_business_pro_primary_menu_fallback',
        ) );
    }
}
endif;

if( ! function_exists( 'rara_business_pro_primary_menu_fallback' ) ) :
/**
 * Primary Menu Fallback
*/
function rara_business_pro_primary_menu_fallback(){
    if( current_user_can( 'manage_options' ) ){
        echo '<ul id="primary-menu" class="menu">';
        echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Click here to add a menu', 'rara-business-pro' ) . '</a></li>';
        echo '</ul>';
    }
}
endif;

if( ! function_exists( 'rara_business_pro_get_home_sections' ) ) :
/**
 * Returns Home Sections 
*/
function rara_business_pro_get_home_sections(){

    $default_options    = rara_business_pro_default_theme_options(); // Get default theme options
    $frontpage_sections = get_theme_mod( 'sort_frontpage_section', $default_options['sort_frontpage_section'] );
    $sections           = ! empty( $frontpage_sections ) ? $frontpage_sections : array();
    
    $enabled_section = array();
    foreach( $sections as $section ){
        if( is_active_sidebar( $section ) || in_array( $section, $default_options['sort_frontpage_section'] ) ){
            array_push( $enabled_section, $section );
        } 
    }
    
    $enabled_section = array_diff( array_unique( $enabled_section ), array( '' ) );       
    return $enabled_section;
}
endif;

if( ! function_exists( 'rara_business_pro_get_portfolio_buttons' ) ) :
/**
 * Query for Portfolio Buttons
*/
function rara_business_pro_get_portfolio_buttons( $no_of_portfolio, $home = false ){
    if( taxonomy_exists( 'rara_portfolio_categories' ) ){
        if( $home ){
            $s = '';
            $i = 0;
            $portfolio_posts = get_posts( array( 'post_type' => 'rara-portfolio', 'post_status' => 'publish', 'posts_per_page' => $no_of_portfolio ) );
            foreach( $portfolio_posts as $portfolio ){
                $terms = get_the_terms( $portfolio->ID, 'rara_portfolio_categories' );
                if( $terms ){
                    foreach( $terms as $term ){
                        $i++;
                        $s .= $term->term_id;
                        $s .= ', ';    
                    }
                }
            }
            $term_ids = explode( ', ', $s );
            $term_ids = array_diff( array_unique( $term_ids ), array('') );
            wp_reset_postdata();//Reseting get_posts       
        }
        
        $args = array(
            'taxonomy'      => 'rara_portfolio_categories',
            'orderby'       => 'name', 
            'order'         => 'ASC',
        );                
        $terms = get_terms( $args );
        if( $terms ){
        ?>
        <div class="button-group filter-button-group">        
            <button data-filter="*" class="button is-checked"><?php echo esc_html_e( 'All', 'rara-business-pro' ); ?></button><!-- This is HACK for reducing space between inline block elements.
            --><?php
                foreach( $terms as $t ){
                    if( $home ){
                        if( in_array( $t->term_id, $term_ids ) )
                        echo '<button class="button" data-filter=".' . esc_attr( $t->slug ) .  '">' . esc_html( $t->name ) . '</button>';
                    }else{
                        echo '<button class="button" data-filter=".' . esc_attr( $t->slug ) .  '">' . esc_html( $t->name ) . '</button>';    
                    }                    
                } 
            ?>
        </div>            
        <?php
        }
    }
}
endif;

if( ! function_exists( 'rara_business_pro_get_portfolios' ) ) :
/**
 * Query for portfolios 
*/
function rara_business_pro_get_portfolios( $no_of_portfolio = -1 ){
    $portfolio_qry = new WP_Query( array( 'post_type' => 'rara-portfolio', 'post_status' => 'publish', 'posts_per_page' => $no_of_portfolio ) );
    if( taxonomy_exists( 'rara_portfolio_categories' ) && $portfolio_qry->have_posts() ){ ?>
                        
        <div class="filter-grid">
    		<?php
            while( $portfolio_qry->have_posts() ){
                $portfolio_qry->the_post();
                $terms = get_the_terms( get_the_ID(), 'rara_portfolio_categories' );
                $s = '';
                $n = '';
                $i = 0;
                if( $terms ){
                    foreach( $terms as $t ){
                        $i++;
                        $s .= $t->slug;
                        $n .= '#'.$t->name;
                        if( count( $terms ) > $i ){
                            $s .= ' ';
                            $n .= ' ';
                        }
                    }
                }                    
                ?>
                <div class="element-item <?php echo esc_attr( $s );?>">
    				<div class="img-holder">
    					<a href="<?php the_permalink(); ?>">
                            <?php 
                                if( has_post_thumbnail() ){
                                    the_post_thumbnail( 'rara-business-portfolio' );
                                }else{
                                    echo '<img src="'. esc_url( get_template_directory_uri().'/images/rara-business-portfolio.jpg' ) .'" alt="'. esc_attr( get_the_title() ).'">';
                                }
                            ?>                        
                        </a>
    					<div class="text-holder">
    						<div class="text">
    							<?php 
                                    the_title( '<h3 class="title">', '</h3>' );
                                    if( $n ) echo '<p>'. esc_html( $n ) .'</p>'; 
                                ?>                                
    						</div>
    					</div>                        
    				</div>    				
    			</div>
    		    <?php
            }
            ?>
    	</div><!-- .filter-grid -->
        <?php
        wp_reset_postdata(); 
    } 
}
endif;

/**
 * Query WooCommerce activation
 */
function rara_business_pro_is_woocommerce_activated() {
	return class_exists( 'woocommerce' ) ? true : false;
}

/**
 * Query Rara theme companion activation
 */
function rara_business_pro_is_rara_theme_companion_activated() {
    return class_exists( 'Raratheme_Companion_Public' ) ? true : false;
}

/**
 * Query Contact Form 7
 */
function rara_business_pro_is_cf7_activated() {
    return class_exists( 'WPCF7' ) ? true : false;
}


if( ! function_exists( 'rara_business_pro_get_svg' ) ) :
    /**
     * Return SVG markup.
     *
     * @param array $args {
     *     Parameters needed to display an SVG.
     *
     *     @type string $icon  Required SVG icon filename.
     *     @type string $title Optional SVG title.
     *     @type string $desc  Optional SVG description.
     * }
     * @return string SVG markup.
     */
    function rara_business_pro_get_svg( $args = array() ) {
        // Make sure $args are an array.
        if ( empty( $args ) ) {
            return __( 'Please define default parameters in the form of an array.', 'rara-business-pro' );
        }

        // Define an icon.
        if ( false === array_key_exists( 'icon', $args ) ) {
            return __( 'Please define an SVG icon filename.', 'rara-business-pro' );
        }

        // Set defaults.
        $defaults = array(
            'icon'        => '',
            'title'       => '',
            'desc'        => '',
            'fallback'    => false,
        );

        // Parse args.
        $args = wp_parse_args( $args, $defaults );

        // Set aria hidden.
        $aria_hidden = ' aria-hidden="true"';

        // Set ARIA.
        $aria_labelledby = '';

        /*
         * Restaurant and Cafe Pro doesn't use the SVG title or description attributes; non-decorative icons are described with .screen-reader-text.
         *
         * However, child themes can use the title and description to add information to non-decorative SVG icons to improve accessibility.
         *
         * Example 1 with title: <?php echo rara_business_pro_get_svg( array( 'icon' => 'arrow-right', 'title' => __( 'This is the title', 'textdomain' ) ) ); ?>
         *
         * Example 2 with title and description: <?php echo rara_business_pro_get_svg( array( 'icon' => 'arrow-right', 'title' => __( 'This is the title', 'textdomain' ), 'desc' => __( 'This is the description', 'textdomain' ) ) ); ?>
         *
         * See https://www.paciellogroup.com/blog/2013/12/using-aria-enhance-svg-accessibility/.
         */
        if ( $args['title'] ) {
            $aria_hidden     = '';
            $unique_id       = uniqid();
            $aria_labelledby = ' aria-labelledby="title-' . $unique_id . '"';

            if ( $args['desc'] ) {
                $aria_labelledby = ' aria-labelledby="title-' . $unique_id . ' desc-' . $unique_id . '"';
            }
        }

        // Begin SVG markup.
        $svg = '<svg class="icon icon-' . esc_attr( $args['icon'] ) . '"' . $aria_hidden . $aria_labelledby . ' role="img">';

        // Display the title.
        if ( $args['title'] ) {
            $svg .= '<title id="title-' . $unique_id . '">' . esc_html( $args['title'] ) . '</title>';

            // Display the desc only if the title is already set.
            if ( $args['desc'] ) {
                $svg .= '<desc id="desc-' . $unique_id . '">' . esc_html( $args['desc'] ) . '</desc>';
            }
        }

        /*
         * Display the icon.
         *
         * The whitespace around `<use>` is intentional - it is a work around to a keyboard navigation bug in Safari 10.
         *
         * See https://core.trac.wordpress.org/ticket/38387.
         */
        $svg .= ' <use href="#icon-' . esc_html( $args['icon'] ) . '" xlink:href="#icon-' . esc_html( $args['icon'] ) . '"></use> ';

        // Add some markup to use as a fallback for browsers that do not support SVGs.
        if ( $args['fallback'] ) {
            $svg .= '<span class="svg-fallback icon-' . esc_attr( $args['icon'] ) . '"></span>';
        }

        $svg .= '</svg>';

        return $svg;
    }
endif;

if( ! function_exists( 'rara_business_pro_escape_text_tags' ) ) :
/**
 * Remove new line tags from string
 *
 * @param $text
 *
 * @return string
 */
function rara_business_pro_escape_text_tags( $text ) {
    return (string) str_replace( array( "\r", "\n" ), '', strip_tags( $text ) );
}
endif;

if( ! function_exists( 'rara_business_pro_get_template_page_url' ) ) :
    /**
     * Fuction to return page url
    */
    function rara_business_pro_get_template_page_url( $template_key = '', $post_type = 'page' ){

        if( ! empty( $template_key ) ){
            $args = array(
                'meta_key'      => '_wp_page_template',
                'meta_value'    => $template_key,
                'post_type'     => $post_type,
            );

            $posts_array = get_posts( $args );

            if ( ! empty( $posts_array ) ) {
                foreach ( $posts_array as $posts ) {
                    $post_options[ $posts->ID ] = $posts->ID;    
                    $page_template_url = get_permalink( $post_options[ $posts->ID ] );
                    return $page_template_url;
                }
            }
        } else {
            return false;
        }
    }
endif;

if ( ! function_exists( 'rara_business_pro_get_dynamnic_sidebar' ) ) :
    /**
     * Function to list dynamic sidebar
     */
    function rara_business_pro_get_dynamnic_sidebar( $nosidebar = false, $primary_sidebar = false, $default = false ){
        /** Load default theme options */
        $default_options =  rara_business_pro_default_theme_options();

        $dynamic_sidebars = get_theme_mod( 'dynamic_sidebar', $default_options['dynamic_sidebar'] );
        $sidebar_arr   = array();
        
        if( $default ) $sidebar_arr['default-sidebar'] = esc_html__( 'Default Sidebar', 'rara-business-pro' );
        if( $primary_sidebar ) $sidebar_arr['primary-sidebar'] = esc_html__( 'Primary Sidebar', 'rara-business-pro' );
        
        if( ! empty( $dynamic_sidebars ) ){        
            foreach( $dynamic_sidebars as $sidebar ){            
                $id = $sidebar['name'] ? sanitize_title( $sidebar['name'] ) : 'rara-sidebar-one';
                $sidebar_arr[$id] = $sidebar['name'];
            }
        }
        
        if( $nosidebar ) $sidebar_arr['no-sidebar'] = esc_html__( 'No Sidebar', 'rara-business-pro' );
        
        return $sidebar_arr;
    }
endif;

if ( ! function_exists( 'rara_business_pro_sidebar' ) ) :
    /**
     * Return sidebar for different archive and single pages
     */
    function rara_business_pro_sidebar( $class = false ){
        global $post;
        $return = false;

        /** Load default theme options */
        $default_options = rara_business_pro_default_theme_options();
        $show_on_front   = get_option( 'show_on_front' );
        $blogpage_id     = get_option( 'page_for_posts' );
        $frontpage_id    = get_option( 'page_on_front' );
        
        // Default blogpage sidebar
        $blog_sidebar = get_theme_mod( 'home_page_sidebar', $default_options['home_page_sidebar'] );
        $blog_layout  = get_theme_mod( 'blog_sidebar_layout', $default_options['blog_sidebar_layout'] );
        // Default sidebar layout 
        $layout = get_theme_mod( 'default_sidebar_layout', $default_options['default_sidebar_layout'] );

        if ( is_home() ){
            if( 'page' == $show_on_front && $blogpage_id > 0 ){
                $single_sidebar = get_post_meta( $blogpage_id, 'selected_sidebar', true );
                $single_sidebar = ! empty( $single_sidebar ) ? $single_sidebar : 'default-sidebar';

                $sidebar_layout = get_post_meta( $blogpage_id, 'sidebar_layout', true );
                $sidebar_layout = ! empty( $sidebar_layout ) ? $sidebar_layout : 'default-sidebar';

                if( ( $single_sidebar == 'no-sidebar' ) || ( ( $single_sidebar == 'default-sidebar' ) && ( $blog_sidebar == 'no-sidebar' ) ) ){
                    $return = $class ? 'full-width' : false;
                }elseif( $single_sidebar == 'default-sidebar' && $blog_sidebar != 'no-sidebar' && is_active_sidebar( $blog_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $blog_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){
                        $return = $class ? 'rightsidebar' : $blog_sidebar;
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $blog_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){
                        $return = $class ? 'leftsidebar' : $blog_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $single_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $blog_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){
                        $return = $class ? 'rightsidebar' : $single_sidebar;
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $blog_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){
                        $return = $class ? 'leftsidebar' : $single_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }else{
                    $return = $class ? 'full-width' : false;
                }

            }elseif( is_active_sidebar( $blog_sidebar ) ){            
                if( $blog_layout == 'right-sidebar' ){
                    $return = $class ? 'rightsidebar' : $blog_sidebar;
                }elseif( $blog_layout == 'left-sidebar' ){
                    $return = $class ? 'leftsidebar' : $blog_sidebar;
                }else{
                    $return = $class ? 'full-width' : false;
                }
            }else{
                $return = $class ? 'full-width' : false;
            }        
        }
    
        if ( is_archive() ) {
            //archive page
            $archive_sidebar = get_theme_mod( 'archive_page_sidebar', $default_options['archive_page_sidebar'] );
            $cat_sidebar     = get_theme_mod( 'cat_archive_page_sidebar', $default_options['cat_archive_page_sidebar'] );
            $tag_sidebar     = get_theme_mod( 'tag_archive_page_sidebar', $default_options['tag_archive_page_sidebar'] );
            $date_sidebar    = get_theme_mod( 'date_archive_page_sidebar', $default_options['date_archive_page_sidebar'] );
            $author_sidebar  = get_theme_mod( 'author_archive_page_sidebar', $default_options['author_archive_page_sidebar'] );

            if ( is_category() ){
                
                if ( $cat_sidebar == 'no-sidebar' || ( $cat_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ) {
                    $return = $class ? 'full-width' : false;
                } elseif ( $cat_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) {
                    if( $layout == 'right-sidebar' ) {
                        $return = $class ? 'rightsidebar' : $archive_sidebar;
                    }elseif( $layout == 'left-sidebar' ) {
                        $return = $class ? 'leftsidebar' : $archive_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } elseif ( is_active_sidebar( $cat_sidebar ) ){
                    if( $layout == 'right-sidebar' ) {
                        $return = $class ? 'rightsidebar' : $cat_sidebar;
                    }elseif( $layout == 'left-sidebar' ) {
                        $return = $class ? 'leftsidebar' : $cat_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } else {
                    $return = $class ? 'full-width' : false;
                }
                    
            } elseif ( is_tag() ) {
                
                if( $tag_sidebar == 'no-sidebar' || ( $tag_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                   $return = $class ? 'full-width' : false;
                }elseif( ( $tag_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $archive_sidebar;
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $archive_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $tag_sidebar ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $tag_sidebar;
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $tag_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    }     
                }else{
                    $return = $class ? 'full-width' : false;
                }
                
            } elseif ( is_author() ) {
                
                if( $author_sidebar == 'no-sidebar' || ( $author_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                    $return = $class ? 'full-width' : false;
                }elseif( ( $author_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                    if( $layout == 'right-sidebar' ){ 
                        $return = $class ? 'rightsidebar' : $archive_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){ 
                        $return = $class ? 'leftsidebar' : $archive_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $author_sidebar ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $author_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $author_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }else{
                    $return = $class ? 'full-width' : false;
                }
               
                
            } elseif ( is_date() ) {
                
               if( $date_sidebar == 'no-sidebar' || ( $date_sidebar == 'default-sidebar' && $archive_sidebar == 'no-sidebar' ) ){
                    $return = $class ? 'full-width' : false;
                }elseif( ( $date_sidebar == 'default-sidebar' && $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $archive_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $archive_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $date_sidebar ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $date_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $date_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }else{
                    $return = $class ? 'full-width' : false;
                }                                                  
                
            } elseif ( rara_business_pro_is_woocommerce_activated() && is_archive( 'product' ) ) {
                if ( $archive_sidebar != 'no-sidebar' && is_active_sidebar( 'shop-sidebar' ) ) {
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : 'shop-sidebar'; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : 'shop-sidebar'; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } elseif( is_active_sidebar( $archive_sidebar ) ) {
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $archive_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $archive_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } else {
                   $return = $class ? 'full-width' : false;
                }                      
            } else {
                if ( $archive_sidebar != 'no-sidebar' && is_active_sidebar( $archive_sidebar ) ) {
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $archive_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $archive_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } else {
                   $return = $class ? 'full-width' : false;
                }                      
            }
            
        }

        if ( is_search() ) {
            $search_sidebar = ! empty( get_theme_mod( 'search_page_sidebar' ) ) ? get_theme_mod( 'search_page_sidebar' ) : 'primary-sidebar';
            if( $search_sidebar != 'no-sidebar' && is_active_sidebar( $search_sidebar ) ){
                if( $layout == 'right-sidebar' ){
                    $return = $class ? 'rightsidebar' : $search_sidebar; 
                }elseif( $layout == 'left-sidebar' ){
                    $return = $class ? 'leftsidebar' : $search_sidebar; 
                }else{
                    $return = $class ? 'full-width' : false;
                }
            }else{
                $return = $class ? 'full-width' : false;
            }
        }
        
        if ( is_singular() ) {
            $post_sidebar = get_theme_mod( 'single_post_sidebar', $default_options['single_post_sidebar'] );
            $page_sidebar = get_theme_mod( 'single_page_sidebar', $default_options['single_page_sidebar'] );
            $page_layout  = get_theme_mod( 'page_sidebar_layout', $default_options['page_sidebar_layout'] );
            $post_layout  = get_theme_mod( 'post_sidebar_layout', $default_options['post_sidebar_layout'] );
            
            // Single post/page selected sidebar
            $single_sidebar = get_post_meta( $post->ID, 'selected_sidebar', true );
            $single_sidebar = ! empty( $single_sidebar ) ? $single_sidebar : 'default-sidebar';

            // Single post/page sidebar layout
            $sidebar_layout = get_post_meta( $post->ID, 'sidebar_layout', true );
            $sidebar_layout = ! empty( $sidebar_layout ) ? $sidebar_layout : 'default-sidebar';

            if( is_singular( 'rara-portfolio' ) ){
                 $return = $class ? 'full-width' : false;
            }elseif ( rara_business_pro_is_woocommerce_activated() && is_singular( 'product' ) ) {
                if( is_active_sidebar( 'shop-sidebar' ) ){
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : 'shop-sidebar'; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : 'shop-sidebar'; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                } else {
                    if( $layout == 'right-sidebar' ){
                        $return = $class ? 'rightsidebar' : $post_sidebar; 
                    }elseif( $layout == 'left-sidebar' ){
                        $return = $class ? 'leftsidebar' : $post_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }
            } elseif ( is_page() ){

                if( is_page_template( array( 'templates/contact.php', 'templates/faq.php', 'templates/portfolio.php', 'templates/team.php', 'templates/testimonial.php' ) ) ){
                        $return = $class ? '' : false;
                }elseif( ( $single_sidebar == 'no-sidebar' ) || ( ( $single_sidebar == 'default-sidebar' ) && ( $page_sidebar == 'no-sidebar' ) ) ){
                     $return = $class ? 'full-width' : false;
                }elseif( $single_sidebar == 'default-sidebar' && $page_sidebar != 'no-sidebar' && is_active_sidebar( $page_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $page_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){ 
                        $return = $class ? 'rightsidebar' : $page_sidebar; 
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $page_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){ 
                        $return = $class ? 'leftsidebar' : $page_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $single_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $page_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){
                        $return = $class ? 'rightsidebar' : $single_sidebar; 
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $page_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){
                        $return = $class ? 'leftsidebar' : $single_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }else{
                    $return = $class ? 'full-width' : false;
                }
                
            }elseif( is_single() ){
                if( ( $single_sidebar == 'no-sidebar' ) || ( ( $single_sidebar == 'default-sidebar' ) && ( $post_sidebar == 'no-sidebar' ) ) ){
                    $return = $class ? 'full-width' : false;
                }elseif( $single_sidebar == 'default-sidebar' && $post_sidebar != 'no-sidebar' && is_active_sidebar( $post_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $post_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){
                        $return = $class ? 'rightsidebar' : $post_sidebar; 
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $post_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){
                        $return = $class ? 'leftsidebar' : $post_sidebar; 
                    }else{
                        $return = $class ? 'full-width' : false;
                    }
                }elseif( is_active_sidebar( $single_sidebar ) ){
                    if( ( $sidebar_layout == 'default-sidebar' && $post_layout == 'right-sidebar' ) || ( $sidebar_layout == 'right-sidebar' ) ){
                        $return = $class ? 'rightsidebar' : $single_sidebar; 
                    }elseif( ( $sidebar_layout == 'default-sidebar' && $post_layout == 'left-sidebar' ) || ( $sidebar_layout == 'left-sidebar' ) ){
                        $return = $class ? 'leftsidebar' : $single_sidebar;
                    }else{
                        $return = $class ? 'full-width' : false;
                    } 
                }else{
                    $return = $class ? 'full-width' : false;
                }
            }
        }
    
        return $return; 
    }
endif;

if( ! function_exists( 'rara_business_pro_get_all_fonts' ) ) :
    /**
     * Return Web safe font and google font
     */
    function rara_business_pro_get_all_fonts(){
        $google = array();        
        $standard = array(
            'georgia-serif'       => __( 'Georgia', 'rara-business-pro' ),
            'palatino-serif'      => __( 'Palatino Linotype, Book Antiqua, Palatino', 'rara-business-pro' ),
            'times-serif'         => __( 'Times New Roman, Times', 'rara-business-pro' ),
            'arial-helvetica'     => __( 'Arial, Helvetica', 'rara-business-pro' ),
            'arial-gadget'        => __( 'Arial Black, Gadget', 'rara-business-pro' ),
            'comic-cursive'       => __( 'Comic Sans MS, cursive', 'rara-business-pro' ),
            'impact-charcoal'     => __( 'Impact, Charcoal', 'rara-business-pro' ),
            'lucida'              => __( 'Lucida Sans Unicode, Lucida Grande', 'rara-business-pro' ),
            'tahoma-geneva'       => __( 'Tahoma, Geneva', 'rara-business-pro' ),
            'trebuchet-helvetica' => __( 'Trebuchet MS, Helvetica', 'rara-business-pro' ),
            'verdana-geneva'      => __( 'Verdana, Geneva', 'rara-business-pro' ),
            'courier'             => __( 'Courier New, Courier', 'rara-business-pro' ),
            'lucida-monaco'       => __( 'Lucida Console, Monaco', 'rara-business-pro' ),
        );
        
        $fonts = include wp_normalize_path( get_template_directory() . '/inc/custom-controls/typography/webfonts.php' );
        
        foreach( $fonts['items'] as $font ){
            $google[$font['family']] = $font['family'];
        }
        $all_fonts = array_merge( $standard, $google );
        return $all_fonts; 
    }
endif;

if ( ! function_exists( 'rara_business_pro_get_patterns' ) ) :
    /**
     * Function to list Custom Pattern
     */
    function rara_business_pro_get_patterns(){
        $patterns = array();
        $patterns['nobg'] = get_template_directory_uri() . '/images/patterns_thumb/' . 'nobg.png';
        for( $i=0; $i<38; $i++ ){
            $patterns['pattern'.$i] = get_template_directory_uri() . '/images/patterns_thumb/' . 'pattern' . $i .'.png';
        }
        for( $j=1; $j<26; $j++ ){
            $patterns['hbg'.$j] = get_template_directory_uri() . '/images/patterns_thumb/' . 'hbg' . $j . '.png';
        }
        return $patterns;
    }
endif;


/**
 * convert hex to rgb
 * @link http://bavotasan.com/2011/convert-hex-color-to-rgb-using-php/
 */
function rara_business_pro_hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   //return implode(",", $rgb); // returns the rgb values separated by commas
   return $rgb; // returns an array with the rgb values
}

if( ! function_exists( 'rara_business_pro_get_posts' ) ) :
    /**
     * Fuction to list Post Type
     */
    function rara_business_pro_get_posts( $post_type = 'post', $slug = false ){
        
        $args = array(
            'posts_per_page'   => -1,
            'post_type'        => $post_type,
            'post_status'      => 'publish',
            'suppress_filters' => true 
        );
        $posts_array = get_posts( $args );
        
        // Initate an empty array
        $post_options = array();
        $post_options[''] = __( ' -- Choose -- ', 'rara-business-pro' );
        
        if ( ! empty( $posts_array ) ) {
            foreach ( $posts_array as $posts ) {
                if( $slug ){
                    $post_options[ $posts->post_title ] = $posts->post_title;
                }else{
                    $post_options[ $posts->ID ] = $posts->post_title;    
                }
            }
        }
        return $post_options;
        wp_reset_postdata();
    }
endif;

if( ! function_exists( 'rara_business_pro_social_share' ) ) :
    /**
     * Social Sharing
     */
    function rara_business_pro_social_share( $sticky = false ){
        $default_options = rara_business_pro_default_theme_options();

        $ed_share = get_theme_mod( 'ed_social_sharing', $default_options['ed_social_sharing'] );
        $shares   = get_theme_mod( 'social_share', $default_options['social_share'] );
        $class    = $sticky ? 'sticky' : '';
        
        if ( $ed_share && $shares ) { ?>
            <div class="social-share <?php echo esc_attr( $class ); ?>">
                <?php 
                    if( ! $sticky ) echo '<strong>'. __( 'Share this article', 'rara-business-pro' ) .'</strong>'; 
                ?>
                <ul class="social-icons">
                    <?php
                        foreach( $shares as $share ){
                            rara_business_pro_get_social_share( $share );                    
                        }
                    ?>
                </ul>
            </div>
        <?php
        }
    }
endif;

if( ! function_exists( 'rara_business_pro_get_social_share' ) ) :
    /**
     * Get list of social sharing icons
     * http://www.sharelinkgenerator.com/
     * 
     */
    function rara_business_pro_get_social_share( $share ){
        global $post;
        
                switch( $share ){
            case 'facebook':
            echo '<li><a href="' . esc_url( 'https://www.facebook.com/sharer/sharer.php?u=' . get_the_permalink( $post->ID ) ) . '" class="facebook" rel="nofollow" target="_blank">'. __( 'facebook', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'twitter':
            echo '<li><a href="' . esc_url( 'https://twitter.com/home?status=' . get_the_title( $post->ID ) ) . '&nbsp;' . get_the_permalink( $post->ID ) . '" class="twitter" rel="nofollow" target="_blank">'. __( 'twitter', 'rara-business-pro' ).'</a></li>';
            
            break;
            
            case 'linkedin':
            echo '<li><a href="' . esc_url( 'https://www.linkedin.com/shareArticle?mini=true&url=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID ) ) . '" class="linkedin" rel="nofollow" target="_blank">'. __( 'linkedin', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'pinterest':
            echo '<li><a href="' . esc_url( 'https://pinterest.com/pin/create/button/?url=' . get_the_permalink( $post->ID ) . '&description=' . get_the_title( $post->ID )  ) . '" class="pinterest" rel="nofollow" target="_blank">'. __( 'pinterest', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'email':
            echo '<li><a href="' . esc_url( 'mailto:?Subject=' . get_the_title( $post->ID ) . '&Body=' . get_the_permalink( $post->ID ) ) . '" class="email" rel="nofollow" target="_blank">'. __( 'email', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'gplus':
            echo '<li><a href="' . esc_url( 'https://plus.google.com/share?url=' . get_the_permalink( $post->ID ) ) . '" class="gplus" rel="nofollow" target="_blank">'. __( 'gplus', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'stumble':
            echo '<li><a href="' . esc_url( 'http://www.stumbleupon.com/submit?url=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID ) ) . '" class="stumble" rel="nofollow" target="_blank">'. __( 'stumble', 'rara-business-pro' ) .'</a></li>';
            
            break;
            
            case 'reddit':
            echo '<li><a href="' . esc_url( 'http://www.reddit.com/submit?url=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID ) ) . '" class="reddit" rel="nofollow" target="_blank">'. __( 'reddit', 'rara-business-pro' ) .'</a></li>';
            
            break; 

            case 'tumblr':
            echo '<li> <a href=" ' . esc_url ( 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID) ). ' " class="tumblr" rel="nofollow" target="_blank">'. __( 'tumblr', 'rara-business-pro' ) .'</a></li>';      
            
            break; 

            case 'digg':
            echo '<li> <a href=" ' . esc_url ( 'http://digg.com/submit?url=' . get_the_permalink( $post->ID ) ). ' " class="digg" rel="nofollow" target="_blank">'. __( 'digg', 'rara-business-pro' ) .'</a></li>';      
            
            break;

            case 'weibo':
            echo '<li> <a href=" ' . esc_url ( 'https://service.weibo.com/share/share.php?url=' . get_the_permalink( $post->ID ) ). ' " class="weibo" rel="nofollow" target="_blank">'. __( 'weibo', 'rara-business-pro' ) .'</a></li>';      
            
            break;

            case 'xing':
            echo '<li> <a href=" ' . esc_url ( 'https://www.xing.com/app/user?op=share&url=' . get_the_permalink( $post->ID ) ). ' " class="xing" rel="nofollow" target="_blank">'. __( 'xing', 'rara-business-pro' ) .'</a></li>';      
            
            break;

            case 'vk':
            echo '<li> <a href=" ' . esc_url ( 'http://vk.com/share.php?url=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID) ). ' " class="vk" rel="nofollow" target="_blank">'. __( 'vk', 'rara-business-pro' ) .'</a></li>';      
            
            break; 

            case 'pocket':
            echo '<li> <a href=" ' . esc_url ( 'https://getpocket.com/edit?url=' . get_the_permalink( $post->ID ) . '&title=' . get_the_title( $post->ID) ). ' " class="pocket" rel="nofollow" target="_blank">'. __( 'pocket', 'rara-business-pro' ) .'</a></li>';      
            
            break;  
        }
    }
endif;

if( ! function_exists( 'rara_business_pro_author_social' ) ) :
    /**
     * Author Social Links
     */
    function rara_business_pro_author_social(){
        $id        = get_the_author_meta( 'ID' );
        $facebook  = get_user_meta( $id, '_bfp_facebook', true );
        $twitter   = get_user_meta( $id, '_bfp_twitter', true );
        $instagram = get_user_meta( $id, '_bfp_instagram', true );
        $snapchat  = get_user_meta( $id, '_bfp_snapchat', true );
        $pinterest = get_user_meta( $id, '_bfp_pinterest', true );
        $linkedin  = get_user_meta( $id, '_bfp_linkedin', true );
        $gplus     = get_user_meta( $id, '_bfp_gplus', true );
        $youtube   = get_user_meta( $id, '_bfp_youtube', true );
        
        if( $facebook || $twitter || $instagram || $snapchat || $pinterest || $linkedin || $gplus || $youtube ){
            echo '<ul class="social-networks">';
            if( $facebook ){
                echo '<li><a href="' . esc_url( $facebook ) . '"><i class="fa fa-facebook"></i></a></li>';
            }
            if( $twitter ){
                echo '<li><a href="' . esc_url( $twitter ) . '"><i class="fa fa-twitter"></i></a></li>';
            }
            if( $instagram ){
                echo '<li><a href="' . esc_url( $instagram ) . '"><i class="fa fa-instagram"></i></a></li>';
            }
            if( $snapchat ){
                echo '<li><a href="' . esc_url( $snapchat ) . '"><i class="fa fa-snapchat"></i></a></li>';
            }
            if( $pinterest ){
                echo '<li><a href="' . esc_url( $pinterest ) . '"><i class="fa fa-pinterest"></i></a></li>';
            }
            if( $linkedin ){
                echo '<li><a href="' . esc_url( $linkedin ) . '"><i class="fa fa-linkedin"></i></a></li>';
            }
            if( $gplus ){
                echo '<li><a href="' . esc_url( $gplus ) . '"><i class="fa fa-google-plus"></i></a></li>';
            }
            if( $youtube ){
                echo '<li><a href="' . esc_url( $youtube ) . '"><i class="fa fa-youtube-play"></i></a></li>';
            }
            echo '</ul>';
        }
    }
endif;

if( ! function_exists( 'rara_business_pro_custom_header_link' ) ) :
    /**
     * Additional Link in menu
     */
    function rara_business_pro_custom_header_link(){
        $default_options = rara_business_pro_default_theme_options(); // Get default theme options
        $link_type       = get_theme_mod( 'custom_link_option', $default_options['custom_link_option'] );
        $button_icon     = get_theme_mod( 'custom_link_icon', $default_options['custom_link_icon'] );
        $label           = get_theme_mod( 'custom_link_label', $default_options['custom_link_label'] );
        $link            = get_theme_mod( 'custom_link', $default_options['custom_link'] );
        $page_id         = get_theme_mod( 'custom_link_page', $default_options['custom_link_page'] );
        $ed_new_tab      = get_theme_mod( 'ed_custom_link_tab', $default_options['ed_custom_link_tab'] );
        $target          = $ed_new_tab ? ' target="_blank"' : '';

        $return = '';

        if( 'custom' == $link_type && $link && $label){
            if( ! empty( $button_icon ) ){
                $return .= '<a href="' . esc_url( $link ) . '" class="btn-buy custom_label"' . $target . '><i class="'. esc_attr( $button_icon ) .'"></i>' . esc_html( $label ) . '</a>';
            } else {
                $return .= '<a href="' . esc_url( $link ) . '" class="btn-buy"' . $target . '>' . esc_html( $label ) . '</a>';
            }
        }elseif( $page_id ){
            $page_obj = get_post( $page_id );

            if( ! empty( $page_obj ) ){
                $button_icon = ! empty( $button_icon ) ? $button_icon : '';
                $title       = $page_obj->post_title;
                $url         = get_the_permalink( $page_obj->ID );

                if( ! empty( $button_icon ) ){
                    $return .= '<a href="' . esc_url( $url ) . '" class="btn-buy"' . $target . '><i class="'. esc_attr( $button_icon ) .'"></i>' . esc_html( $title ) . '</a>';
                } else {
                    $return .= '<a href="' . esc_url( $url ) . '" class="btn-buy"' . $target . '>' . esc_html( $title ) . '</a>';
                }
            }
        }

        return $return;
    }
endif;

if( ! function_exists( 'rara_business_pro_get_categories' ) ) :
    /**
     * Function to list post categories in customizer options
     */
    function rara_business_pro_get_categories( $select = true, $taxonomy = 'category', $slug = false ){    
        /* Option list of all categories */
        $categories = array();
        
        $args = array( 
            'hide_empty' => false,
            'taxonomy'   => $taxonomy 
        );
        
        $catlists = get_terms( $args );
        if( $select ) $categories[''] = __( 'Choose Category', 'rara-business-pro' );
        foreach( $catlists as $category ){
            if( $slug ){
                $categories[$category->slug] = $category->name;
            }else{
                $categories[$category->term_id] = $category->name;    
            }        
        }
        
        return $categories;
    }
endif;

if( ! function_exists( 'rara_business_pro_get_id_from_page' ) ) :
    /**
    * Get page ids from page name.
    */
    function rara_business_pro_get_id_from_page( $slider_pages ){
        if( $slider_pages ){
            $ids = array();
            foreach( $slider_pages as $p ){
                if( !empty( $p['page'] ) ){
                   $page_ids = get_page_by_title( $p['page'] );
                   $ids[] = $page_ids->ID;
                }
            }  
            return $ids;
        }else{
            return false;
        }
    }
endif;