<?php

/**
 * Post/page Metabox.
 *
 * This is the template that includes metaboxes of Rara Readable Pro theme
 *
 * @package Rara_Business_Pro
 */
 
/**
 * Class to Renders and save metabox options
 *
 * @since 2.0.0
 */
class Rara_Business_Pro_MetaBox {
    private $meta_box;

    private $fields;

    /**
    * Constructor
    *
    * @since 2.0.0
    *
    * @access public
    *
    */
    public function __construct( $meta_box_id, $meta_box_title, $post_type ) {
        
        $this->meta_box = array (
                            'id'        => $meta_box_id,
                            'title'     => $meta_box_title,
                            'post_type' => $post_type,
                            );

        $this->fields = array(
                            'sidebar_layout',
                            'selected_sidebar',
                            );


        // Add metaboxes
        add_action( 'add_meta_boxes', array( $this, 'add' ) );
        
        add_action( 'save_post', array( $this, 'save' ) );  
    }

    /**
    * Add Meta Box for multiple post types.
    *
    * @since 2.0.0
    *
    * @access public
    */
    public function add($postType) {
        if( in_array( $postType, $this->meta_box['post_type'] ) ) {
            add_meta_box( $this->meta_box['id'], $this->meta_box['title'], array( $this, 'show' ), $postType );
        }
    }

    /**
    * Renders metabox
    *
    * @since 2.0.0
    *
    * @access public
    */
    public function show() {
        global $post;

        $layout_options = array(    
            'default-sidebar'=> array(
                 'value'     => 'default-sidebar',
                 'label'     => __( 'Default Sidebar', 'rara-business-pro' ),
                 'thumbnail' => get_template_directory_uri() . '/images/default-sidebar.png'
            ),
            'no-sidebar'     => array(
                 'value'     => 'no-sidebar',
                 'label'     => __( 'Full Width', 'rara-business-pro' ),
                 'thumbnail' => get_template_directory_uri() . '/images/no-sidebar.png'
            ),    
            'left-sidebar' => array(
                 'value'     => 'left-sidebar',
                 'label'     => __( 'Left Sidebar', 'rara-business-pro' ),
                 'thumbnail' => get_template_directory_uri() . '/images/left-sidebar.png'         
            ),
            'right-sidebar' => array(
                 'value'     => 'right-sidebar',
                 'label'     => __( 'Right Sidebar', 'rara-business-pro' ),
                 'thumbnail' => get_template_directory_uri() . '/images/right-sidebar.png'         
             )    
        );


        // Use nonce for verification  
        wp_nonce_field( basename( __FILE__ ), 'rara_business_pro_custom_meta_box_nonce' );

        // Begin the field table and loop  ?>  
        <div id="rara-business-pro-ui-tabs" class="ui-tabs">
            <ul class="rara-business-pro-ui-tabs-nav" id="rara-business-pro-ui-tabs-nav">
                <li><a href="#frag1"><?php esc_html_e( 'Sidebar Layout', 'rara-business-pro' ); ?></a></li>
                <li><a href="#frag2"><?php esc_html_e( 'Select Sidebar', 'rara-business-pro' ); ?></a></li>
            </ul> 
            
            <div id="frag1" class="metabox_tabhead">
                <table id="layout-options" class="form-table" width="100%">
                    <tbody>
                        <tr>
                           <?php  
                            $sidebar_layout = get_post_meta( $post->ID, 'sidebar_layout', true );
                            if ( empty( $sidebar_layout ) ){
                                $sidebar_layout = 'default-sidebar';
                            }
                            foreach( $layout_options as $field ){ ?>

                            <div class="hide-radio radio-image-wrapper" style="float:left; margin-right:30px;">
                                <input id="<?php echo esc_attr( $field['value'] ); ?>" type="radio" name="sidebar_layout" value="<?php echo esc_attr( $field['value'] ); ?>" <?php checked( $field['value'], $sidebar_layout ); if( empty( $sidebar_layout ) ){ checked( $field['value'], 'default-sidebar' ); }?>/>
                                <label class="description" for="<?php echo esc_attr( $field['value'] ); ?>">
                                    <img src="<?php echo esc_url( $field['thumbnail'] ); ?>" alt="<?php echo esc_attr( $field['value'] ); ?>" />
                                </label>
                            </div>
                            <?php } // end foreach ?>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div id="frag2" class="metabox_tabhead">
                <table id="sidebar-metabox" class="form-table" width="100%">
                    <tbody> 
                        <tr>
                            <?php
                            $sidebar_options = rara_business_pro_get_dynamnic_sidebar( true, true, true );
                            $metasidebar     = get_post_meta( $post->ID, 'selected_sidebar', true );

                            if ( empty( $metasidebar ) ){
                                $metasidebar = 'default-sidebar';
                            }?>

                            <select name="selected_sidebar">
                            <?php 
                                foreach( $sidebar_options as $k => $v ){ ?>
                                    <option value="<?php echo esc_attr( $k ); ?>" <?php selected( $metasidebar, $k ); ?> ><?php echo esc_html( $v ); ?></option>
                                <?php }
                            ?>
                            </select>
                        </tr>
                        <tr>
                            <td><span style="font-weight: 300; font-style: italic;"><?php printf( esc_html__( 'You can set up the sidebar content from %s', 'rara-business-pro' ), '<a href="'. esc_url( admin_url( 'widgets.php' ) ) .'">here</a>' ); ?></span></td>
                        </tr>
                    </tbody>
                </table>        
            </div>
        </div>
    <?php 
    }

    /**
     * Save custom metabox data
     * 
     * @action save_post
     *
     * @since 2.0.0
     *
     * @access public
     */
    public function save( $post_id ) { 
    
        // Checks save status
        $is_autosave = wp_is_post_autosave( $post_id );
        $is_revision = wp_is_post_revision( $post_id );
        $is_valid_nonce = ( isset( $_POST[ 'rara_business_pro_custom_meta_box_nonce' ] ) && wp_verify_nonce( $_POST[ 'rara_business_pro_custom_meta_box_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

        // Exits script depending on save status
        if ( $is_autosave || $is_revision || ! $is_valid_nonce ) {
            return;
        }
      
        foreach ( $this->fields as $field ) {      
            // Checks for input and sanitizes/saves if needed
            if( isset( $_POST[ $field ] ) ) {
                update_post_meta( $post_id, $field, ( $_POST[ $field ] ) );
            }
        } // end foreach         
    }
}

$rara_business_pro_metabox = new Rara_Business_Pro_MetaBox( 
                                    'rara_business_pro_sidebar_options',                  //metabox id
                                    esc_html__( 'Rara Business Pro Sidebar Options', 'rara-business-pro' ), //metabox title
                                    array( 'page', 'post' )             //metabox post types
                                );

/**
 * Enqueue scripts and styles for Metaboxes
 * @uses wp_enqueue_script, and  wp_enqueue_style
 *
 * @since 2.0.0
 */
function rara_business_pro_enqueue_metabox_scripts( $hook ) {
    // Use minified libraries if SCRIPT_DEBUG is turned off
    $build  = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '/build' : '';
    $suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

    if( $hook == 'post.php' || $hook == 'post-new.php'  ){

        //Scripts
        wp_enqueue_script( 'rara-business-pro-metabox', get_template_directory_uri() . '/inc/js/metabox.js', array( 'jquery', 'jquery-ui-tabs' ), '2013-10-05' );
        //CSS Styles
        wp_enqueue_style( 'rara-business-pro-metabox-tabs', get_template_directory_uri() . '/inc/css/metabox-tabs.css' );
    }
    return;
}
add_action( 'admin_enqueue_scripts', 'rara_business_pro_enqueue_metabox_scripts', 11 );

/**
 * User Profile Extra Fields 
 */
function rara_business_pro_user_fields( $user ) { 
    
    wp_nonce_field( basename( __FILE__ ), 'tap_user_fields_nonce' ); 
    
    if( is_string( $user ) === true ){
        $user = new stdClass();//create a new
        $id = -9999;
        unset( $user );
    }else{
        $id = $user->ID;
    }
     
    $facebook  = get_user_meta( $id, '_bfp_facebook', true );
    $twitter   = get_user_meta( $id, '_bfp_twitter', true );
    $instagram = get_user_meta( $id, '_bfp_instagram', true );
    $snapchat  = get_user_meta( $id, '_bfp_snapchat', true );
    $pinterest = get_user_meta( $id, '_bfp_pinterest', true );
    $linkedin  = get_user_meta( $id, '_bfp_linkedin', true );
    $gplus     = get_user_meta( $id, '_bfp_gplus', true );
    $youtube   = get_user_meta( $id, '_bfp_youtube', true );
    ?>
    
    <h3><?php esc_html_e( 'User Social Link', 'rara-business-pro' ); ?></h3>
    
    <table class="form-table social-profile">    
        <tr>
            <th><label for="facebook"><?php esc_html_e( 'Facebook Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="facebook" id="facebook" value="<?php echo esc_attr( $facebook ? $facebook : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Facebook Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="twitter"><?php esc_html_e( 'Twitter Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="twitter" id="twitter" value="<?php echo esc_attr( $twitter ? $twitter : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Twitter Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="instagram"><?php esc_html_e( 'Instagram Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="instagram" id="instagram" value="<?php echo esc_attr( $instagram ? $instagram : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Instagram Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="snapchat"><?php esc_html_e( 'Snapchat Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="snapchat" id="snapchat" value="<?php echo esc_attr( $snapchat ? $snapchat : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Snapchat Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>  
        <tr>
            <th><label for="pinterest"><?php esc_html_e( 'Pinterest Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="pinterest" id="pinterest" value="<?php echo esc_attr( $pinterest ? $pinterest : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Pinterest Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="linkedin"><?php esc_html_e( 'LinkedIn Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="linkedin" id="linkedin" value="<?php echo esc_attr( $linkedin ? $linkedin : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your LinkedIn Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>      
        <tr>
            <th><label for="gplus"><?php esc_html_e( 'Google Plus Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="gplus" id="gplus" value="<?php echo esc_attr( $gplus ? $gplus : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your Google Plus Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>
        <tr>
            <th><label for="youtube"><?php esc_html_e( 'YouTube Url', 'rara-business-pro' ); ?></label></th>
            <td>
                <input type="text" name="youtube" id="youtube" value="<?php echo esc_attr( $youtube ? $youtube : '' ); ?>" class="regular-text" /><br />
                <span class="description"><?php esc_html_e( "Please enter your YouTube Url.", 'rara-business-pro' ); ?></span>
            </td>
        </tr>          
    </table>
<?php 
}
/** Hooks to add extra field in profile */
add_action( 'show_user_profile', 'rara_business_pro_user_fields' ); // editing your own profile
add_action( 'edit_user_profile', 'rara_business_pro_user_fields' ); // editing another user
add_action( 'user_new_form', 'rara_business_pro_user_fields' ); // creating a new user

/**
 * Saving Extra User Profile Information
*/ 
function rara_business_pro_save_user_fields( $user_id ) {

    // Check if our nonce is set.
    if ( ! isset( $_POST['tap_user_fields_nonce'] ) ) {
        return;
    }

    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $_POST['tap_user_fields_nonce'], basename( __FILE__ ) ) ) {
        return;
    }

    if ( !current_user_can( 'edit_user', $user_id ) ) return false;

    if( isset( $_POST['facebook'] ) ){
        $facebook = esc_url_raw( $_POST['facebook'] );
        update_user_meta( $user_id, '_bfp_facebook', $facebook );
    }
    
    if( isset( $_POST['twitter'] ) ){
        $twitter = esc_url_raw( $_POST['twitter'] );
        update_user_meta( $user_id, '_bfp_twitter', $twitter );
    }
    
    if( isset( $_POST['instagram'] ) ){
        $instagram = esc_url_raw( $_POST['instagram'] );
        update_user_meta( $user_id, '_bfp_instagram', $instagram );
    }
    
    if( isset( $_POST['snapchat'] ) ){
        $snapchat = esc_url_raw( $_POST['snapchat'] );
        update_user_meta( $user_id, '_bfp_snapchat', $snapchat );
    }
    
    if( isset( $_POST['pinterest'] ) ){
        $pinterest = esc_url_raw( $_POST['pinterest'] );
        update_user_meta( $user_id, '_bfp_pinterest', $pinterest );
    }
    
    if( isset( $_POST['linkedin'] ) ){
        $linkedin = esc_url_raw( $_POST['linkedin'] );
        update_user_meta( $user_id, '_bfp_linkedin', $linkedin );
    }
    
    if( isset( $_POST['gplus'] ) ){
        $gplus = esc_url_raw( $_POST['gplus'] );
        update_user_meta( $user_id, '_bfp_gplus', $gplus );
    }
    
    if( isset( $_POST['youtube'] ) ){
        $youtube = esc_url_raw( $_POST['youtube'] );
        update_user_meta( $user_id, '_bfp_youtube', $youtube );
    }
    
}
/** Hook to Save Extra User Fields */
add_action( 'personal_options_update', 'rara_business_pro_save_user_fields' );
add_action( 'edit_user_profile_update', 'rara_business_pro_save_user_fields' );
add_action( 'user_register', 'rara_business_pro_save_user_fields' );
