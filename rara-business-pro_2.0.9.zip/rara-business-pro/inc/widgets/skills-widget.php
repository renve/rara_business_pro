<?php
/**
 * Skills Widget
 *
 * @package Rara_Theme_Companion
 */

// register Rara_Business_Pro_Skills_Widget widget
function rara_business_pro_register_skills_widget(){
    register_widget( 'Rara_Business_Pro_Skills_Widget' );
}
add_action('widgets_init', 'rara_business_pro_register_skills_widget');
 
 /**
 * Adds Rara_Business_Pro_Skills_Widget widget.
 */
class Rara_Business_Pro_Skills_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        add_action( 'admin_print_footer_scripts', array( $this,'rara_business_pro_skill_widget_item_template' ) );
        add_action( 'admin_footer-widgets.php', array( $this, 'print_scripts' ), 9999 );
        add_action( 'load-widgets.php', array( $this, 'rbp_load_cta_colorpicker' ) );
        parent::__construct(
            'rbp_skills_widget', // Base ID
            __( 'Rara: Skills', 'rara-business-pro' ), // Name
            array( 
                'class' => 'rbp_skills_widget',
                'description' => __( 'A Widget for the statistics.', 'rara-business-pro' ), 
            ) // Args
        );
    }

    /**
     * 
     * Items template.
     *
     * @since 1.0.0
     */
    function rara_business_pro_skill_widget_item_template() { ?>
        
        <div class="rbp-skills-template">
            <div class="skills-repeat" data-id=""><span><i class="fa fa-times cross"></i></span>
                <label for="widget-rbp_skills_widget-2-skill_title-1"><?php _e( 'Skill Title','rara-business-pro' );?></label> 
                <input class="widefat skill_title" id="widget-rbp_skills_widget-2-skill_title-1" name="widget-rbp_skills_widget[2][skill_title][1]" type="text" value="">   
                <label for="widget-rbp_skills_widget-2-skill_value-1"><?php _e( 'Skill Value ( % )','rara-business-pro' );?></label> 
                <input class="skill_value" id="widget-rbp_skills_widget-2-skill_value-1" name="widget-rbp_skills_widget[2][skill_value][1]" type="number" min="1" max="100" step="1"></input>         
            </div>
        </div>
        <?php
        echo '<style>.rbp-skills-template{display:none;}</style>';
        }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        
        $obj             = new Rara_Business_Pro_Widget_Class();
        $title           = ! empty( $instance['title'] ) ? $instance['title'] : '' ;        
        $content         = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $bgcolor         = apply_filters('rbp_skill_section_bg_color','#0aa3f3');
        $widget_bg_color = ! empty($instance['widget-bg-color']) ? esc_attr($instance['widget-bg-color']): $bgcolor;
        $widget_bg_image = ! empty($instance['widget-bg-image']) ? esc_attr($instance['widget-bg-image']): '';

        echo $args['before_widget']; 

        if( $widget_bg_image ){
            $attachment_id =  $widget_bg_image;
            $image_array   = wp_get_attachment_image_src( $attachment_id, 'full' );
            $image      = preg_match('/(^.*\.jpg|jpeg|png|gif|ico*)/i', $image_array[0] );
            $fimg_url      = $image_array[0];    

            $skill_class = ' rbp-skill-bg-image';
            $bg = ' style="background:url(' . esc_url( $fimg_url ) . ') no-repeat; background-size: cover; background-position: center"';
        }else{
            $skill_class = '';
            $bg = ' style="background:'. $widget_bg_color .'"';
        }
        ?>

        <div class="skill-wrapper <?php echo esc_attr( $skill_class ); ?>" <?php echo $bg;?>> 
            <div class="skill-wrapper-inner">
            <?php
                if( ! empty( $title ) || ! empty( $content ) ){ ?>
                <div class="text-holder">
                    <?php 
                        if( $title ) echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title']; 
                        if( $content ) echo wpautop( wp_kses_post( $content ) );
                    ?>
                </div>
                <?php } ?>
                <div class="skills-holder">
                    <div class="skills">
                        <?php if( isset( $instance['skill_title'] ) && isset( $instance['skill_value'] ) ) : 
                                foreach( $instance['skill_title'] as $key => $value){ ?> 
                                    <div class="skill">
                                        <div class="skill-title"><?php echo esc_html( $value ) ?></div>
                                        <div class="skill-bar" data-bar="<?php echo esc_attr( $instance['skill_value'][$key] ); ?>"><span></span></div>
                                    </div>
                        <?php  } endif; ?>
                    </div>
                </div>
            </div><!-- .skill-wrapper-inner -->
        </div><!-- .skill-wrapper -->

        <?php echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $obj             = new Rara_Business_Pro_Widget_Class();
        $title           = ! empty( $instance['title'] ) ? $instance['title'] : '' ;        
        $content         = ! empty( $instance['content'] ) ? $instance['content'] : '';
        $bgcolor         = apply_filters('rbp_skill_section_bg_color','#0aa3f3');
        $skill_title     = ! empty( $instance['skill_title'] ) ? $instance['skill_title'] : '' ;        
        $skill_value     = ! empty( $instance['skill_value'] ) ? $instance['skill_value'] : '' ;
        $widget_bg_color = ! empty($instance['widget-bg-color']) ? esc_attr($instance['widget-bg-color']):$bgcolor;
        $widget_bg_image = !empty($instance['widget-bg-image']) ? esc_attr($instance['widget-bg-image']):'';
        ?>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'rara-business-pro' ); ?></label> 
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />            
            </p>
            
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>"><?php esc_html_e( 'Description', 'rara-business-pro' ); ?></label>
                <textarea name="<?php echo esc_attr( $this->get_field_name( 'content' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content' ) ); ?>" rows="6" cols="50"><?php echo wp_kses_post( $content ); ?></textarea>
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'widget-bg-color' ) ); ?>"><?php esc_html_e( 'Background Color', 'rara-business-pro' ); ?></label>
                <input type="text" class="my-widget-color-field" name="<?php echo esc_attr( $this->get_field_name( 'widget-bg-color' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'widget-bg-color' ) ); ?>" value="<?php echo esc_attr( $widget_bg_color ); ?>" />
            </p>
            Or,
            <?php
                $obj->rara_business_pro_get_image_field( $this->get_field_id( 'widget-bg-image' ), $this->get_field_name( 'widget-bg-image' ),  $widget_bg_image, __( 'Upload Image', 'rara-business-pro' ) );
            ?>
            <div class="widget-skills-repeater" id="<?php echo esc_attr( $this->get_field_id( 'rbp-skills-repeater' ) ); ?>">
            <?php if( ! isset( $skill_title ) || $skill_title=='' ){ ?>
                    <div class="skills-repeat" data-id="1">
                        <i class="fa fa-arrows-alt handle" aria-hidden="true"></i>
                        <span><i class="fa fa-times cross"></i></span>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'skill_title[1]' ) ); ?>"><?php esc_html_e( 'Skill Title', 'rara-business-pro' ); ?></label> 
                        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'skill_title[1]' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'skill_title[1]' ) ); ?>" type="text" value="" />   
                        <label for="<?php echo esc_attr( $this->get_field_id( 'skill_value[1]' ) ); ?>"><?php esc_html_e( 'Skill Value', 'rara-business-pro' ); ?></label> 
                        <input id="<?php echo esc_attr( $this->get_field_id( 'skill_value[1]' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'skill_value[1]' ) ); ?>" type="number" min="1" max="100" step="1" value=""></input>         
                    </div>
                <?php
                }

                if( isset( $instance['skill_title'] ) && $instance['skill_title'] !='' ){
                    $title_array = $instance['skill_title'];
                    $titles = array_keys( $title_array ); 
                    foreach ( $titles as $title => $value ) { ?>
                            <div class="skills-repeat" data-id="<?php echo $value; ?>">
                                <i class="fa fa-arrows-alt handle" aria-hidden="true"></i>
                                <span><i class="fa fa-times cross"></i></span>
                                <label for="<?php echo esc_attr( $this->get_field_id( 'skill_title['.$value.']' ) ); ?>"><?php esc_html_e( 'Skill Title', 'rara-business-pro' ); ?></label> 
                                <input class="widefat demo" id="<?php echo esc_attr( $this->get_field_id( 'skill_title['.$value.']' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'skill_title['.$value.']' ) ); ?>" type="text" value="<?php echo esc_attr($instance['skill_title'][$value]);?>" />   
                                <label for="<?php echo esc_attr( $this->get_field_id( 'skill_value['.$value.']' ) ); ?>"><?php esc_html_e( 'Skill Value ( % )', 'rara-business-pro' ); ?></label> 
                                <input class="skill_value" id="<?php echo esc_attr( $this->get_field_id( 'skill_value['.$value.']' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'skill_value['.$value.']' ) ); ?>"  type="number" min="1" max="100" step="1" value="<?php echo esc_attr( $instance['skill_value'][$value] ); ?>"></input>         
                            </div>
                    <?php
                    }
                }
                ?>
            <span class="cl-skill-holder"></span>
            </div>
            <button id="add-skill" class="button"><?php _e('Add Skills','rara-business-pro');?></button>
        <?php
            echo "<script> 
                jQuery(document).ready(function($){
                    $('.widget-skills-repeater').sortable({
                        cursor: 'move',
                        update: function (event, ui) {
                            $('.widget-skills-repeater .skills-repeat').trigger('change');
                        }
                    });
                });
            </script>";
    }
    
    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = array();

        $instance['title']           = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '' ;
        $instance['content']         = ! empty( $new_instance['content'] ) ? wp_kses_post( $new_instance['content'] ) : '';
        $bgcolor                     = apply_filters('rbp_skill_section_bg_color','#0aa3f3');
        $instance['widget-bg-color'] = isset($new_instance['widget-bg-color']) ? esc_attr($new_instance['widget-bg-color']):$bgcolor;
        $instance['widget-bg-image'] = isset($new_instance['widget-bg-image']) ? esc_attr($new_instance['widget-bg-image']):'';

        if( isset($new_instance['skill_title'] ) )
        {
            foreach ( $new_instance['skill_title'] as $key => $value ) {
                $instance['skill_title'][$key]   = $value;
            }
        }

        if( isset($new_instance['skill_value']))
        {
            foreach ( $new_instance['skill_value'] as $key => $value ) {
                $instance['skill_value'][$key]    = $value;
            }
        }

        return $instance;
    }

    public function rbp_load_cta_colorpicker() {    
        wp_enqueue_style( 'wp-color-picker' );        
        wp_enqueue_script( 'wp-color-picker' );    
    }

    public function print_scripts() {
        ?>
        <script>
            
            ( function( $ ){
                
                function initColorPicker( widget ) {
                    widget.find( '.my-widget-color-field' ).wpColorPicker( {
                        change: _.throttle( function() { // For Customizer
                            $(this).trigger( 'change' );
                        }, 3000 )
                    });
                }

                function onFormUpdate( event, widget ) {
                    initColorPicker( widget );
                }

                $( document ).on( 'widget-added widget-updated', onFormUpdate );

                $( document ).ready( function() {
                    $( '#widgets-right .widget:has(.my-widget-color-field)' ).each( function () {
                        initColorPicker( $( this ) );
                    } );
                } );



            }( jQuery ) );

        </script>
        <?php
    }
}  // class Rara_Business_Pro_Skills_Widget