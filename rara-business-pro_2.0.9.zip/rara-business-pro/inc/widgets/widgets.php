<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 * @package Rara_Business_Pro
 */
function rara_business_pro_widgets_init() {
	
    $sidebars = array(
        'primary-sidebar' => array(
            'name'        => __( 'Primary Sidebar', 'rara-business-pro' ),
            'id'          => 'primary-sidebar', 
            'description' => __( 'Default Sidebar', 'rara-business-pro' ),
        ),
        'services' => array(
            'name'        => __( 'Services Widget', 'rara-business-pro' ),
            'id'          => 'services', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Icon Text" widget for the services.', 'rara-business-pro' ),
        ),
        'about' => array(
            'name'        => __( 'About Widget', 'rara-business-pro' ),
            'id'          => 'about', 
            'description' => __( 'Add "Rara: Featured Page Widget" for about section.', 'rara-business-pro' ),
        ),
        'choose-us' => array(
            'name'        => __( 'Why Choose Us Widget', 'rara-business-pro' ),
            'id'          => 'choose-us', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Icon Text" widget for the choos us reasons. Add "Image" widget for featured image.', 'rara-business-pro' ),
        ),
        'team' => array(
            'name'        => __( 'Team Widget', 'rara-business-pro' ),
            'id'          => 'team', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Team Member" widget for the team members.', 'rara-business-pro' ),
        ),
        'testimonial' => array(
            'name'        => __( 'Testimonial Widget', 'rara-business-pro' ),
            'id'          => 'testimonial', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Testimonial" widget for the testimonials.', 'rara-business-pro' ),
        ),
        'stats' => array(
            'name'        => __( 'Stat Counter Widget', 'rara-business-pro' ),
            'id'          => 'stats', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Stat Counter Widget" for the statistics.', 'rara-business-pro' ),
        ),
        'skill' => array(
            'name'        => __( 'Skill Widget', 'rara-business-pro' ),
            'id'          => 'skill', 
            'description' => __( 'Add "Rara: Skills" widget for the title, description and skills.', 'rara-business-pro' ),
        ),
        'pricing' => array(
            'name'        => __( 'Pricing  Widget', 'rara-business-pro' ),
            'id'          => 'pricing', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: Pricing Table Widget" for Pricing Options.', 'rara-business-pro' ),
        ),
        'cta' => array(
            'name'        => __( 'Call To Action Widget', 'rara-business-pro' ),
            'id'          => 'cta', 
            'description' => __( 'Add "Rara : Call To Action widget" for the title, description and call to action buttons.', 'rara-business-pro' ),
        ),
        'faq' => array(
            'name'        => __( 'FAQs Widget', 'rara-business-pro' ),
            'id'          => 'faq', 
            'description' => __( 'Add "Text" widget for the title and description. Add "Rara: FAQs" widget for frequently asked questions.', 'rara-business-pro' ),
        ),
        'client' => array(
            'name'        => __( 'Clients Widget', 'rara-business-pro' ),
            'id'          => 'client', 
            'description' => __( 'Add "Rara: Client Logo" widget for client logos.', 'rara-business-pro' ),
        ),
        'team-template' => array(
            'name'        => __( 'Team Template Widget', 'rara-business-pro' ),
            'id'          => 'team-template', 
            'description' => __( 'Add "Rara: Team Member" widget for the team members in Team Template Page.', 'rara-business-pro' ),
        ),
        'faq-template' => array(
            'name'        => __( 'FAQ Template Widget', 'rara-business-pro' ),
            'id'          => 'faq-template', 
            'description' => __( 'Add "Rara: FAQs" widget for frequently asked questions in Faq Template Page.', 'rara-business-pro' ),
        ),
        'testimonial-template' => array(
            'name'        => __( 'Testimonial Template Widget', 'rara-business-pro' ),
            'id'          => 'testimonial-template', 
            'description' => __( 'Add "Rara: Testimonial" widget for the testimonials in Testimonial Template Page.', 'rara-business-pro' ),
        ),
        'footer-one'=> array(
            'name'        => __( 'Footer One', 'rara-business-pro' ),
            'id'          => 'footer-one', 
            'description' => __( 'Add footer one widgets here.', 'rara-business-pro' ),
        ),
        'footer-two'=> array(
            'name'        => __( 'Footer Two', 'rara-business-pro' ),
            'id'          => 'footer-two', 
            'description' => __( 'Add footer two widgets here.', 'rara-business-pro' ),
        ),
        'footer-three'=> array(
            'name'        => __( 'Footer Three', 'rara-business-pro' ),
            'id'          => 'footer-three', 
            'description' => __( 'Add footer three widgets here.', 'rara-business-pro' ),
        ),
        'footer-four'=> array(
            'name'        => __( 'Footer Four', 'rara-business-pro' ),
            'id'          => 'footer-four', 
            'description' => __( 'Add footer four widgets here.', 'rara-business-pro' ),
        )
    );
    
    foreach( $sidebars as $sidebar ){
        register_sidebar( array(
    		'name'          => esc_html( $sidebar['name'] ),
    		'id'            => esc_attr( $sidebar['id'] ),
    		'description'   => esc_html( $sidebar['description'] ),
    		'before_widget' => '<section id="%1$s" class="widget %2$s">',
    		'after_widget'  => '</section>',
    		'before_title'  => '<h2 class="widget-title" itemprop="name">',
    		'after_title'   => '</h2>',
    	) );
    }

    /** Dynamic sidebars */
    $dynamic_sidebars = rara_business_pro_get_dynamnic_sidebar();
    
    foreach( $dynamic_sidebars as $k => $v ){
        if( ! empty( $v ) ){
            register_sidebar( array(
                'name'          => esc_attr( $v ),
                'id'            => esc_attr( $k ),
                'description'   => '',
                'before_widget' => '<section id="%1$s" class="widget %2$s">',
                'after_widget'  => '</section>',
                'before_title'  => '<h2 class="widget-title">',
                'after_title'   => '</h2>',
            ) );
        }
    }
}
add_action( 'widgets_init', 'rara_business_pro_widgets_init' );

/**
 * Addition of widget class.
 */
require get_template_directory() . '/inc/widgets/widgets-class.php';

/**
 * Addition of pricing widget.
 */
require get_template_directory() . '/inc/widgets/pricing-widget.php';

/**
 * Addition of skills widget.
 */
require get_template_directory() . '/inc/widgets/skills-widget.php';

/**
 * Addition of author widget.
 */
require get_template_directory() . '/inc/widgets/author-widget.php';

/**
 * Widget Twitter Feeds
 */
require get_template_directory() . '/inc/widgets/twitter-feeds-widget.php';

if( ! function_exists( 'rara_business_pro_recent_post_thumbnail' ) ):
    /**
     * Filter to modify recent post widget thumbnail image
     */
    function rara_business_pro_recent_post_thumbnail( $size ){
        return $size = "rara-business-pro-blog";
    }
endif;
add_filter( 'rara_recent_img_size', 'rara_business_pro_recent_post_thumbnail' );