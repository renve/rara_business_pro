<?php
/**
 * Pricing Table Widget
 *
 * @package Rara_Business_Pro
 */

// register Rara_Business_Pro_Pricing_Table_Widget widget
function rara_business_pro_register_pricing_table_widget(){
    register_widget( 'Rara_Business_Pro_Pricing_Table_Widget' );
}
add_action('widgets_init', 'rara_business_pro_register_pricing_table_widget');
 
 /**
 * Adds Rara_Business_Pro_Pricing_Table_Widget widget.
 */
class Rara_Business_Pro_Pricing_Table_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        add_action( 'admin_print_footer_scripts', array( $this,'rara_business_pro_item_template' ) );
        parent::__construct(
			'rbp_pt_widget', // Base ID
			__( 'RARA: Pricing Table Widget', 'rara-business-pro' ), // Name
			array( 
                'class' => 'rbp_pt_widget our-pricing',
                'description' => __( 'A Pricing Table Widget.', 'rara-business-pro' ),
            ) // Args
		);
    }

    /**
    * 
    * Items template.
    *
    * @since 1.0.0
    */
    function rara_business_pro_item_template() { ?>
        
        <div class="rbp-item-template">
            <li class="rbp-items-wrap">
                <p>
                    <input class="items-length" name="<?php echo esc_attr( $this->get_field_name( 'items[{{indexed}}]' ) ); ?>" type="text" value="" />
                    <span class="rbp-del-item dashicons-no" style="font-family: 'dashicons'"></span>
                </p>
            </li>
        </div>
    <?php
        }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        
        $obj       = new Rara_Business_Pro_Widget_Class();
        $plan_type = ! empty( $instance['plan_type'] ) ? $instance['plan_type'] : 'basic-plan' ;
        $title     = ! empty( $instance['title'] ) ? $instance['title'] : '' ;  
        $currency  = ! empty( $instance['currency'] ) ? $instance['currency'] : '$';
        $price     = ! empty( $instance['price'] ) ? $instance['price'] : '';
        $time      = ! empty( $instance['time'] ) ? $instance['time'] : '/m';
        $image     = ! empty( $instance['image'] ) ? $instance['image'] : '';
        $icon      = ! empty( $instance['icon'] ) ? $instance['icon'] : '';
        $label     = ! empty( $instance['label'] ) ? $instance['label'] : '';
        $link      = ! empty( $instance['link'] ) ? $instance['link'] : '';


        if( $image ){
            $attachment_id =  $image;
            $icon_img_size = apply_filters('icon_img_size','thumbnail');
            $image_array   = wp_get_attachment_image_src( $attachment_id, $icon_img_size);
            $image      = preg_match('/(^.*\.jpg|jpeg|png|gif|ico*)/i', $image_array[0] );
            $fimg_url      = $image_array[0]; 
        }
        
        echo $args['before_widget'];
        ?>
            <div class="rbp-pt-holder col <?php echo esc_attr( $plan_type ); ?>">
                <?php 

                    if( 'popular-plan' == $plan_type ) echo '<span class="tag">'. __( 'Popular Plan', 'rara-business-pro' ) .'</span>';

                    // if( $title ) echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title']; 
                    if( $title ) echo '<h3>'. esc_html( $title ) .'</h3>'; 

                    if( $image ){ ?>
                        <div class="icon-holder">
                            <img src="<?php echo esc_url( $fimg_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
                        </div><!-- .icon-holder -->
                    <?php }elseif( $icon ){ ?>
                        <div class="icon-holder">
                            <span class="fa <?php echo esc_attr( $icon ); ?>"></span>
                        </div><!-- .icon-holder -->
                    <?php } 

                    if( $price ) {
                        echo '<div class="price-holder"><span class="currency">'. esc_html( $currency ) .'</span>'. wp_kses_post( $price ) .'<span class="per-value">'. esc_html( $time ) .'</span></div>';
                    }

                    if( isset( $instance['items'] ) && !empty($instance['items'] ) ){ 
                        echo '<ul class="plan-list">';

                            $items  = $instance['items'];
                            $arr_keys  = array_keys( $items );
                            foreach ( $items as $key => $value )
                            { 
                                if ( array_key_exists( $key,$instance['items'] ) ) { ?>
                                    <li><?php echo wp_kses_post( $instance['items'][$key] ); ?></li>
                                <?php
                                }
                            }

                        echo '</ul>';
                    } 

                    if( ! empty( $link ) && ! empty( $label ) ){
                        echo '<a href="'. esc_url( $link ).'" class="btn-signup">'. esc_html( $label ) .'</a>';
                    }
                ?>
            </div>
        <?php            
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
        
        $obj = new Rara_Business_Pro_Widget_Class();
        $plan_type = ! empty( $instance['plan_type'] ) ? $instance['plan_type'] : 'basic-plan' ;
        $title     = ! empty( $instance['title'] ) ? $instance['title'] : '' ;
        $currency  = ! empty( $instance['currency'] ) ? $instance['currency'] : '$' ;
        $price     = ! empty( $instance['price'] ) ? $instance['price'] : '';
        $time      = ! empty( $instance['time'] ) ? $instance['time'] : '/m';
        $icon      = ! empty( $instance['icon'] ) ? $instance['icon'] : '';
        $image     = ! empty( $instance['image'] ) ? $instance['image'] : '';
        $link      = ! empty( $instance['link'] ) ? $instance['link'] : '';
        $label     = ! empty( $instance['label'] ) ? $instance['label'] : '';
        ?>

		<p>   
            <label for="<?php echo esc_attr( $this->get_field_id( 'plan_type' ) ); ?>"><?php esc_html_e( 'Plan Type', 'rara-business-pro' ); ?></label> 
            <select name="<?php echo $this->get_field_name('plan_type'); ?>" id="<?php echo $this->get_field_id('plan_type'); ?>" class="widefat">
                <?php
                    $types = array (
                        'basic-plan'   => __( 'Basic Plan', 'rara-business-pro' ),
                        'popular-plan' => __( 'Popular Plan', 'rara-business-pro' ),
                        'premium-plan' => __( 'Premium Plan', 'rara-business-pro' ),
                    );

                    foreach ( $types as $key => $option) {
                    echo '<option value="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" '. selected( $plan_type, $key, false ) . ' >' . esc_html( $option ) .'</option>';
                    }
                ?>
            </select>
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'rara-business-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />            
		</p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'currency' ) ); ?>"><?php esc_html_e( 'Currency', 'rara-business-pro' ); ?></label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'currency' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'currency' ) ); ?>" value="<?php print $currency; ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'price' ) ); ?>"><?php esc_html_e( 'Price', 'rara-business-pro' ); ?></label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'price' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'price' ) ); ?>" value="<?php print $price; ?>">
        </p>

         <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'time' ) ); ?>"><?php esc_html_e( 'Per value', 'rara-business-pro' ); ?></label>
            <input type="text" name="<?php echo esc_attr( $this->get_field_name( 'time' ) ); ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'time' ) ); ?>" value="<?php print $time; ?>">
        </p>
        
        <script type='text/javascript'>
            jQuery(document).ready(function($) {
                $('.rbp-sortable-items').sortable({
                    cursor: 'move',
                    update: function (event, ui) {
                        $('ul.rbp-sortable-items input').trigger('change');
                    }
                });
            });
        </script>

        <ul class="rbp-sortable-items" id="<?php echo esc_attr( $this->get_field_id( 'rara-business-pro-items' ) ); ?>">
            <?php
            if(isset($instance['items']))
            {
                $items  = $instance['items'];
                $arr_keys  = array_keys( $items );
                if(isset($arr_keys)){
                    foreach ($arr_keys as $key => $value)
                    { 
                        if ( array_key_exists( $value,$instance['items'] ) )
                        { 
                            ?>
                                <li class="rbp-items-wrap">
                                    <p>
                                        <input class="items-length" name="<?php echo esc_attr( $this->get_field_name( 'items['.$value.']' ) ) ?>" type="text" value="<?php echo esc_attr($instance['items'][$value]);?>" />
                                        <span class="rbp-del-item dashicons-no" style="font-family: 'dashicons'"></span>
                                    </p>
                                </li>
                        <?php
                        }
                    }
                }
            }
            ?>
            <div class="rbp-items-holder"></div>
        </ul>
        <input class="rbp-items-add button-secondary" type="button" value="<?php _e('Add Item','rara-business-pro');?>"><br><br>
        <span class="widget-note"><?php _e('Click the above button to add items. You can sort them as well.','rara-business-pro');?></span>
        
        <?php $obj->rara_business_pro_get_image_field( $this->get_field_id( 'image' ), $this->get_field_name( 'image' ), $image, __( 'Upload Image', 'rara-business-pro' ) ); ?>
        
        <p><strong><?php esc_html_e( 'or', 'rara-business-pro' ); ?></strong></p>
        
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>"><?php esc_html_e( 'Icons', 'rara-business-pro' ); ?></label><br />
            <span class="icon-receiver"><i class="<?php echo esc_attr( $icon ); ?>"></i></span>
            <input class="hidden-icon-input" name="<?php echo esc_attr( $this->get_field_name( 'icon' ) ); ?>" type="hidden" id="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>" value="<?php echo esc_attr( $icon ); ?>" />            
        </p>
        <?php $obj->rara_business_pro_get_icon_list(); ?>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Featured Link', 'rara-business-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_url( $link ); ?>" />            
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'label' ) ); ?>"><?php esc_html_e( 'Label', 'rara-business-pro' ); ?></label> 
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'label' ) ); ?>" type="text" value="<?php echo esc_attr( $label ); ?>" />            
        </p>

        <?php
	}
    
    /**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
        $instance['plan_type'] = ! empty( $new_instance['plan_type'] ) ? esc_attr( $new_instance['plan_type'] ) : 'basic-plan';
        $instance['title']     = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '' ;
        $instance['currency']  = ! empty( $new_instance['currency'] ) ? esc_html( $new_instance['currency'] ) : '';
        $instance['price']     = ! empty( $new_instance['price'] ) ? wp_kses_post( $new_instance['price'] ) : '';
        $instance['time']      = ! empty( $new_instance['time'] ) ? esc_html( $new_instance['time'] ) : '';
        $instance['image']     = ! empty( $new_instance['image'] ) ? esc_attr( $new_instance['image'] ) : '';
        $instance['icon']      = ! empty( $new_instance['icon'] ) ? esc_attr( $new_instance['icon'] ) : '';
        $instance['link']      = ! empty( $new_instance['link'] ) ? esc_attr( $new_instance['link'] ) : '';
        $instance['label']     = ! empty( $new_instance['label'] ) ? esc_attr( $new_instance['label'] ) : '';

        if(isset($new_instance['items']) && !empty($new_instance['items']))
        {
            $arr_keys  = array_keys( $new_instance['items'] );
                    
            foreach ($arr_keys as $key => $value)
            { 
                if ( array_key_exists( $value,$new_instance['items'] ) )
                { 
                    $instance['items'][$value] =  $new_instance['items'][$value];
                }
            }
        }

        return $instance;
	}
    
}  // class Rara_Business_Pro_Pricing_Table_Widget