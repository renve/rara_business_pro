<?php
/**
 * Author Widget
 *
 * @package Rara_Business_Pro
 *
 */

if ( ! class_exists( 'Rara_Business_Pro_Author_Widget' ) ) :
	/**
	 * Author class.
	 * 
	 */

	class Rara_Business_Pro_Author_Widget extends WP_Widget { 
	  
	  private $users_split_at = 200; //Do not run get_users() if there are more than 200 users on the website
	  var $defaults;
		
		function __construct() {
			$widget_ops = array( 
				'classname' => 'rbp_author_widget', 
				'description' => __( 'Use this widget to display author/user profile info', 'rara-business-pro' ) 
			);

			$control_ops = array( 'id_base' => 'rbp_author_widget' );
			parent::__construct( 'rbp_author_widget', __('Rara: Author', 'rara-business-pro'), $widget_ops, $control_ops );

			// Allow themes or plugins to modify default parameters
			$defaults = apply_filters('rbp_author_widget_modify_defaults',array( 
				'title'                => __( 'About Author', 'rara-business-pro' ),
				'author'               => 0,
				'display_name'         => 1,
				'display_avatar'       => 1,
				'display_desc'         => 1,
				'avatar_size'          => 255,
				'link_to_name'         => 0,
				'link_to_avatar'       => 0,
				'display_social_links' => 1,
				'link_url'             => '',
				'limit_chars'          => ''
			));

			$this->defaults = $defaults;
			
		}
		
		function widget( $args, $instance ) {
			
			extract( $args );
			$instance = wp_parse_args( (array) $instance, $this->defaults );

			//Check for user_id
			$user_id = $instance['author'];

			$author_link = ! empty( $instance['link_url'] ) ? esc_url( $instance['link_url'] ) : get_author_posts_url(get_the_author_meta( 'ID',$user_id ) );	
			$title =  apply_filters( 'widget_title', $instance['title'] );
					
			echo $before_widget;

			if ( !empty( $title ) ) {
				echo $before_title . esc_html( $title ) . $after_title;
			}
			?>

			<?php if ( $instance['display_avatar'] ) : ?>
				<?php
				 	if ( $instance['link_to_avatar'] ) {
				 		$pre_avatar = '<a href="'. esc_url( $author_link ) .'">';
				 		$post_avatar = '</a>';
				 	} else {
				 		$pre_avatar = '';
				 		$post_avatar = '';
				 	}
						echo $pre_avatar. wp_kses_post( get_avatar( get_the_author_meta('ID', $user_id), $instance['avatar_size'] ) ) . $post_avatar;
					?>
				<?php endif; ?>

			<?php if ( $instance['display_name'] ) : ?>
			  <?php
			  	if ( $instance['link_to_name'] ) {
				 		$pre_name = '<a href="'. esc_url( $author_link ) .'">';
				 		$post_name = '</a>';
				 	} else {
				 		$pre_name = '';
				 		$post_name = '';
				 	}
					echo '<h3>' . $pre_name . esc_html( get_the_author_meta('display_name', $user_id ) ) . $post_name. '</h3>';
				?>
			<?php endif; ?>

			<?php if ($instance['display_desc'] ) : ?>
				<?php $description = get_the_author_meta( 'description', $user_id ); ?>
				<?php echo wpautop( wp_kses_post( $this->trim_chars( $description, $instance['limit_chars'] ) ) ); ?>
			<?php endif; ?>
				
			<?php if ( $instance['display_social_links'] && !empty( $user_id ) ) : ?>
				<div class="author_social_link_wrap">
					<?php  $this->author_social_links( $user_id ); ?>
				</div>
			<?php endif; ?>

			<?php
			echo $after_widget;

		}
		
		function update( $new_instance, $old_instance ) {
			$instance                      = $old_instance;
			$instance['title']             = strip_tags( $new_instance['title'] );
			$instance['author']            = absint( $new_instance['author'] );
			$instance['display_name']      = isset( $new_instance['display_name'] ) ? 1 : 0;
			$instance['display_avatar']    = isset( $new_instance['display_avatar'] ) ? 1 : 0;
			$instance['display_desc']      = isset( $new_instance['display_desc'] ) ? 1 : 0;
			$instance['display_social_links'] = isset( $new_instance['display_social_links'] ) ? 1 : 0;
			$instance['link_to_name']      = isset( $new_instance['link_to_name'] ) ? 1 : 0;
			$instance['link_to_avatar']    = isset( $new_instance['link_to_avatar'] ) ? 1 : 0;
			$instance['link_url']          = !empty( $new_instance['link_url'] ) ? esc_url( $new_instance['link_url'] ) : '';
			$instance['avatar_size']       = !empty( $new_instance['avatar_size'] ) ? absint( $new_instance['avatar_size'] ) : 255;
			$instance['limit_chars']       = isset( $new_instance['limit_chars'] ) ? absint( $new_instance['limit_chars'] ) : '';


			return $instance;
		}

		function form( $instance ) {

			$instance = wp_parse_args( (array) $instance, $this->defaults );?>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e('Title', 'rara-business-pro'); ?>:</label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" type="text" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" />
			</p>

			<p>
				
				<?php if( $this->count_users() <= $this->users_split_at ) : ?>
				
				<?php $authors = get_users(); ?>
				<label for="<?php echo esc_attr( $this->get_field_id( 'author' ) ); ?>"><?php _e( 'Choose author/user', 'rara-business-pro' ); ?>:</label>
				<select name="<?php echo esc_attr( $this->get_field_name( 'author' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'author' ) ); ?>" class="widefat">
				<?php foreach( $authors as $author ) : ?>
					<option value="<?php echo esc_attr( $author->ID ); ?>" <?php selected( $author->ID, $instance['author']); ?>><?php echo esc_attr( $author->data->user_login ); ?></option>
				<?php endforeach; ?>
				</select>
				
				<?php else: ?>
				
				<label for="<?php echo esc_attr( $this->get_field_id( 'author' ) ); ?>"><?php _e( 'Enter author/user ID', 'rara-business-pro' ); ?>:</label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'author' ) ); ?>" type="text" name="<?php echo esc_attr( $this->get_field_name( 'author' ) ); ?>" value="<?php echo $instance['author']; ?>" class="small-text" />
				
				<?php endif; ?>
				
			</p>

			<h4><?php _e('Display Options', 'rara-business-pro'); ?></h4>
			<ul>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'display_avatar' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'display_avatar' ) ); ?>" value="1" <?php checked(1, $instance['display_avatar']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'display_avatar' ) ); ?>"><?php _e('Display author avatar', 'rara-business-pro'); ?></label>
				</li>
				<li>
					<label for="<?php echo esc_attr( $this->get_field_id( 'avatar_size' ) ); ?>"><?php _e('Avatar size:', 'rara-business-pro'); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'avatar_size' ) ); ?>" type="text" name="<?php echo esc_attr( $this->get_field_name( 'avatar_size' ) ); ?>" value="<?php echo $instance['avatar_size']; ?>" class="small-text"/> px
				</li>
			</ul>
			<hr/>
			<ul>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'display_name' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'display_name' ) ); ?>" value="1" <?php checked(1, $instance['display_name']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'display_name' ) ); ?>"><?php _e('Display author name', 'rara-business-pro'); ?></label>
				</li>
			</ul>
			<hr/>
			<ul>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'display_desc' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'display_desc' ) ); ?>" value="1" <?php checked(1, $instance['display_desc']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'display_desc' ) ); ?>"><?php _e('Display author description', 'rara-business-pro'); ?></label>
				</li>
				<li>
					<label for="<?php echo esc_attr( $this->get_field_id( 'limit_chars' ) ); ?>"><?php _e('Limit description:', 'rara-business-pro'); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'limit_chars' ) ); ?>" type="number" name="<?php echo esc_attr( $this->get_field_name( 'limit_chars' ) ); ?>" value="<?php echo $instance['limit_chars']; ?>" class="widefat" />
					<small class="howto"><?php _e('Specify number of characters to limit author description length', 'rara-business-pro'); ?></small>
				</li>
			</ul>
			<hr/>
			<ul>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'link_to_name' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'link_to_name' ) ); ?>" value="1" <?php checked(1, $instance['link_to_name']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'link_to_name' ) ); ?>"><?php _e('Link author name', 'rara-business-pro'); ?></label>
				</li>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'link_to_avatar' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'link_to_avatar' ) ); ?>" value="1" <?php checked(1, $instance['link_to_avatar']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'link_to_avatar' ) ); ?>"><?php _e('Link author avatar', 'rara-business-pro'); ?></label>
				</li>
				<li>
					<input id="<?php echo esc_attr( $this->get_field_id( 'display_social_links' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'display_social_links' ) ); ?>" value="1" <?php checked(1, $instance['display_social_links']); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'display_social_links' ) ); ?>"><?php _e('Display author social link', 'rara-business-pro'); ?></label>
				</li>

				<li>
					<label for="<?php echo esc_attr( $this->get_field_id( 'link_url' ) ); ?>"><?php _e('Override author link URL:', 'rara-business-pro'); ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'link_url' ) ); ?>" type="text" name="<?php echo esc_attr( $this->get_field_name( 'link_url' ) ); ?>" value="<?php echo $instance['link_url']; ?>" class="widefat"/>
					<small class="howto"><?php _e('Specify custom URL if you want to override default author archive link', 'rara-business-pro'); ?></small>
				</li>
			</ul>

			<?php do_action('rbp_author_widget_add_opts',$this,$instance);?>

			<?php
			
		}
		
		/* Check total number of users on the website */
		function count_users(){
			$user_count = count_users();
			if(isset($user_count['total_users']) && !empty($user_count['total_users'])){
				return $user_count['total_users'];
			}
			return 0;
		}

		/**
		 * Limit character description
		 * 
		 * @param string  $string Content to trim
		 * @param int     $limit  Number of characters to limit
		 * @param string  $more   Chars to append after trimmed string
		 * @return string Trimmed part of the string
		*/
		public function trim_chars( $string, $limit, $more = '...' ) {

			if ( !empty( $limit ) ) {

				$text = trim( preg_replace( "/[\n\r\t ]+/", ' ', $string ), ' ' );
				preg_match_all( '/./u', $text, $chars );
				$chars = $chars[0];
				$count = count( $chars );

				if ( $count > $limit ) {

					$chars = array_slice( $chars, 0, $limit );

					for ( $i = ( $limit -1 ); $i >= 0; $i-- ) {
						if ( in_array( $chars[$i], array( '.', ' ', '-', '?', '!' ) ) ) {
							break;
						}
					}

					$chars =  array_slice( $chars, 0, $i );
					$string = implode( '', $chars );
					$string = rtrim( $string, ".,-?!" );
					$string.= $more;
				}

			}

			return $string;
		}

		public function author_social_links( $id= 0 ){

			if( ! empty( $id ) ){
		        $facebook  = get_user_meta( $id, '_bfp_facebook', true );
		        $twitter   = get_user_meta( $id, '_bfp_twitter', true );
		        $instagram = get_user_meta( $id, '_bfp_instagram', true );
		        $snapchat  = get_user_meta( $id, '_bfp_snapchat', true );
		        $pinterest = get_user_meta( $id, '_bfp_pinterest', true );
		        $linkedin  = get_user_meta( $id, '_bfp_linkedin', true );
		        $gplus     = get_user_meta( $id, '_bfp_gplus', true );
		        $youtube   = get_user_meta( $id, '_bfp_youtube', true );
		        
		        if( $facebook || $twitter || $instagram || $snapchat || $pinterest || $linkedin || $gplus || $youtube ){
		            echo '<ul class="social-networks">';
		            if( $facebook ){
		                echo '<li><a href="' . esc_url( $facebook ) . '" class="facebook"><i class="fa fa-facebook"></i></a></li>';
		            }
		            if( $twitter ){
		                echo '<li><a href="' . esc_url( $twitter ) . '" class="twitter"><i class="fa fa-twitter"></i></a></li>';
		            }
		            if( $instagram ){
		                echo '<li><a href="' . esc_url( $instagram ) . '" class="instagram"><i class="fa fa-instagram"></i></a></li>';
		            }
		            if( $snapchat ){
		                echo '<li><a href="' . esc_url( $snapchat ) . '" class="snapchat"><i class="fa fa-snapchat"></i></a></li>';
		            }
		            if( $pinterest ){
		                echo '<li><a href="' . esc_url( $pinterest ) . '" class="pinterest"><i class="fa fa-pinterest"></i></a></li>';
		            }
		            if( $linkedin ){
		                echo '<li><a href="' . esc_url( $linkedin ) . '" class="linkedin"><i class="fa fa-linkedin"></i></a></li>';
		            }
		            if( $gplus ){
		                echo '<li><a href="' . esc_url( $gplus ) . '" class="google-plus"><i class="fa fa-google-plus"></i></a></li>';
		            }
		            if( $youtube ){
		                echo '<li><a href="' . esc_url( $youtube ) . '" class="youtube"><i class="fa fa-youtube-play"></i></a></li>';
		            }
		            echo '</ul>';
	        	}
	        }
    	}
	}
endif;
function rara_business_pro_register_author_widget() {
	register_widget( 'Rara_Business_Pro_Author_Widget' );
}
add_action( 'widgets_init', 'rara_business_pro_register_author_widget' );