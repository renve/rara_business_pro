<?php
/**
 * Header Two
 * 
 * @package Rara_Business_Pro
*/

$default_options        = rara_business_pro_default_theme_options(); // Get default theme options
$custom_header_link 	= rara_business_pro_custom_header_link();
$ed_header_contact      = get_theme_mod( 'ed_header_contact_details', $default_options['ed_header_contact_details'] );
$phone                  = get_theme_mod( 'header_phone', $default_options['header_phone'] );
$address                = get_theme_mod( 'header_address', $default_options['header_address'] );
$email                  = get_theme_mod( 'header_email', $default_options['header_email'] );
$ed_header_social_links = get_theme_mod( 'ed_header_social_links', $default_options['ed_header_social_links'] );
$social_links           = get_theme_mod( 'header_social_links', $default_options['header_social_links'] );

?>
<header class="site-header center-layout" itemscope itemtype="http://schema.org/WPHeader">
	<?php 
        if( ! ( ( $phone || $address || $email ) && $ed_header_contact ) &&  ! ( $ed_header_social_links && ! empty( $social_links ) ) ){ 
            $class = ' hide-header-top';
        } else {
            $class ='';
        }
    ?>
	<div class="header-t<?php echo esc_attr( $class ); ?>">
		<div class="container">
			<?php 
	            if( ( $phone || $address || $email ) && $ed_header_contact ){ ?>
	                <div class="contact-info">
						<?php 
	                        if( $phone ) rara_business_pro_header_phone( $phone );
	                        if( $address ) rara_business_pro_header_address( $address );
	                        if( $email ) rara_business_pro_header_email( $email ); 
	                    ?>
					</div>
	                <?php 
	            } 
	            rara_business_pro_social_links( $ed_header_social_links, $social_links );

                rara_business_pro_header_primary_toggle_btn();
            ?>
		</div>
		<div class="responsive-menu-holder">
			<div class= "social-networks-holder">
				<div class="container">
					<?php rara_business_pro_social_links( $ed_header_social_links, $social_links ); ?>
				</div>
			</div>
			<div class="container">
				<nav id="site-navigation" class="main-navigation">
					<?php rara_business_pro_primary_nagivation(); ?>
				</nav>
				<?php 
                    if( ! empty( $custom_header_link ) ) echo wp_kses_post( $custom_header_link );
                
                    if( $phone || $address || $email ){ ?>
                        <div class="contact-info">
    						<?php 
                                if( $phone ) rara_business_pro_header_phone( $phone );
                                if( $address ) rara_business_pro_header_address( $address );
                                if( $email ) rara_business_pro_header_email( $email ); 
                            ?>
    					</div>
                        <?php 
                    } 
                ?>
			</div>
		</div>
	</div>
    <div class="sticky-menu-holder"></div>

	<div class="main-header">
		<div class="container">

			<?php  rara_business_pro_header_site_branding(); ?>

			<div class="right">
				<?php if( ! empty( $custom_header_link ) ) echo wp_kses_post( $custom_header_link ); ?>
				<nav id="site-navigation" class="main-navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
        			<?php rara_business_pro_primary_nagivation(); ?>
    		    </nav><!-- #site-navigation -->
			</div>
		</div>
	</div>
</header>