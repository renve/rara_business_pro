<?php
/**
 * Template Name: Testimonial
 *
 * @package Rara_Business_Pro
 */
get_header(); 
	
	if( is_active_sidebar( 'testimonial-template' ) ){ ?>
	    <div class="testimonial-grid">
			<?php dynamic_sidebar( 'testimonial-template' ); ?>
		</div>
	<?php
	}

get_footer();