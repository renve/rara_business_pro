<?php
/**
 * Template Name: Contact
 *
 * @package Rara_Business_Pro
 */
get_header(); 

$default_options       = rara_business_pro_default_theme_options(); 
$header_contact_ctrl   = get_theme_mod( 'ed_header_contact_details', $default_options['ed_header_contact_details'] );
$header_social_ctrl    = get_theme_mod( 'ed_header_social_links', $default_options['ed_header_social_links'] );
$show_header_contact   = get_theme_mod( 'ed_ct_detail_as_in_header', $default_options['ed_ct_detail_as_in_header'] );
$show_header_social    = get_theme_mod( 'ed_ct_sl_as_in_header', $default_options['ed_ct_sl_as_in_header'] );
$contact_detail_title  = get_theme_mod( 'ct_detail_title', $default_options['ct_detail_title'] );
$show_gmap             = get_theme_mod( 'ed_ct_google_map', $default_options['ed_ct_google_map'] );
$show_contact_frontpage = get_theme_mod( 'ed_ct_cf7_as_in_frontpage', $default_options['ed_ct_cf7_as_in_frontpage'] );

if( ! ( $header_contact_ctrl && $show_header_contact ) ){
    $phone_number      = get_theme_mod( 'ct_phone', $default_options['ct_phone'] );
    $address           = get_theme_mod( 'ct_address', $default_options['ct_address'] );
    $email             = get_theme_mod( 'ct_email', $default_options['ct_email'] );
} else {
    $phone_number      = get_theme_mod( 'header_phone', $default_options['header_phone'] );
    $address           = get_theme_mod( 'header_address', $default_options['header_address'] );
    $email             = get_theme_mod( 'header_email', $default_options['header_email'] );
}

if( ! ( $header_social_ctrl && $show_header_social ) ){
    $social_control    = true;
    $social_links      = get_theme_mod( 'ct_social_links', $default_options['ct_social_links'] );
} else {
    $social_control    = $header_social_ctrl;
    $social_links      = get_theme_mod( 'header_social_links', $default_options['header_social_links'] );
}

if( $show_contact_frontpage ){
    $form_shortcode        = get_theme_mod( 'contact_cf7_shortcode', $default_options['contact_cf7_shortcode'] );
} else {
    $form_shortcode        = get_theme_mod( 'ct_cf7_shortcode', $default_options['ct_cf7_shortcode'] );
}
?>
    <div class="contact-grid">
        <div class="left">
            <?php 
                rara_business_pro_breadcrumb(); 
                rara_business_pro_page_header();  

                if( ! empty( $form_shortcode ) ){
                    echo '<div class="form-holder">';
                    echo do_shortcode( $form_shortcode );
                    echo '</div><!-- .form-holder -->';
                }
            ?>
        </div>
        <div class="right">
            <?php 
                if( $show_gmap || has_post_thumbnail() ){
                    echo '<div class="map-holder">';
                        if( $show_gmap ) {
                            echo '<div id="map-canvas" class="map-holder"></div><!-- .map-holder -->';
                        } else {
                            the_post_thumbnail( 'rara-business-gmap', array( 'itemprop' => 'image' ) );
                        }
                    echo '</div>';
                }
             ?>
            
            <div class="contact-info">
                <?php 
                    if( ! empty( $contact_detail_title ) ) echo '<h3>'. esc_html( $contact_detail_title ).'</h3>';
                
                    if( ! empty( $phone_number ) || ! empty( $email ) || ! empty( $address ) ){ 
                        if( !empty( $phone_number ) ) echo ' <div class="phone"><a href="tel:'. esc_attr( preg_replace( '/\D/', '', $phone_number ) ) .'"><i class="fa fa-mobile-phone"></i>'. esc_html( $phone_number ) .'</a></div>';
                        if( !empty( $address ) ) echo '<div class="address"><address><i class="fa fa-map-marker"></i>'. esc_html( $address ) .'</address></div>';
                        if( !empty( $email ) ) echo '<div class="email"><a href="mailto:'. sanitize_email( $email ) .'"><i class="fa fa-envelope-o"></i>'. sanitize_email( $email ) .'</a></div>';
                    }
                    
                    rara_business_pro_social_links( $social_control, $social_links ); 
                ?>
            </div>
        </div>
    </div>
<?php
get_footer();
