<?php
/**
 * Template Name: Team
 *
 * @package Rara_Business_Pro
 */
get_header(); 
	
	if( is_active_sidebar( 'team-template' ) ){ ?>
	    <div class="team-grid">
			<?php dynamic_sidebar( 'team-template' ); ?>
		</div>
	<?php
	}

get_footer();