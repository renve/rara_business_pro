<?php
/**
 * Template Name: FAQ
 *
 * @package Rara_Business_Pro
 */
get_header(); 

	if( is_active_sidebar( 'faq-template' ) ){ ?>
	    <section class="widget widget_raratheme_companion_faqs_widget">
	        <div class="col">
	            <?php dynamic_sidebar( 'faq-template' ); ?>
	        </div>
	    </section>
	<?php
	}
	
get_footer();
