=== Rara Business Pro ===

Contributors: Rara Theme (http://raratheme.com)
Requires at least: 4.7
Tested up to: 4.9.8
Stable tag: 2.0.9
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: two-columns, left-sidebar, right-sidebar, custom-header, custom-background, custom-logo, custom-menu, theme-options, featured-images, threaded-comments, full-width-template, footer-widgets, translation-ready, blog, e-commerce, portfolio

A starter theme called Rara Business Pro.

== Description ==

Rara Business Pro is a SEO friendly, speed optimized and mobile friendly WordPress theme that you can use to create clean and professional businesses websites. You can easily and quickly change the look and feel of your website without writing a single line of code.  The theme is great for showcasing your services, portfolio, experiences, testimonials and team members that will help you grow your client relationships and business.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Documentation ==
    * Homepage Setup
    * To set up the homepage you must first install and activate the recommended plugins ( RaraTheme Companion ). Then, create a page for the homepage. After that, follow the following steps.
             
    => Go to Appearance>Customize > Homepage Settings.
    => Select A static page under Your homepage displays
    => Choose the page you just created as Home page.
    => Click Save & Publish.

	You are now ready to setup the home page. Go to Appearance> Customize> Frontpage Settings to edit the different frontpage sections. for more documentation visit https://raratheme.com/documentation/rara-business-pro/

== Copyright ==

Rara Business Pro WordPress Theme, Copyright 2017 raratheme.com
Rara Business Pro is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Rara Business Pro bundles the following third-party resources:

Isotope PACKAGED v3.0.5
Source      : https://isotope.metafizzy.co
License     : GPLv3
License Url : https://github.com/metafizzy/isotope

malihu jquery custom scrollbar plugin v3.1.5 
Source  	: http://manos.malihu.gr/jquery-custom-content-scroller
License 	: MIT License (MIT)
License Url : https://github.com/malihu/malihu-custom-scrollbar-plugin/blob/master/LICENSE.txt

wow, Copyright (c) 2016 Matthieu Aussaguel
Source  	: https://github.com/matthieua/WOW
License 	: GPLv3
License Url : https://github.com/matthieua/WOW

animate.css, Copyright (c) 2017 Daniel Eden
Source		: https://github.com/daneden/animate.css
License 	: MIT
License Url : https://github.com/daneden/animate.css/blob/master/LICENSE

Font Awesome icons, Copyright Dave Gandy
Icons License: CC BY 4.0 
Fonts License: SIL OFL 1.1 
Source: http://fontawesome.io/

TGMPA, Copyright (c) 2011, Thomas Griffin
License: GPL-2.0+
Source: http://tgmpluginactivation.com/

# Images
  All images are under Creative Commons Public Domain deed CC0.

    * Banner Image
        Link: https://www.pexels.com/photo/analysis-brainstorming-business-business-group-466733/

# Kirki
    Rara Business Pro WordPress Theme incorporates code from Kirki, Copyright (c) 2017 Aristeides Stathopoulos
    Kirki is distributed under the terms of The MIT License (MIT)
    License Url: https://github.com/aristath/kirki/blob/develop/LICENSE

Unless otherwise specified, all the theme files, scripts and images are licensed under GPLv2 or later

== Credits ==
* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

== Changelog ==   
    = 2.0.9 =
    * Added Software Company child theme feaures.
     
    = 2.0.8 = 
    * Fixed skill widget background image issue. 
    * Fixed blog section view all button link issue. 
    * Fixed white screen issue in lower php version. 
     
    = 2.0.7 =
    * Added option to open link in new tab for custom link in header.
    * fixed issue of pseudo element in fontawesome 5.0 
    * fixed customizer fontawesome issue

    = 2.0.6 =
    * View All button CSS fixed. 
    * Font awesome conflict issue fixed. 

    = 2.0.5 =
    * Fixed sticky menu issue in onpage menu option. 
    * Added readmore link in frontpage sections.
    * Some css tweaks.
    * Fixed horizontal scrollbar issue in microsoft edge
    
    = 2.0.4 =
    * Added performance features
    * Updated wpml-config.xml file
    
    = 2.0.3 =
    * Search page static search query string issue fixed.
    * Minor bug fix.

    = 2.0.2 =
    * Enable/Disable Animation option added in the customizer.
    * Removed demo files from theme and updated imported hooks.

    = 2.0.1 =
    * Fixed screen movement issue in mac. 
    * Fixed hidden submenu issue in mobile devices.
    * Updated to WP 4.9.6 changes.
    * Comment field set to default order.
    * Some css tweaks.
    
	= 2.0.0 =
	* Initial release