<?php
/**
 * FAQ's Section
 * 
 * @package Rara_Business_Pro
*/

/** Load default theme options */
$default_options =  rara_business_pro_default_theme_options();

$faq_page_url = rara_business_pro_get_template_page_url( 'templates/faq.php', 'page' );
$button_label = get_theme_mod( 'frontpage_faq_widget_readmore_text', $default_options['frontpage_faq_widget_readmore_text'] );

if( is_active_sidebar( 'faq' ) ){ ?>
    <section id="faq-section" class="faq-section wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
    	<div class="container">
    		<?php dynamic_sidebar( 'faq' ); ?>

			<?php if( ! empty( $button_label ) && ! empty( $faq_page_url ) ){ ?>
    			<div class="btn-holder"><a href="<?php echo esc_url( $faq_page_url ); ?>" class="btn-view"><?php echo esc_html( $button_label ); ?></a></div>
    		<?php } ?>
    	</div>
    </section>
<?php
}