<?php
/**
 * Pricing Section
 * 
 * @package Rara_Business_Pro
*/

if( is_active_sidebar( 'pricing' ) ) { ?>
    <section id="pricing-section" class="our-pricing wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
		<div class="container">
			<div class="pricing-holder">
				<?php dynamic_sidebar( 'pricing' ); ?>
			</div><!-- .pricing-holder -->
		</div>
	</section>
<?php
}