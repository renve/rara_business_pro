<?php
/**
 * Testimonial Section
 * 
 * @package Rara_Business_Pro
*/

/** Load default theme options */
$default_options =  rara_business_pro_default_theme_options();

$testimonial_page_url = rara_business_pro_get_template_page_url( 'templates/testimonial.php', 'page' );
$button_label         = get_theme_mod( 'fp_testimonial_viewall_label', $default_options['fp_testimonial_viewall_label'] );

if( is_active_sidebar( 'testimonial' ) ) { ?>
    <section id="testimonial-section" class="our-testimonial wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
    	<div class="container">
    		<div class="grid">
    			<?php dynamic_sidebar( 'testimonial' ); ?>
    		</div>
    		<?php
	    		if( ! empty( $button_label ) && ! empty( $testimonial_page_url ) ){ ?>
	    			<div class="btn-holder"><a href="<?php echo esc_url( $testimonial_page_url ); ?>" class="btn-readmore"><?php echo esc_html( $button_label ); ?></a></div>
	    		<?php } 
			?>
    	</div>
    </section>
<?php
}