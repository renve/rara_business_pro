<?php
/**
 * Team Section
 * 
 * @package Rara_Business_Pro
*/

/** Load default theme options */
$default_options =  rara_business_pro_default_theme_options();

$team_page_url = rara_business_pro_get_template_page_url( 'templates/team.php', 'page' );
$button_label  = get_theme_mod( 'fp_team_viewall_label', $default_options['fp_team_viewall_label'] );

if( is_active_sidebar( 'team' ) ) { ?>
    <section id="team-section" class="our-team wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
    	<div class="container">
    		<div class="grid">
    			<?php dynamic_sidebar( 'team' ); ?>
    		</div>
    		<?php
	    		if( ! empty( $button_label ) && ! empty( $team_page_url ) ){ ?>
	    			<div class="btn-holder"><a href="<?php echo esc_url( $team_page_url ); ?>" class="btn-readmore"><?php echo esc_html( $button_label ); ?></a></div>
	    		<?php } 
			?>
    	</div>
    </section>
<?php
}