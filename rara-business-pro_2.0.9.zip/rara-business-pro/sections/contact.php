<?php
/**
 * Contact Section
 * 
 * @package Rara_Business_Pro
*/

/** Load default theme options */
$default_options       = rara_business_pro_default_theme_options(); 
$header_contact_ctrl   = get_theme_mod( 'ed_header_contact_details', $default_options['ed_header_contact_details'] );
$header_social_ctrl    = get_theme_mod( 'ed_header_social_links', $default_options['ed_header_social_links'] );
$show_header_contact   = get_theme_mod( 'ed_contact_detail_as_in_header', $default_options['ed_contact_detail_as_in_header'] );
$show_header_social    = get_theme_mod( 'ed_social_links_as_in_header', $default_options['ed_social_links_as_in_header'] );
$show_google_map       = get_theme_mod( 'ed_frontpage_google_map', $default_options['ed_frontpage_google_map'] );

$section_title         = get_theme_mod( 'contact_title', $default_options['contact_title'] );
$section_description   = get_theme_mod( 'contact_description', $default_options['contact_description'] );

if( ! ( $header_contact_ctrl && $show_header_contact ) ){
	$phone_number      = get_theme_mod( 'contact_phone', $default_options['contact_phone'] );
	$address           = get_theme_mod( 'contact_address', $default_options['contact_address'] );
	$email             = get_theme_mod( 'contact_email', $default_options['contact_email'] );
} else {
	$phone_number      = get_theme_mod( 'header_phone', $default_options['header_phone'] );
	$address           = get_theme_mod( 'header_address', $default_options['header_address'] );
	$email             = get_theme_mod( 'header_email', $default_options['header_email'] );
}

if( ! ( $header_social_ctrl && $show_header_social ) ){
	$social_control    = true;
	$social_links      = get_theme_mod( 'contact_social_links', $default_options['contact_social_links'] );
} else {
	$social_control    = $header_social_ctrl;
	$social_links      = get_theme_mod( 'header_social_links', $default_options['header_social_links'] );
}

$form_shortcode        = get_theme_mod( 'contact_cf7_shortcode', $default_options['contact_cf7_shortcode'] );
?>

<section id="contact-section" class="contact-section wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
	<div class="container">
		<?php if( ! empty( $section_title ) || ! empty( $section_description ) ) : ?>
			<header class="section-header">
				<section class="widget widget_text">
					<?php if( ! empty( $section_title ) ) echo '<h2 class="widget-title">'. esc_html( $section_title ) .'</h2>'; ?>
					<div class="textwidget">
					<?php  if( ! empty( $section_description ) ) echo wp_kses_post( wpautop( $section_description ) ); ?>
					</div>
				</section>
			</header>
		<?php endif; ?>
		<div class="holder">
			<div class="left">
				<div class="contact-detail">
					<?php 
						if( ! empty( $phone_number ) || ! empty( $email ) || ! empty( $address ) ){ 
							if( !empty( $phone_number ) ) echo '<a href="tel:'. esc_attr( preg_replace( '/\D/', '', $phone_number ) ) .'" class="tel-link"><i class="fa fa-mobile-phone"></i>'. esc_html( $phone_number ) .'</a>';
							if( !empty( $address ) ) echo '<address><i class="fa fa-map-marker"></i>'. esc_html( $address ) .'</address>';
							if( !empty( $email ) ) echo '<a href="mailto:'. sanitize_email( $email ) .'" class="email-link"><i class="fa fa-envelope-o"></i>'. sanitize_email( $email ) .'</a>';
						}

						rara_business_pro_social_links( $social_control, $social_links );
					?>
				</div>
				<?php if( $show_google_map ) echo '<div id="map-canvas" class="map-holder"></div><!-- .map-holder -->'; ?>
			</div>
			<?php 
				if( ! empty( $form_shortcode ) && rara_business_pro_is_cf7_activated() ){
					echo '<div class="form-holder">';
					echo do_shortcode( $form_shortcode );
					echo '</div>';
				}
			?>
		</div>
	</div>
</section>