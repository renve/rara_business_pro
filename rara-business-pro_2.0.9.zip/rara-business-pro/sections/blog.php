<?php
/**
 * Blog Section
 * 
 * @package Rara_Business_Pro
*/

/** Load default theme options */
$default_options =  rara_business_pro_default_theme_options();

$title        = get_theme_mod( 'blog_title', $default_options['blog_title'] );
$subtitle     = get_theme_mod( 'blog_description', $default_options['blog_description'] );
$button_label = get_theme_mod( 'blog_viewall_label', $default_options['blog_viewall_label'] );
$blog_page    = get_option( 'page_for_posts' );

$args = array(
    'post_type'           => 'post',
    'post_status'         => 'publish',
    'posts_per_page'      => 6,
    'ignore_sticky_posts' => true
);

$qry = new WP_Query( $args );

if( $qry->have_posts() || $title || $subtitle ){ ?>
    <section id="blog-section" class="blog-section wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
    	<div class="container">
    		<?php if( $title || $subtitle ){ ?>
            <header class="section-header">
    			<section class="widget widget_text">
    				<?php 
                        if( $title ) echo '<h2 class="widget-title">' . esc_html( $title )  . '</h2>';
                        if( $subtitle ) echo '<div class="textwidget">' . wpautop( wp_kses_post( $subtitle ) ) . '</div>';
                    ?>
    			</section>
    		</header>
    		<?php } ?>
            
            <?php if( $qry->have_posts() ){?>
            <div class="grid">
    			<?php while( $qry->have_posts() ){ $qry->the_post(); ?>
                <article class="blog-post" itemscope itemtype="http://schema.org/Blog">
    				<a href="<?php the_permalink(); ?>" class="post-thumbnail">
                        <?php 
                        if( has_post_thumbnail() ){
                            the_post_thumbnail( 'rara-business-blog', 'itemprop=image' );                        
                        }else{
                            echo '<img src="'. esc_url( get_template_directory_uri().'/images/rara-business-blog.jpg' ) .'" alt="'. esc_attr( get_the_title() ) .'">';   
                        } 
                        ?>
                    </a>
    				<h3 class="entry-title" itemprop="headline"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    				<div class="entry-meta">
            			<?php 
                            rara_business_pro_posted_on();
                            rara_business_pro_posted_by();
                         ?>
            		</div><!-- .entry-meta -->
    			</article>			
    			<?php } wp_reset_postdata(); ?>
    		</div>
            <?php } 

                if( ! empty( $button_label ) && ! empty( $blog_page ) ){ ?>
                    <div class="btn-holder"><a href="<?php echo esc_url( get_the_permalink( $blog_page ) ); ?>" class="btn-readmore"><?php echo esc_html( $button_label ); ?></a></div>
                <?php } 
            ?>
    	</div>
    </section>
<?php
}